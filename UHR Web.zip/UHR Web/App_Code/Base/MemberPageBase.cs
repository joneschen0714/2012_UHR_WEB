﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

namespace UHR
{
    public class MemberPageBase : Page
    {
        //初始化
        protected override void OnPreInit(EventArgs e)
        {
            //若未登入
            if (!MemberInfo.CheckLogin)
            {
                string redirect = Server.UrlEncode(Request.Url.ToString()); //記錄目標頁面
                Response.Redirect("~/Page/Member/Login.aspx?redirect=" + redirect); //導向會員登入頁
            }
        }
    }
}