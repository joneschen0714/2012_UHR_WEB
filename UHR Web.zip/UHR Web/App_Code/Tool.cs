﻿using System;
using System.Data;
using System.Data.Odbc;
using System.IO;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Xml;
using ICSharpCode.SharpZipLib.Zip;
using Microsoft.Office.Interop.Owc11;

namespace UHR
{
    public class Tool
    {
        public Tool()
        {

        }

        /// <summary>DataTable轉換為JSON字串格式</summary>
        public static string DataTableConvertJson(DataTable dt)
        {
            StringBuilder jsonBuilder = new StringBuilder();
            jsonBuilder.Append("{\"");
            jsonBuilder.Append(dt.TableName);
            jsonBuilder.Append("\":[");
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                jsonBuilder.Append("{");
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    jsonBuilder.Append("\"");
                    jsonBuilder.Append(dt.Columns[j].ColumnName);
                    jsonBuilder.Append("\":\"");
                    jsonBuilder.Append(dt.Rows[i][j].ToString());
                    jsonBuilder.Append("\",");
                }
                jsonBuilder.Remove(jsonBuilder.Length - 1, 1);
                jsonBuilder.Append("},");
            }
            jsonBuilder.Remove(jsonBuilder.Length - 1, 1);
            jsonBuilder.Append("]");
            jsonBuilder.Append("}");
            return jsonBuilder.ToString();
        }

        /// <summary>檔案轉Byte[]</summary>
        public static byte[] ConvertFileToByte(string filepath)
        {
            FileStream fs = new FileStream(filepath, FileMode.Open, FileAccess.Read);
            byte[] buf = new byte[fs.Length];
            fs.Read(buf, 0, Convert.ToInt32(fs.Length));
            fs.Close();
            fs.Dispose();

            return buf;
        }

        /// <summary>分割字串，並在各個值前後加上指定字元</summary>
        public static string SetSplitSingleMark(string value, string SingleMark, char splitChar)
        {
            string newValue = "";

            foreach (string str in value.Split(splitChar))
                newValue += SingleMark + str.Trim() + SingleMark + splitChar;

            return newValue.Trim(splitChar);
        }

        /// <summary>取得HttpContext，並轉NULL為空值</summary>
        public static string CheckQueryString(string strName)
        {
            HttpContext context = HttpContext.Current;
            if (context.Request.QueryString[strName] == null)
                return "";
            else
                return context.Request.QueryString[strName].ToString();
        }

        /// <summary>取得HttpContext，並轉NULL為空值</summary>
        public static string GetStringUrlParam(string strUrl, string strParamName)
        {
            string strValue = "";
            foreach (string strItem in strUrl.Split('?', '&'))
            {
                string[] ItemData = strItem.Split('=');
                if (ItemData[0] == strParamName)
                {
                    strValue = ItemData[1];
                }
            }

            return strValue;
        }

        /// <summary>設定Url的某個參數</summary>
        public static string SetUrlParam(string Url, string ParamName, string ParamValue)
        {
            string[] _items = Url.Split('?');
            string strUrlMain = "", strUrlParams = "", strParamsValue = "";

            strUrlMain = _items[0];
            strUrlParams = (_items.Length == 2 ? _items[1] : "");

            if (!string.IsNullOrEmpty(strUrlParams))
            {
                foreach (string _param in strUrlParams.Split('&'))
                {
                    string[] ItemData = _param.Split('=');
                    string _name = ItemData[0];
                    string _value = ItemData[1];

                    if (_name != ParamName)
                    {
                        strParamsValue += string.Format("{0}={1}&", _name, _value);
                    }
                }
            }

            if (!string.IsNullOrEmpty(ParamValue))
                strParamsValue += string.Format("{0}={1}&", ParamName, ParamValue);

            if (!string.IsNullOrEmpty(strParamsValue))
                strUrlMain += "?" + strParamsValue.TrimEnd('&');

            return strUrlMain;
        }

        /// <summary>取得Xml節點的屬性值</summary>
        public static string GetXmlAttributeItem(XmlNode _node, string _AttrName)
        {
            string strResult = "";
            if (_node.Attributes[_AttrName] != null)
            {
                strResult = _node.Attributes[_AttrName].Value;
            }

            return strResult;
        }

        /// <summary>取得JavaScript for jQuery指令控制項</summary>
        public static Control GetJavaScriptContent(string _script)
        {
            string strScript = "<script type='text/javascript'>$(document).ready(function(){{ScriptContent}});</script>";
            strScript = strScript.Replace("{ScriptContent}", _script);

            LiteralControl liScript = new LiteralControl(strScript);
            return liScript;
        }

        /// <summary>空值轉換DBNULL函式</summary>
        public static object GetDBNullString(object _obj)
        {
            string str = null;

            if (_obj != null)
                str = _obj.ToString().Trim();

            if (string.IsNullOrEmpty(str))
                _obj = DBNull.Value;

            return _obj;
        }

        /// <summary>轉DataTable為CSV檔</summary>
        public static void DataTableToCSV(DataTable table, string strPath)
        {
            //宣告
            string strCol = "";
            string[] strValAry = new string[table.Rows.Count];
            StreamWriter writer = new StreamWriter(strPath, false, System.Text.Encoding.Default);

            //循序讀取欄位名稱
            foreach (DataColumn col in table.Columns)
            {
                strCol += (strCol == "" ? "" : ",") + "\"" + col.ColumnName.Trim() + "\""; //累加欄位名稱

                //循序讀取資料列
                int colIndex = 0;
                foreach (DataRow row in table.Rows)
                {
                    strValAry[colIndex] += (strValAry[colIndex] == null ? "" : ",") + "\"" + row[col.ColumnName].ToString().Trim() + "\""; //增加值至陣列
                    colIndex++;
                }
            }

            writer.WriteLine(strCol); //寫入欄位
            //循序寫入資料
            foreach (string strVal in strValAry)
                writer.WriteLine(strVal);

            //關閉物件
            writer.Close();
            writer.Dispose();
        }

        /// <summary>轉DataTable為Excel檔</summary>
        public static void DataTableToExcel(DataTable table, string strPath)
        {
            //增加表分頁
            SpreadsheetClass myexcel = new SpreadsheetClass();
            Worksheet mysheet = myexcel.ActiveSheet;

            //循序增加表標題
            for(int i=0; i< table.Columns.Count; i++)
            {
                mysheet.Cells[1, i+1] = table.Columns[i].ColumnName;
            }

            //循序讀取資料列
            for (int i = 0; i < table.Rows.Count; i++)
            {
                //循序讀取資料欄
                for (int j = 0; j < table.Columns.Count; j++)
                {
                    mysheet.Cells[i + 2, j + 1] = table.Rows[i][j].ToString(); //寫入資料
                }
            }

            //匯出表格
            myexcel.Export(strPath, SheetExportActionEnum.ssExportActionNone, SheetExportFormat.ssExportXMLSpreadsheet);
        }

        /// <summary>取得上傳至指定的CSV內容-相容64位元系統 (ODBC)</summary>
        public static DataTable GetDataSetFromCSV(string filePath, string fileName)
        {
            string strConn = @"Driver={Microsoft Text Driver (*.txt; *.csv)};Dbq=";
            strConn += filePath; //filePath, For example: C:\
            strConn += ";Extensions=asc,csv,tab,txt;";
            OdbcConnection objConn = new OdbcConnection(strConn);
            DataTable dtCSV = new DataTable();
            try
            {
                string strSql = "select * from " + fileName; //fileName, For example: 1.csv
                OdbcDataAdapter odbcCSVDataAdapter = new OdbcDataAdapter(strSql, objConn);
                odbcCSVDataAdapter.Fill(dtCSV);
                return dtCSV;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>解壓縮檔案</summary>
        public static void UnZip(string zipfilePath, string targetpath)
        {
            ZipInputStream s = new ZipInputStream(File.OpenRead(zipfilePath));

            ZipEntry theEntry;
            while ((theEntry = s.GetNextEntry()) != null)
            {
                string directoryName = Path.GetDirectoryName(targetpath);
                string fileName = Path.GetFileName(theEntry.Name);

                //生成解壓目錄 
                Directory.CreateDirectory(directoryName);

                if (fileName != String.Empty)
                {
                    //解壓文件到指定的目錄 
                    FileStream streamWriter = File.Create(targetpath + theEntry.Name);

                    int size = 2048;
                    byte[] data = new byte[2048];
                    while (true)
                    {
                        size = s.Read(data, 0, data.Length);
                        if (size > 0) { streamWriter.Write(data, 0, size); }
                        else { break; }
                    }
                    streamWriter.Close();
                }
            }
            s.Close();
        }

        /// <summary>台幣換算美金(幣別格式)</summary>
        public static decimal GetUSDPrice(object Price, int MidpointRound)
        {
            decimal dPrice = Convert.ToDecimal(Price);
            decimal thisPrice = (dPrice / Definition.USD_Currency);
            thisPrice = Math.Round(thisPrice, MidpointRound);

            return thisPrice;
        }

        /// <summary>取得Client端的IP位址</summary>
        public static string GetClientIP()
        {
            string ClientIP = HttpContext.Current.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ClientIP))
            {
                ClientIP = HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"];
            }

            return ClientIP;
        }

        /// <summary>過濾內部IP</summary>
        public static bool FilterToCorrectIP(string IP)
        {
            bool Result = true;

            switch (IP)
            {
                case "211.20.112.217":
                    Result = false;
                    break;
            }

            return Result;
        }

        /// <summary>把Null或DBNULL轉為預設值</summary>
        public static object GetValue(object obj, object DefaultValue)
        {
            if (obj == DBNull.Value || obj == null)
            {
                obj = DefaultValue;
            }

            return obj;
        }

        /// <summary>取得累加數字的文字內容補0</summary>
        public static string GetPadLeftString(string value, int iNumber)
        {
            int iCount = value.Length;
            int iVal = int.Parse(value) + iNumber;
            return iVal.ToString().PadLeft(iCount, '0');
        }

        /// <summary>將空值或NULL取代成指定字</summary>
        public static string ReplaceNullText(object _obj, string replaceText)
        {
            string str = null;

            if (_obj != null)
                str = _obj.ToString().Trim();

            if (string.IsNullOrEmpty(str))
                str = replaceText;

            return str;
        }
    }
}