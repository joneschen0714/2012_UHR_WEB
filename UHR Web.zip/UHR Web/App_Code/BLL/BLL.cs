﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Linq;

namespace UHR
{
    public class BLL
    {
        public BLL()
        {

        }

        /// <summary>取得熱門產品資料</summary>
        public static DataTable GetHotProducts()
        {
            return DAL.GetHotProducts();
        }

        /// <summary>取得最新一筆News內容</summary>
        public static DataRow GetFirstNews()
        {
            return DAL.GetFirstNews();
        }

        /// <summary>取得所有News內容</summary>
        public static DataTable GetAllNews(string _type, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL.GetAllNews(_type, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得指定的News內容</summary>
        public static DataRow GetSingleNews(object _newsid)
        {
            return DAL.GetSingleNews(_newsid);
        }

        /// <summary>取得靜態頁面內容</summary>
        public static string GetStaticPageContent(object _Type)
        {
            return DAL.GetStaticPageContent(_Type);
        }

        /// <summary>取得巡覽列名稱</summary>
        public static string GetNavigatorName(string strSQL)
        {
            return DAL.GetNavigatorName(strSQL);
        }

        /// <summary>取得產品List</summary>
        public static DataTable GetProductList(string _keyword, string _oemlm, string _type, string _catalog, string _brand, string _uhrlm, string _class, string _stock)
        {
            return DAL.GetProductList(_keyword, _oemlm, _type, _catalog, _brand, _uhrlm, _class, _stock);
        }

        /// <summary>取得單筆產品資訊</summary>
        public static DataRow GetProductInfo(string _id, string UHR_LM)
        {
            DataRow row = DAL.GetProductInfo(_id, UHR_LM);

            //若Bulb Status等於空白，則預設N
            string bl_status = Convert.ToString(row["UHR_BL_Status"]);
            row["UHR_BL_Status"] = string.IsNullOrEmpty(bl_status) ? "N" : bl_status;

            return row;
        }

        /// <summary>取得原廠燈Marking</summary>
        public static string GetOEMLampModuleMarking(string ProjectorID)
        {
            return DAL.GetOEMLampModuleMarking(ProjectorID);
        }

        /// <summary>取得相關Projector</summary>
        public static DataTable GetRelatedProjector(string _uhrlmid)
        {
            return DAL.GetRelatedProjector(_uhrlmid);
        }

        /// <summary>取得相關OEM Lamp Module</summary>
        public static DataTable GetRelatedOEMLampModule(string _uhrlmid)
        {
            return DAL.GetRelatedOEMLampModule(_uhrlmid);
        }

        /// <summary>取得UHR Lamp Module圖片</summary>
        public static DataTable GetUHR_LampModuleImage(string _uhrlmid)
        {
            return DAL.GetUHR_LampModuleImage(_uhrlmid);
        }

        /// <summary>檢查會員註冊資料</summary>
        public static void CheckMember(string _memberid, string _email, ref string _message)
        {
            DAL.CheckMember(_memberid, _email, ref _message);
        }

        /// <summary>會員註冊</summary>
        public static void RegisterMember(string _password, string _email, string _name, string _tel, string _address, string _company, string _sex, string _country)
        {
            DAL.RegisterMember(_password, _email, _name, _tel, _address, _company, _sex, _country);
        }

        /// <summary>登入驗証</summary>
        public static DataTable MemberLogin(string _email, string _password)
        {
            return DAL.MemberLogin(_email, _password);
        }

        /// <summary>以Email取得會員資料</summary>
        public static DataTable EmailGetMember(string _email)
        {
            return DAL.EmailGetMember(_email);
        }

        /// <summary>以會員ID取得會員資料</summary>
        public static DataTable GetMemberInfo(string _memberid)
        {
            return DAL.GetMemberInfo(_memberid);
        }

        /// <summary>取得Promotion List資料</summary>
        public static DataTable GetPromotionList()
        {
            return DAL.GetPromotionList();
        }

        /// <summary>取得Catalog Description資料</summary>
        public static string GetCatalogDescription(string _catalogid)
        {
            return DAL.GetCatalogDescription(_catalogid);
        }

        /// <summary>取得Quick Order資料</summary>
        public static DataTable GetQuickOrderData(string _keyword)
        {
            return DAL.GetQuickOrderData(_keyword);
        }

        /// <summary>新增項目至WishList</summary>
        public static void AddWishList(object _memberid, object _projectorid)
        {
            DAL.AddWishList(_memberid, _projectorid);
        }

        /// <summary>檢查WishList項目是否衝突</summary>
        public static bool WishListExists(object _memberid, object _projectorid)
        {
            return DAL.WishListExists(_memberid, _projectorid);
        }

        /// <summary>取得WishList清單資料</summary>
        public static DataTable GetWishListData(string _memberid)
        {
            return DAL.GetWishListData(_memberid);
        }

        /// <summary>移除WishList項目</summary>
        public static void RemoveWishListItem(string _wishlistid)
        {
            DAL.RemoveWishListItem(_wishlistid);
        }

        /// <summary>新增詢價記錄</summary>
        public static bool AddOrder(string _memberid, string _ordernum, string _type, string _attn, string _po, string _tel, string _shipaddress, string _billaddress, string _comment, string _attachment, string _emailcc, ShoppingCart _sc)
        {
            return DAL.AddOrder(_memberid, _ordernum, _type, _attn, _po, _tel, _shipaddress, _billaddress, _comment, _attachment, _emailcc, _sc);
        }

        /// <summary>訂單匯入</summary>
        public static bool ImportOrderList(string OrderType, DataTable dt, ref string Message)
        {
            MemberInfo mi = Definition.MemberInfo;
            bool result = true;

            #region 驗証庫存量
            //取出每個品名的總數量
            var grouped = from t in dt.AsEnumerable()
                          where t.Field<string>("Shipping Address") != null
                          group t by t["UHR P/N"] into g
                          select new
                          {
                              GroupKey = g.Key,
                              TotalQty = g.Sum(p => (int)p["Quantity"]),
                              SubTotal = g.Sum(p => (decimal)p["SubTotal"])
                          };

            //循序驗証庫存數是否足夠
            foreach (var group in grouped)
            {
                var PN = group.GroupKey;
                int TotalQty = group.TotalQty;

                int iStock = BLL.GetProductStockQtyAmerica(PN.ToString());
                if (TotalQty > iStock)
                {
                    Message += string.Format(Resources.Lang.L000197, PN, iStock);
                    result = false;
                }
            }
            #endregion

            #region 驗証信用額度
            //總價格
            decimal TotalPrice = grouped.Sum(p => p.SubTotal);

            //檢查信用額度
            decimal dCreditLimit = BLL.GetCustomCreditLimit(mi.ERP_Company, mi.ERP_CustomCode);
            if (dCreditLimit - TotalPrice < 0)
            {
                result = false;
                Message = Resources.Lang.L000193;
            }
            #endregion

            if (result)
            {
                result = DAL.ImportOrderList(OrderType, dt, ref Message); //呼叫匯入函式

                if (!result)
                {
                    Message = string.Format(Resources.Lang.L000198);
                }
            }

            return result;
        }

        /// <summary>取得新訂單編號</summary>
        public static string GetNewOrderNumber()
        {
            //(編碼:W YY MM DD 四碼流水號)
            string strOrderNum = "W" + DateTime.Now.ToString("yyyyMMdd").Substring(2);
            string value = DAL.GetNewOrderNumber(strOrderNum);

            //若無編號則預設0001，反之則累加1
            if (string.IsNullOrEmpty(value))
                value = strOrderNum + "0001";
            else
                value = strOrderNum + Tool.GetPadLeftString(value.Substring(7), 1);

            return value;
        }

        /// <summary>取得最後一筆詢價單記錄</summary>
        public static DataRow GetLastOrder(string MemberID)
        {
            return DAL.GetLastOrder(MemberID);
        }

        /// <summary>取得Projector販售清單</summary>
        public static DataTable GetProjectorSell()
        {
            return DAL.GetProjectorSell();
        }

        /// <summary>取得RMA原因代號資料</summary>
        public static DataTable GetRmaReason()
        {
            return DAL.GetRmaReason();
        }

        /// <summary>新增RMA單資料</summary>
        public static bool AddRMAForm(string _type, string _description, string _item, MemberInfo _mi)
        {
            return DAL.AddRMAForm(_type, _description, _item, _mi);
        }

        /// <summary>更新會員資料</summary>
        public static void UpdateMemberInfo(string _memberid, string _password, string _email, string _name, string _tel, string _address, string _company, string _sex, string _country)
        {
            DAL.UpdateMemberInfo(_memberid, _password, _email, _name, _tel, _address, _company, _sex, _country);
        }

        /// <summary>更新會員的登入時間</summary>
        public static void UpdateMemberLoginDate(string MemberID)
        {
            DAL.UpdateMemberLoginDate(MemberID);
        }

        /// <summary>取得國家清單</summary>
        public static DataTable GetCountryList(string _code)
        {
            return DAL.GetCountryList(_code);
        }

        /// <summary>取得品牌名稱</summary>
        public static string GetBrandName(string BrandID)
        {
            return DAL.GetBrandName(BrandID);
        }

        /// <summary>取得OEM Lamp Module名稱</summary>
        public static string GetOEMLampModuleName(string LampModuleID)
        {
            return DAL.GetOEMLampModuleName(LampModuleID);
        }

        /// <summary>取得Config定義表的對應顯示名稱</summary>
        public static string GetConfigName(string Type, string Value)
        {
            return DAL.GetConfigName(Type, Value);
        }

        /// <summary>取得Config定義表的資料</summary>
        public static DataTable GetConfigData(string Type)
        {
            return DAL.GetConfigData(Type);
        }

        /// <summary>取得UHR Lamp Module品名</summary>
        public static string GetUHRLampModuleName(string UHRLMID)
        {
            return DAL.GetUHRLampModuleName(UHRLMID);
        }

        /// <summary>取得OEM Lamp Module清單</summary>
        public static DataTable GetOEMLampModuleByProjector(string ProjectorIDArray)
        {
            return DAL.GetOEMLampModuleByProjector(ProjectorIDArray);
        }

        /// <summary>增加產品瀏覽Log</summary>
        public static void InsertProductBrowseLog(string PID, string MemberID, string IP)
        {
            //檢查是否為外部IP
            if (Tool.FilterToCorrectIP(IP))
            {
                DAL.InsertProductBrowseLog(PID, MemberID, IP);
            }
        }

        /// <summary>增加關鍵字Log</summary>
        public static void InsertKeywordLog(string Keyword, string MemberID, string IP)
        {
            //檢查是否為外部IP
            if (Tool.FilterToCorrectIP(IP))
            {
                DAL.InsertKeywordLog(Keyword, MemberID, IP);
            }
        }

        /// <summary>取得廠牌的資料清單</summary>
        public static DataTable GetBrandList(string BrandIDArray)
        {
            return DAL.GetBrandList(BrandIDArray);
        }

        /// <summary>新增FAQ</summary>
        public static void InsertFAQ(string c_ID, string MemberID, string Type, string Subject, string Contents)
        {
            DAL.InsertFAQ(c_ID, MemberID, Type, Subject, Contents);
        }

        /// <summary>取得FAQ List</summary>
        public static DataTable GetFAQList(string MemberID, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL.GetFAQList(MemberID, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得FAQ List</summary>
        public static DataTable GetFAQDetail(string ID)
        {
            return DAL.GetFAQDetail(ID);
        }

        /// <summary>取得產品的庫存數量(美國)</summary>
        public static int GetProductStockQtyAmerica(string PartName)
        {
            //若小於0，則顯示0
            int qty = DAL.GetProductStockQtyAmerica(PartName);
            qty = qty < 0 ? 0 : qty;

            return qty;
        }

        /// <summary>取得產品的庫存數量(台灣)</summary>
        public static int GetProductStockQtyTaiwan(string PartName)
        {
            return DAL.GetProductStockQtyTaiwan(PartName);
        }

        /// <summary>取得會員的價格表定義</summary>
        public static DataTable GetMemberPriceTitle(string MemberID)
        {
            return DAL.GetMemberPriceTitle(MemberID);
        }

        /// <summary>取得會員的價格表</summary>
        public static DataTable GetMemberPrice(string MemberID, string OrderType, string Product, string Qty)
        {
            return DAL.GetMemberPrice(MemberID, OrderType, Product, Qty);
        }

        /// <summary>取得會員購物車的OrderType清單</summary>
        public static DataTable GetpProductOrderType(string MemberID, ShoppingCart sc)
        {
            //轉成文字陣列
            string[] strList = new string[sc.Count];
            for (int i = 0; i < sc.Count; i++)
            {
                strList[i] = sc[i].ProductNo;
            }

            return DAL.GetpProductOrderType(MemberID, strList);
        }

        /// <summary>取得ERP對應的客戶品號資料</summary>
        public static DataTable GetERPCustomPN(string ERPCompany, string CustomCode, string ProductName)
        {
            return DAL.GetERPCustomPN(ERPCompany, CustomCode, ProductName);
        }

        /// <summary>取得ERP對應的客戶基本資料</summary>
        public static DataRow GetERPMemerProfile(string ERPCompany, string CustomCode)
        {
            return DAL.GetERPMemerProfile(ERPCompany, CustomCode);
        }

        /// <summary>取得ERP對應的客戶信用額度</summary>
        public static decimal GetCustomCreditLimit(string ERPCompany, string CustomCode)
        {
            return DAL.GetCustomCreditLimit(ERPCompany, CustomCode);
        }

        /// <summary>取得訂單歷史記錄</summary>
        public static DataTable GetOrderList(string ID, string MemberID, string Type, string strSDate, string strEDate, string strKeyword, int _pageindex, int _pagesize, out int _recordcount)
        {
            return DAL.GetOrderList(ID, MemberID, Type, strSDate, strEDate, strKeyword, _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得訂單單身項目歷史記錄</summary>
        public static DataTable GetOrderItemList(string OrderID)
        {
            return DAL.GetOrderItemList(OrderID);
        }

        /// <summary>判斷訂單是否已轉入ERP</summary>
        public static bool CheckOrderToERP(string ERPCompany, string OrderNumber)
        {
            return DAL.CheckOrderToERP(ERPCompany, OrderNumber);
        }

        /// <summary>取消訂單</summary>
        public static void CancelOrder(string OrderNumber)
        {
            DAL.CancelOrder(OrderNumber);
        }

        /// <summary>取得產品庫存表列表</summary>
        public static DataTable GetInvertoryList(string MemberID, string OrderType)
        {
            return DAL.GetInvertoryList(MemberID, OrderType);
        }
    }
}