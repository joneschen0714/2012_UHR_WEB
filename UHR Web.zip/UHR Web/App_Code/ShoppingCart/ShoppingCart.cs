﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using UHR.OrderType;

namespace UHR
{
    /// <summary>購物車集合</summary>
    public class ShoppingCart : List<ShoppingCartItem>
    {
        //變數
        private string _ordertype = "";
        private OrderTypeBase _base = null;

        public ShoppingCart() { }

        /// <summary>訂單類型</summary>
        public string OrderType
        {
            set
            {
                _ordertype = value;

                //判斷OrderType，給予對應的物件
                if (_ordertype == "D")
                    _base = new DropShipment();
                else
                    _base = new NormalOrder();

            }
            get { return _ordertype; }
        }

        /// <summary>總金額</summary>
        public decimal? TotalAmount
        {
            get
            {
                decimal? _totalamount = 0;
                foreach (ShoppingCartItem sci in this)
                {
                    _totalamount += sci.SubTotalPrice;
                }

                return _totalamount;
            }
        }

        /// <summary>總數量</summary>
        public int TotalQuantity
        {
            get
            {
                int _totalqty = 0;
                foreach (ShoppingCartItem sci in this)
                {
                    _totalqty += sci.Quantity;
                }

                return _totalqty;
            }
        }

        /// <summary>移除購物車項目</summary>
        public void Remove(string _projectorid, ShoppingCartItem.ProductType _type)
        {
            ShoppingCartItem _item = Get(_projectorid, _type);
            base.Remove(_item);
        }

        /// <summary>取得購物車項目</summary>
        public ShoppingCartItem Get(string _projectorid, ShoppingCartItem.ProductType _type)
        {
            ShoppingCartItem _item = null;
            foreach (ShoppingCartItem tempitem in this)
            {
                if ((_projectorid == tempitem.ProjectorID) && (_type == tempitem.Type))
                {
                    _item = tempitem;
                }
            }
            return _item;
        }

        /// <summary>檢查產品是否已存在</summary>
        public bool Exists(string _projectorid, ShoppingCartItem.ProductType _type)
        {
            ShoppingCartItem _item = Get(_projectorid, _type);
            return (_item != null);
        }

        /// <summary>加入項目</summary>
        public void Add(string _projectorid, ShoppingCartItem.ProductType _type, int _quantity)
        {
            //取得資料來源
            DataRow row = BLL.GetProductInfo(_projectorid, null);

            //判斷產品類別與名稱
            string strProductNo = "";
            if (_type == ShoppingCartItem.ProductType.LampModule) { strProductNo = Convert.ToString(row["UHR_LM"]); }
            else if (_type == ShoppingCartItem.ProductType.Bulb) { strProductNo = Convert.ToString(row["UHR_BL"]); }

            //設定Shopping Item
            ShoppingCartItem sci = new ShoppingCartItem();
            sci.Type = _type;
            sci.ProjectorID = Convert.ToString(row["ID"]);
            sci.ProductNo = strProductNo;
            sci.Brand = Convert.ToString(row["Brand"]);
            sci.OEMLampModule = Convert.ToString(row["OEM_LM"]);
            sci.ProjectorModel = Convert.ToString(row["ProjectorModel"]);
            sci.Quantity = _quantity;

            this.Add(sci); //加入項目
            UpdatePrice(_projectorid, _type); //更新價格

        }

        /// <summary>更新清單內的價格</summary>
        public void UpdatePrice(string _projectorid, ShoppingCartItem.ProductType _type)
        {
            MemberInfo mi = MemberInfo.Get(); //取得會員登入物件
            ShoppingCartItem sci = Get(_projectorid, _type); //取得購物車項目

            //判斷會員等級
            if (mi.Level == "A" || mi.Level == "B")
            {
                int iQty = (OrderType == "T" ? TotalQuantity : sci.Quantity); //若Type等於TotalOrder，則為總數量

                //取得會員價格
                DataTable dtPrice = BLL.GetMemberPrice(mi.MemberID, OrderType, sci.ProductNo, iQty.ToString());
                if (dtPrice.Rows.Count > 0)
                {
                    //更新幣別與價格
                    sci.Currency = mi.Currency;
                    sci.UnitPrice = Convert.ToDecimal(dtPrice.Rows[0]["Price"]);
                }
                else
                {
                    sci.Currency = null;
                    sci.UnitPrice = null;
                }
            }
            else
            {
                DataRow row = BLL.GetProductInfo(sci.ProjectorID, null); //取得產品資訊

                sci.Currency = "USD"; //預設幣別為美金

                //設為標準定價
                if (sci.Type == ShoppingCartItem.ProductType.LampModule)
                    sci.UnitPrice = Convert.ToDecimal(row["UHR_LM_Price"]);
                else if (sci.Type == ShoppingCartItem.ProductType.Bulb)
                    sci.UnitPrice = Convert.ToDecimal(row["UHR_BL_Price"]);
            }
        }

        /// <summary>取得OrderType物件</summary>
        public OrderTypeBase OrderTypeObject
        {
            get { return _base; }
        }
    }

    /// <summary>購物車項目</summary>
    public class ShoppingCartItem
    {
        public enum ProductType { None = 0, LampModule = 1, Bulb = 2 }

        //變數
        private string _productno = "", _brand = "", _projectormodel = "", _oemlampmodule = "", _projectorid = "", _currency = "", _custompn = "", _customdesc = "";
        private int _quantity = 0;
        private decimal? _unitprice = 0;
        private ProductType _type = ProductType.None;

        public ShoppingCartItem()
        {

        }

        public ProductType Type
        {
            set { _type = value; }
            get { return _type; }
        }

        /// <summary>產品名稱</summary>
        public string ProductNo
        {
            set { _productno = value; }
            get { return _productno; }
        }

        /// <summary>廠牌</summary>
        public string Brand
        {
            set { _brand = value; }
            get { return _brand; }
        }

        /// <summary>Projector ID</summary>
        public string ProjectorID
        {
            set { _projectorid = value; }
            get { return _projectorid; }
        }

        /// <summary>投影機型號</summary>
        public string ProjectorModel
        {
            set { _projectormodel = value; }
            get { return _projectormodel; }
        }

        /// <summary>OEM Lamp Module</summary>
        public string OEMLampModule
        {
            set { _oemlampmodule = value; }
            get { return _oemlampmodule; }
        }

        /// <summary>數量</summary>
        public int Quantity
        {
            set { _quantity = value; }
            get { return _quantity; }
        }

        /// <summary>幣別</summary>
        public string Currency
        {
            set { _currency = value; }
            get { return _currency; }
        }

        /// <summary>客戶品號</summary>
        public string CustomPN
        {
            set { _custompn = value; }
            get { return _custompn; }
        }

        /// <summary>客戶商品描述</summary>
        public string CustomDESC
        {
            set { _customdesc = value; }
            get { return _customdesc; }
        }

        /// <summary>單價</summary>
        public decimal? UnitPrice
        {
            set { _unitprice = value; }
            get { return _unitprice; }
        }

        /// <summary>取得小計</summary>
        public decimal? SubTotalPrice
        {
            get
            {
                decimal? total = null;

                if (UnitPrice != null) total = UnitPrice * Quantity;

                return total;
            }
        }

        /// <summary>轉換ProductType字串</summary>
        public static string GetProductTypeValue(ProductType _type)
        {
            string strType = "";
            if (_type == ProductType.LampModule) { strType = "LM"; }
            else if (_type == ProductType.Bulb) { strType = "BL"; }
            return strType;
        }

        /// <summary>轉換ProductType型別</summary>
        public static ProductType GetProductType(string _type)
        {
            ProductType pt = ProductType.None;
            if (_type == "LM") { pt = ProductType.LampModule; }
            else if (_type == "BL") { pt = ProductType.Bulb; }

            return pt;
        }
    }
}