﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace UHR.OrderType
{
    /// <summary>OrderType基底類別</summary>
    abstract public class OrderTypeBase
    {
        /// <summary>Mail的主旨</summary>
        abstract public string MailSubject
        {
            get;
        }

        /// <summary>Mail的模版</summary>
        abstract public TemplateMail MailTemplate
        {
            get;
        }

        /// <summary>檢查函式</summary>
        abstract public bool CheckData(ref string Message);
    }
}