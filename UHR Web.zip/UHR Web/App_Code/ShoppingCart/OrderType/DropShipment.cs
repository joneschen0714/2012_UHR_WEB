﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace UHR.OrderType
{
    /// <summary>OrderType為DropShipment</summary>
    public class DropShipment : OrderTypeBase
    {
        private MemberInfo mi = MemberInfo.Get();
        private ShoppingCart sc = Definition.ShoppingCart;

        public DropShipment()
        {

        }

        public override string MailSubject
        {
            get { return "Order Confirmation Notice for Drop Shipment!"; }
        }

        public override TemplateMail MailTemplate
        {
            get
            {
                TemplateMail _template = new TemplateMail("~/Source/Html/OrderConfirm_DropShipment.htm");
                return _template;
            }
        }

        public override bool CheckData(ref string Message)
        {
            MemberInfo mi = Definition.MemberInfo; //會員登入物件
            bool result = true;

            //LINQ-合併同產品的數量及價格
            var data = from r in sc
                       group r by r.ProductNo into g
                       select new { PN = g.Key, Qty = g.Sum(a => a.Quantity), TotalPrice = g.Sum(a => a.SubTotalPrice) };

            foreach (var item in data)
            {
                string strMsg = "";

                //檢查是否有價格
                if (item.TotalPrice <= 0)
                {
                    result = false;
                    strMsg = Resources.Lang.L000191;
                }

                //檢查是否有庫存
                int iQty = 0;
                if (mi.ERP_Company == "Arclite") { iQty = BLL.GetProductStockQtyTaiwan(item.PN); }
                else if (mi.ERP_Company == "UHRlamps") { iQty = BLL.GetProductStockQtyAmerica(item.PN); }

                if (iQty - item.Qty < 0)
                {
                    result = false;
                    strMsg += (strMsg == "" ? "" : ",") + Resources.Lang.L000192;
                }

                //累加錯誤訊息
                if (strMsg != "") { Message += item.PN + ":" + strMsg + "<br/>"; }
            }

            if (Message == "")
            {
                //檢查信用額度
                decimal dCreditLimit = BLL.GetCustomCreditLimit(mi.ERP_Company, mi.ERP_CustomCode);
                if (dCreditLimit - sc.TotalAmount < 0)
                {
                    result = false;
                    Message = Resources.Lang.L000193;
                }
            }

            return result;
        }
    }
}