﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace UHR.OrderType
{
    /// <summary>OrderType為一般Order</summary>
    public class NormalOrder : OrderTypeBase
    {
        private MemberInfo mi = MemberInfo.Get();
        private ShoppingCart sc = Definition.ShoppingCart;

        public NormalOrder()
        {

        }

        public override string MailSubject
        {
            get
            {
                return "On-line quotation demand";
            }
        }

        public override TemplateMail MailTemplate
        {
            get
            {
                TemplateMail _template = new TemplateMail("~/Source/Html/OrderConfirm.htm");
                return _template;
            }
        }

        public override bool CheckData(ref string Message)
        {
            return true;
        }
    }
}