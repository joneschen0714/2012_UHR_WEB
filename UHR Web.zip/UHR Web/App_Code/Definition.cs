﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR
{
    public class Definition
    {
        public Definition()
        {

        }

        /// <summary>取得Arclite網站連線字串</summary>
        public static string UHRConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["UHRConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP的Arclite公司別連線字串</summary>
        public static string ERPConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["ERPConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP的UHRLamps公司別連線字串</summary>
        public static string UHRLampsConnStr
        {
            get { return ConfigurationManager.ConnectionStrings["UHRLampsConnStr"].ConnectionString; }
        }

        /// <summary>取得ERP Arclite的DB前置名稱</summary>
        public static string ERPDBName
        {
            get { return ConfigurationManager.AppSettings["ERPDBNAME"]; }
        }

        /// <summary>取得ERP UHRlamps的DB前置名稱</summary>
        public static string UHRlampsDBName
        {
            get { return ConfigurationManager.AppSettings["UHRlampsDBName"]; }
        }





        /// <summary>取得NavigatorList記錄清單</summary>
        public static NameValueCollection NavigatorList
        {
            get
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["NavigatorList"] == null) //若Session無記錄
                {
                    NameValueCollection navList = new NameValueCollection();
                    hss.Add("NavigatorList", navList);
                }
                return (NameValueCollection)hss["NavigatorList"];
            }
        }

        /// <summary>取得與設定會員登入資訊</summary>
        public static MemberInfo MemberInfo
        {
            get
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["MemberInfo"] != null)
                    return (MemberInfo)hss["MemberInfo"];
                else
                    return null;
            }
            set { HttpContext.Current.Session["MemberInfo"] = value; }
        }

        /// <summary>取得與設定購物車集合</summary>
        public static ShoppingCart ShoppingCart
        {
            get
            {
                System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
                if (hss["ShoppingCart"] == null)
                {
                    ShoppingCart = new ShoppingCart();
                }
                return (ShoppingCart)hss["ShoppingCart"];
            }
            set { HttpContext.Current.Session["ShoppingCart"] = value; }
        }

        /// <summary>業務總聯絡窗口</summary>
        public static string ContactSalesMail
        {
            get
            {
                //若有指定的業務聯絡窗口則回傳
                if (MemberInfo.CheckLogin && MemberInfo.ContactSalesMail != "")
                {
                    return MemberInfo.ContactSalesMail;
                }

                return ConfigurationManager.AppSettings["ContactSalesMail"];
            }
        }

        /// <summary>發信人顯示名稱</summary>
        public static string SendMailDisplayName
        {
            get { return ConfigurationManager.AppSettings["SendMailDisplayName"]; }
        }

        /// <summary>發信人信箱地址</summary>
        public static string SendMailFromAddress
        {
            get { return ConfigurationManager.AppSettings["SendMailFromAddress"]; }
        }

        /// <summary>網站管理者清單</summary>
        public static string[] Administrators
        {
            get { return ConfigurationManager.AppSettings["Administrators"].Split(','); }
        }

        /// <summary>美金對台幣匯率</summary>
        public static decimal USD_Currency
        {
            get { return Convert.ToDecimal(ConfigurationManager.AppSettings["USD_Currency"]); }
        }

        /// <summary>取得目前使用語系</summary>
        public static string CultrueLang
        {
            get { return System.Globalization.CultureInfo.CurrentCulture.Name; }
        }
    }
}