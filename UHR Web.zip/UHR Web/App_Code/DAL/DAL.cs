﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Linq;

namespace UHR
{
    public class DAL
    {
        public DAL()
        {

        }

        /// <summary>取得熱門產品資料</summary>
        public static DataTable GetHotProducts()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            db.StrSQL = "SELECT TOP 12 p.ID, b.Brand, a.FileName, COUNT(l.P_ID) [Count], " +
                        "[OEM_LM]=STUFF((SELECT '/' + Convert(Varchar(50),[OEM_LM]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=p.ID) ORDER BY OEM_LM FOR XML PATH('')), 1, 1, '') " +
                        "FROM Log l " +
                        "INNER JOIN Product p ON p.ID=l.P_ID AND p.Enabled=1 " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "INNER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                        "INNER JOIN Attachment a ON a.UHR_LMID=m.ID " +
                        "WHERE l.Type='B' AND m.LM_Status='I' AND a.Enabled=1 AND a.Main='Y' AND DATEDIFF(Day,DateTime,GETDATE())<30 " +
                        "GROUP BY p.ID, b.Brand, a.FileName " +
                        "ORDER BY Count DESC";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得最新一筆News內容</summary>
        public static DataRow GetFirstNews()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Lang", Definition.CultrueLang);

            db.SqlParams = param;
            db.StrSQL = "SELECT TOP 1 ID, Title, Description, EffectiveDate FROM News " +
                        "WHERE (GETDATE() BETWEEN EffectiveDate AND ExpiryDate) AND Type='News' AND Lang IN ('Public', @Lang) " +
                        "ORDER BY EffectiveDate DESC";

            DataTable dtResult = db.ExecuteDataTable();

            DataRow row = null;
            if (dtResult.Rows.Count > 0)
            {
                row = dtResult.Rows[0];
            }
            return row;
        }

        /// <summary>取得所有News內容</summary>
        public static DataTable GetAllNews(string _type, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Lang", Definition.CultrueLang);
            param.Add("Type", _type);

            string strWhere = "";
            if (!string.IsNullOrEmpty(_type)) { strWhere += " AND Type=@Type "; }

            db.SqlParams = param;
            string strSQL = "SELECT ID, Title, SlideContent, EffectiveDate, SlideTimeSpan FROM News " +
                            "WHERE Lang IN ('Public', @Lang) AND (GETDATE() BETWEEN EffectiveDate AND ExpiryDate) " + strWhere;

            DataTable dtResult = db.ExecuteDataTable(strSQL, "EffectiveDate DESC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得指定的News內容</summary>
        public static DataRow GetSingleNews(object _newsid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _newsid);

            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM News WHERE ID=@ID";
            DataRow row = db.ExecuteDataTable().Rows[0];
            return row;
        }

        /// <summary>取得靜態頁面內容</summary>
        public static string GetStaticPageContent(object _Type)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Lang", Definition.CultrueLang);
            param.Add("Type", _Type);

            db.SqlParams = param;
            db.StrSQL = "SELECT Content FROM StaticPage WHERE Type=@Type AND Lang IN ('Public', @Lang)";

            string strResult = db.ExecuteScalar();
            return strResult;
        }

        /// <summary>取得巡覽列名稱</summary>
        public static string GetNavigatorName(string strSQL)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //執行DB
            db.StrSQL = strSQL;
            string strResult = db.ExecuteScalar();

            //回傳資料
            return strResult;
        }

        /// <summary>取得產品List</summary>
        public static DataTable GetProductList(string _keyword, string _oemlm, string _type, string _catalog, string _brand, string _uhrlm, string _class, string _stock)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Keyword", "%" + _keyword + "%");
            param.Add("OEM_LMID", _oemlm);
            param.Add("Type", _type);
            param.Add("CatalogID", _catalog);
            param.Add("BrandID", _brand);
            param.Add("UHR_LMID", _uhrlm);
            param.Add("Class", _class);
            param.Add("Stock", _stock);

            #region 條件式
            string strTable = "";
            string strWhere = "";

            //關鍵字檢索
            if (!string.IsNullOrEmpty(_keyword))
            {
                strTable += "INNER JOIN view_ProductKeyword pk ON pk.ID=p.ID ";
                strWhere += "AND pk.Keyword LIKE @Keyword ";
            }

            //依OEM Lamp Module分類
            if (!string.IsNullOrEmpty(_oemlm))
            {
                strTable += "INNER JOIN LampModuleRelProduct rp ON rp.P_ID=p.ID ";
                strWhere += "AND rp.OEM_LMID=@OEM_LMID ";
            }

            //依UHR Lamp Module前投背投分類
            if (!string.IsNullOrEmpty(_type))
            {
                strWhere += "AND m.LM_Type=@Type ";
            }

            //依Catalog型錄分類
            if (!string.IsNullOrEmpty(_catalog))
            {
                strTable += "INNER JOIN CatalogItem ci ON (ci.UHR_LMID=m.ID) AND (ci.CatalogID=@CatalogID) AND (ci.Enabled=1) ";
            }

            //依廠牌型錄分類
            if (!string.IsNullOrEmpty(_brand))
            {
                strWhere += "AND b.ID=@BrandID ";
            }

            //依UHR Lamp Module分類
            if (!string.IsNullOrEmpty(_uhrlm))
            {
                strWhere += "AND m.ID=@UHR_LMID ";
            }

            //依Product Class分類
            if (!string.IsNullOrEmpty(_class))
            {
                strWhere += "AND m.Class=@Class ";
            }

            //依UHR Lamp Stock分類
            if (!string.IsNullOrEmpty(_stock))
            {
                strWhere += "AND m.LM_Status=@Stock ";
            }
            #endregion

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT p.ID," +
                               "p.ProjectorModel," +
                               "[OEMLampModule]=STUFF((SELECT ',' + Convert(Varchar(50),[OEM_LM]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=p.ID) ORDER BY OEM_LM FOR XML PATH('')), 1, 1, '')," +
                               "p.OEM_LT," +
                               "b.ID [BrandID]," +
                               "b.Brand," +
                               "m.ID [UHR_LMID]," +
                               "m.LM [UHR_LM]," +
                               "m.LM_Status [UHR_LM_Status], " +
                               "m.BL_Status [UHR_BL_Status], " +
                               "m.LM_Type," +
                               "c.Name [LMTypeName]," +
                               "m.Class [LM_Class]," +
                               "a.UHR_LMID [Image] " +
                        "FROM Product p " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "INNER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                        "INNER JOIN Config c ON c.Type='LampType' AND c.Value=m.LM_Type " +
                        "LEFT OUTER JOIN (SELECT UHR_LMID FROM Attachment WHERE Enabled=1 GROUP BY UHR_LMID) a ON a.UHR_LMID=m.ID " +
                        strTable +
                        "WHERE 1=1 AND p.Enabled=1 " + strWhere +
                        "GROUP BY p.ID, p.ProjectorModel, p.OEM_LT, b.ID, b.Brand, m.ID ,m.LM, m.LM_Status, m.BL_Status, m.LM_Type, c.Name, m.Class, a.UHR_LMID";

            DataTable dtResult = db.ExecuteDataTable();

            //回傳資料
            return dtResult;
        }

        /// <summary>取得單筆產品資訊</summary>
        public static DataRow GetProductInfo(string _id, string UHR_LM)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _id);
            param.Add("UHR_LM", UHR_LM);

            string strWhere = "";
            if (!string.IsNullOrEmpty(_id)) { strWhere += " AND p.ID=@ID "; }
            if (!string.IsNullOrEmpty(UHR_LM)) { strWhere += " AND m.LM=@UHR_LM "; }

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT p.ID, b.Brand, p.ProjectorModel, p.OEM_LT, p.ProduceDate, p.UHR_LMID, " +
                            "m.LM [UHR_LM], m.LM_Status [UHR_LM_Status], m.Description [UHR_LM_Desc], m.Class [UHR_LM_Class], m.LM_Price [UHR_LM_Price]," +
                            "m.BL [UHR_BL], m.BL_Status [UHR_BL_Status], m.BL_Price [UHR_BL_Price]," +
                            "[OEM_LM]=STUFF((SELECT '/' + Convert(Varchar(50),[OEM_LM]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=p.ID) ORDER BY OEM_LM FOR XML PATH('')), 1, 1, '') " +
                        "FROM Product p " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "LEFT OUTER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                        "WHERE p.Enabled=1 " + strWhere;
            DataTable dtResult = db.ExecuteDataTable();

            DataRow row = null;
            if (dtResult.Rows.Count > 0)
            {
                row = dtResult.Rows[0];
            }
            return row;
        }

        /// <summary>取得原廠燈Marking</summary>
        public static string GetOEMLampModuleMarking(string ProjectorID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ProjectorID", ProjectorID);

            db.SqlParams = param;
            db.StrSQL = "SELECT STUFF((SELECT '/' + Convert(Varchar(50),[Marking]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=@ProjectorID) GROUP BY b1.Marking FOR XML PATH('')), 1, 1, '')";
            string value = db.ExecuteScalar();
            return value;
        }

        /// <summary>取得相關Projector</summary>
        public static DataTable GetRelatedProjector(string _uhrlmid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("UHR_LMID", _uhrlmid);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT p.ID, b.Brand, p.ProjectorModel " +
                        "FROM Product p " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "INNER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                        "WHERE m.ID=@UHR_LMID AND p.Enabled=1";
            DataTable dtResult = db.ExecuteDataTable();

            return dtResult;
        }

        /// <summary>取得相關OEM Lamp Module</summary>
        public static DataTable GetRelatedOEMLampModule(string _uhrlmid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("UHR_LMID", _uhrlmid);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT o.ID, b.ID BrandID, b.Brand, o.OEM_LM " +
                        "FROM Product p " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "INNER JOIN UHRLampModule m ON m.ID=p.UHR_LMID " +
                        "INNER JOIN LampModuleRelProduct r ON r.P_ID=p.ID " +
                        "INNER JOIN OEMLampModule o ON o.ID=r.OEM_LMID " +
                        "WHERE m.ID=@UHR_LMID AND p.Enabled=1 " +
                        "GROUP BY o.ID, b.ID, b.Brand, o.OEM_LM";
            DataTable dtResult = db.ExecuteDataTable();

            return dtResult;
        }

        /// <summary>取得UHR Lamp Module圖片</summary>
        public static DataTable GetUHR_LampModuleImage(string _uhrlmid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("UHR_LMID", _uhrlmid);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Attachment WHERE UHR_LMID=@UHR_LMID AND Enabled=1 ORDER BY Sort";
            DataTable dtResult = db.ExecuteDataTable();

            return dtResult;
        }

        /// <summary>檢查會員註冊資料</summary>
        public static void CheckMember(string _memberid, string _email, ref string _message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", _memberid);
            param.Add("Email", _email);

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(_email)) { strWhere += " AND Email=@Email "; }
            if (!string.IsNullOrEmpty(_memberid)) { strWhere += " AND ID <> @MemberID "; }

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "DECLARE @message varchar(max); " +
                        "SET @message = ''; " +
                        "IF Exists(SELECT ID FROM Member WHERE 1=1 " + strWhere + ") BEGIN " +
                            "SET @message = 'this email is already in use.'; " +
                        "END " +
                        "SELECT @message; ";
            _message = db.ExecuteScalar();
        }

        /// <summary>會員註冊</summary>
        public static void RegisterMember(string _password, string _email, string _name, string _tel, string _address, string _company, string _sex, string _country)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Password", _password);
            param.Add("Email", _email);
            param.Add("Name", _name);
            param.Add("Tel", _tel);
            param.Add("Address", _address);
            param.Add("Company", _company);
            param.Add("Sex", _sex);
            param.Add("Country", _country);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "INSERT Member(Password, Email, Name, Tel, Address, Company, Sex, Country, Enabled, CreateDate, UpdatePwdDate) VALUES(@Password, @Email, @Name, @Tel, @Address, @Company, @Sex, @Country, 1, GetDate(), GetDate())";
            db.ExecuteSQL();
        }

        /// <summary>登入驗証</summary>
        public static DataTable MemberLogin(string _email, string _password)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Email", _email);
            param.Add("Password", _password);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Member WHERE Email=@Email AND Password=@Password AND Enabled=1";
            return db.ExecuteDataTable();
        }

        /// <summary>以Email取得會員資料</summary>
        public static DataTable EmailGetMember(string _email)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Email", _email);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Member WHERE Email=@Email AND Enabled=1";
            return db.ExecuteDataTable();
        }

        /// <summary>以會員ID取得會員資料</summary>
        public static DataTable GetMemberInfo(string _memberid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", _memberid);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Member WHERE ID=@MemberID";
            return db.ExecuteDataTable();
        }

        /// <summary>取得Promotion List資料</summary>
        public static DataTable GetPromotionList()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //執行DB
            db.StrSQL = "SELECT * FROM Catalog WHERE (GETDATE() BETWEEN EffectiveDate AND ExpiryDate) AND (ShowInList=1)";
            return db.ExecuteDataTable();
        }

        /// <summary>取得Catalog Description資料</summary>
        public static string GetCatalogDescription(string _catalogid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", _catalogid);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT Description FROM Catalog WHERE ID=@ID";
            return db.ExecuteScalar();
        }

        /// <summary>取得Quick Order資料</summary>
        public static DataTable GetQuickOrderData(string _keyword)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Keyword", _keyword);

            //執行DB
            db.SqlParams = param;
            db.StrSQL = "SELECT p.ID," +
                               "b.Brand," +
                               "p.ProjectorModel," +
                               "[OEMLampModule]=STUFF((SELECT '/' + Convert(Varchar(50),[OEM_LM]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=p.ID) ORDER BY OEM_LM FOR XML PATH('')), 1, 1, '')," +
                               "ulm.ID [UHR_LMID]," +
                               "ulm.LM [UHR_LM]," +
                               "ulm.BL [UHR_BL], " +
                               "ulm.LM_Status [UHR_LM_Status], " +
                               "ulm.BL_Status [UHR_BL_Status] " +
                        "FROM Product p " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "INNER JOIN LampModuleRelProduct lmr ON (lmr.P_ID=p.ID) " +
                        "INNER JOIN OEMLampModule olm ON (olm.ID=lmr.OEM_LMID) " +
                        "LEFT OUTER JOIN UHRLampModule ulm ON (ulm.ID=p.UHR_LMID) " +
                        "WHERE ((p.ProjectorModel=@Keyword) OR (olm.OEM_LM=@Keyword) OR (ulm.LM=@Keyword)) AND p.Enabled=1 " +
                        "GROUP BY p.ID, b.Brand, p.ProjectorModel, ulm.ID, ulm.LM, ulm.BL, ulm.LM_Status, ulm.BL_Status";
            return db.ExecuteDataTable();
        }

        /// <summary>新增項目至WishList</summary>
        public static void AddWishList(object _memberid, object _projectorid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", _memberid);
            param.Add("ProjectorID", _projectorid);

            db.SqlParams = param;
            db.StrSQL = "INSERT WishList(Member_ID, P_ID, CreateDate) VALUES(@MemberID, @ProjectorID, GETDATE())";
            db.ExecuteSQL();
        }

        /// <summary>檢查WishList項目是否衝突</summary>
        public static bool WishListExists(object _memberid, object _projectorid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", _memberid);
            param.Add("ProjectorID", _projectorid);

            db.SqlParams = param;
            db.StrSQL = "SELECT COUNT(*) FROM WishList WHERE (Member_ID=@MemberID) AND (P_ID=@ProjectorID)";
            string strResult = db.ExecuteScalar();
            return (strResult != "0");
        }

        /// <summary>取得WishList清單資料</summary>
        public static DataTable GetWishListData(string _memberid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", _memberid);

            db.SqlParams = param;
            db.StrSQL = "SELECT wl.ID [WishListID], p.ID, b.Brand, p.ProjectorModel, p.OEM_LT, " +
                            "[OEMLampModule]=STUFF((SELECT '/' + Convert(Varchar(50),[OEM_LM]) FROM LampModuleRelProduct a1,OEMLampModule b1 WHERE (a1.OEM_LMID=b1.ID) AND (a1.P_ID=p.ID) ORDER BY OEM_LM FOR XML PATH('')), 1, 1, '') " +
                        "FROM WishList wl " +
                        "INNER JOIN Product p ON (p.ID=wl.P_ID) " +
                        "INNER JOIN Brand b ON (b.ID=p.BrandID) " +
                        "WHERE (wl.Member_ID=@MemberID) AND p.Enabled=1";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>移除WishList項目</summary>
        public static void RemoveWishListItem(string _wishlistid)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("WishListID", _wishlistid);

            db.SqlParams = param;
            db.StrSQL = "DELETE FROM WishList WHERE ID=@WishListID";
            db.ExecuteSQL();
        }

        /// <summary>新增詢價記錄</summary>
        public static bool AddOrder(string _memberid, string _ordernum, string _type, string _attn, string _po, string _tel, string _shipaddress, string _billaddress, string _comment, string _attachment, string _emailcc, ShoppingCart _sc)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //設定交易
            SqlCommand cmd = db.SqlCommand;
            db.CloseDatabaseState("Y");
            SqlTransaction trans = db.SetTransaction(cmd);

            bool bResult = false;
            try
            {
                //增加表頭
                cmd.Parameters.Add(new SqlParameter("MemberID", _memberid));
                cmd.Parameters.Add(new SqlParameter("OrderNum", _ordernum));
                cmd.Parameters.Add(new SqlParameter("Type", _type));
                cmd.Parameters.Add(new SqlParameter("Attn", _attn));
                cmd.Parameters.Add(new SqlParameter("PO", _po));
                cmd.Parameters.Add(new SqlParameter("Tel", _tel));
                cmd.Parameters.Add(new SqlParameter("ShippingAddress", _shipaddress));
                cmd.Parameters.Add(new SqlParameter("BillingAddress", _billaddress));
                cmd.Parameters.Add(new SqlParameter("Comment", _comment));
                cmd.Parameters.Add(new SqlParameter("Attachment", _attachment));
                cmd.Parameters.Add(new SqlParameter("EmailCC", _emailcc));
                cmd.CommandText = "INSERT [Order](Member_ID, OrderNum, Type, Attn, PO, Tel, ShippingAddress, BillingAddress, Comment, Attachment, Email_cc, Date) VALUES(@MemberID, @OrderNum, @Type, @Attn, @PO, @Tel, @ShippingAddress, @BillingAddress, @Comment, @Attachment, @EmailCC, GETDATE()); SELECT @@IDENTITY";

                string strOrderID = Convert.ToString(cmd.ExecuteScalar()); //新增後取得OrderID

                //循序增加Order Items
                foreach (ShoppingCartItem sci in _sc)
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("OrderID", strOrderID));
                    cmd.Parameters.Add(new SqlParameter("P_ID", sci.ProjectorID));
                    cmd.Parameters.Add(new SqlParameter("ProductNo", sci.ProductNo));
                    cmd.Parameters.Add(new SqlParameter("Type", ShoppingCartItem.GetProductTypeValue(sci.Type)));
                    cmd.Parameters.Add(new SqlParameter("CustomPN", sci.CustomPN));
                    cmd.Parameters.Add(new SqlParameter("CustomDesc", sci.CustomDESC));
                    cmd.Parameters.Add(new SqlParameter("Quantity", sci.Quantity));
                    cmd.Parameters.Add(new SqlParameter("Currency", Tool.GetDBNullString(sci.Currency)));
                    cmd.Parameters.Add(new SqlParameter("UnitPrice", Tool.GetDBNullString(sci.UnitPrice)));
                    cmd.Parameters.Add(new SqlParameter("SubTotal", Tool.GetDBNullString(sci.SubTotalPrice)));
                    cmd.CommandText = "INSERT OrderItem(Order_ID, P_ID, ProductNo, Type, CustomPN, CustomDesc, Quantity, Currency, UnitPrice, SubTotal) VALUES(@OrderID, @P_ID, @ProductNo, @Type, @CustomPN, @CustomDesc, @Quantity, @Currency, @UnitPrice, @SubTotal);";
                    cmd.ExecuteNonQuery();
                }

                trans.Commit();
                bResult = true;
            }
            catch
            {
                trans.Rollback();
                bResult = false;
            }

            db.CloseDatabaseState("N");
            return bResult;
        }

        /// <summary>訂單匯入</summary>
        public static bool ImportOrderList(string OrderType, DataTable dt, ref string Message)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //設定交易
            SqlCommand cmd = db.SqlCommand;
            db.CloseDatabaseState("Y");
            SqlTransaction trans = db.SetTransaction(cmd);

            bool bResult = false;
            try
            {
                //取得會員資料
                MemberInfo mi = Definition.MemberInfo;
                DataTable dtMemberInfo = BLL.GetMemberInfo(mi.MemberID);

                var g = from t in dt.AsEnumerable()
                        group t by new
                        {
                            ShippingAddress = t["Shipping Address"],
                            Recipient = t["Recipient/Company"],
                            ContactTel = t["Contact Tel"],
                            PO = t["PO NO#"],
                            Remark = t["Remark"]
                        };

                string strNewOrderNumber = "";
                foreach (var gp in g)
                {
                    //新訂單號碼
                    if (strNewOrderNumber == "")
                    {
                        strNewOrderNumber = BLL.GetNewOrderNumber();
                    }
                    else
                    {
                        int iCount = strNewOrderNumber.Length;
                        string strNumber = strNewOrderNumber.Substring(iCount - 4, 4);
                        strNumber = Tool.GetPadLeftString(strNumber, 1);
                        strNewOrderNumber = strNewOrderNumber.Substring(0, iCount - 4) + strNumber;
                    }

                    //循序把訂單號碼回存至DataTable
                    string str1 = "[Shipping Address]='{0}' AND [Recipient/Company]='{1}' AND [Contact Tel]='{2}' AND [PO NO#]='{3}' AND [Remark]='{4}'";
                    str1 = string.Format(str1, gp.Key.ShippingAddress.ToString().Replace("'", "''"), gp.Key.Recipient.ToString().Replace("'", "''"), gp.Key.ContactTel, gp.Key.PO, gp.Key.Remark.ToString().Replace("'", "''"));
                    DataRow[] rows = dt.Select(str1);
                    foreach (DataRow row in rows)
                    {
                        row["OrderNumber"] = strNewOrderNumber;
                    }

                    //增加表頭
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("MemberID", mi.MemberID));
                    cmd.Parameters.Add(new SqlParameter("OrderNum", strNewOrderNumber));
                    cmd.Parameters.Add(new SqlParameter("Type", OrderType));
                    cmd.Parameters.Add(new SqlParameter("Attn", gp.Key.Recipient));
                    cmd.Parameters.Add(new SqlParameter("PO", gp.Key.PO));
                    cmd.Parameters.Add(new SqlParameter("Tel", gp.Key.ContactTel));
                    cmd.Parameters.Add(new SqlParameter("ShippingAddress", gp.Key.ShippingAddress));
                    cmd.Parameters.Add(new SqlParameter("BillingAddress", dtMemberInfo.Rows[0]["Address"]));
                    cmd.Parameters.Add(new SqlParameter("Comment", Tool.GetValue(gp.Key.Remark, "")));
                    cmd.Parameters.Add(new SqlParameter("Attachment", ""));
                    cmd.CommandText = "INSERT [Order](Member_ID, OrderNum, Type, Attn, PO, Tel, ShippingAddress, BillingAddress, Comment, Attachment, Date) VALUES(@MemberID, @OrderNum, @Type, @Attn, @PO, @Tel, @ShippingAddress, @BillingAddress, @Comment, @Attachment, GETDATE()); SELECT @@IDENTITY";

                    string strOrderID = Convert.ToString(cmd.ExecuteScalar()); //新增後取得OrderID

                    foreach (var item in gp)
                    {
                        //單身資料
                        string ProductNo = item["UHR P/N"].ToString();
                        DataRow rowProductInfo = BLL.GetProductInfo(null, ProductNo);

                        cmd.Parameters.Clear();
                        cmd.Parameters.Add(new SqlParameter("OrderID", strOrderID));
                        cmd.Parameters.Add(new SqlParameter("P_ID", rowProductInfo["ID"]));
                        cmd.Parameters.Add(new SqlParameter("ProductNo", ProductNo));
                        cmd.Parameters.Add(new SqlParameter("Type", "LM"));
                        cmd.Parameters.Add(new SqlParameter("CustomPN", item["Customer P/N"]));
                        cmd.Parameters.Add(new SqlParameter("CustomDesc", item["Product Description"]));
                        cmd.Parameters.Add(new SqlParameter("Quantity", item["Quantity"]));
                        cmd.Parameters.Add(new SqlParameter("Currency", mi.Currency));
                        cmd.Parameters.Add(new SqlParameter("UnitPrice", item["UnitPrice"]));
                        cmd.Parameters.Add(new SqlParameter("SubTotal", item["SubTotal"]));
                        cmd.CommandText = "INSERT OrderItem(Order_ID, P_ID, ProductNo, Type, CustomPN, CustomDesc, Quantity, Currency, UnitPrice, SubTotal) VALUES(@OrderID, @P_ID, @ProductNo, @Type, @CustomPN, @CustomDesc, @Quantity, @Currency, @UnitPrice, @SubTotal);";
                        cmd.ExecuteNonQuery();
                    }
                }

                trans.Commit();
                bResult = true;
            }
            catch (Exception e)
            {
                trans.Rollback();
                bResult = false;
                Message = e.Message;
            }

            db.CloseDatabaseState("N");
            return bResult;
        }

        /// <summary>取得對應的最後一張訂單編號</summary>
        public static string GetNewOrderNumber(string _ordernum)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderNum", _ordernum + "%");

            db.SqlParams = param;
            db.StrSQL = "SELECT TOP 1 OrderNum FROM [Order] WHERE OrderNum LIKE @OrderNum ORDER BY OrderNum DESC";

            return db.ExecuteScalar();
        }

        /// <summary>取得最後一筆詢價單記錄</summary>
        public static DataRow GetLastOrder(string MemberID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);

            db.SqlParams = param;
            db.StrSQL = "SELECT TOP 1 * FROM [Order] WHERE Member_ID=@MemberID ORDER BY Date DESC";

            DataTable dtResult = db.ExecuteDataTable();

            DataRow row = null;
            if (dtResult.Rows.Count > 0)
            {
                row = dtResult.Rows[0];
            }
            return row;
        }

        /// <summary>取得Projector販售清單</summary>
        public static DataTable GetProjectorSell()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            db.StrSQL = "SELECT b.Brand, p.ProjectorModel, ps.Quantity, ps.Price, ps.Status, ps.Description, ps.ImgFile " +
                        "FROM ProjectorSell ps " +
                        "INNER JOIN Product p ON (p.ID=ps.P_ID) " +
                        "INNER JOIN Brand b ON b.ID=p.BrandID " +
                        "WHERE (ps.Enabled=1)";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得RMA原因代號資料</summary>
        public static DataTable GetRmaReason()
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            db.StrSQL = "SELECT * FROM RMAReasonCode";

            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>新增RMA單資料</summary>
        public static bool AddRMAForm(string _type, string _description, string _item, MemberInfo _mi)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //設定交易
            SqlCommand cmd = db.SqlCommand;
            db.CloseDatabaseState("Y");
            SqlTransaction trans = db.SetTransaction(cmd);

            bool bResult = false;
            try
            {
                //增加表頭
                cmd.Parameters.Add(new SqlParameter("Type", _type));
                cmd.Parameters.Add(new SqlParameter("Description", _description));
                cmd.Parameters.Add(new SqlParameter("MemberID", _mi.MemberID));
                cmd.CommandText = "INSERT [RMAForm](Date, Type, Member_ID, Description) VALUES(GETDATE(), @Type, @MemberID, @Description); SELECT @@IDENTITY";

                string strFormID = Convert.ToString(cmd.ExecuteScalar()); //新增後取得FormID

                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(_item);
                foreach (XmlNode node in xmlDoc.SelectNodes("items/item"))
                {
                    cmd.Parameters.Clear();
                    cmd.Parameters.Add(new SqlParameter("FormID", strFormID));
                    cmd.Parameters.Add(new SqlParameter("ProductNo", node.Attributes["pn"].Value));
                    cmd.Parameters.Add(new SqlParameter("SerialNo", node.Attributes["sn"].Value));
                    cmd.Parameters.Add(new SqlParameter("ReasonCode", node.Attributes["code"].Value));
                    cmd.CommandText = "INSERT RMAFormItem(FormID, ProductNo, SerialNo, ReasonCode) VALUES(@FormID, @ProductNo, @SerialNo, @ReasonCode);";
                    cmd.ExecuteNonQuery();
                }

                trans.Commit();
                bResult = true;
            }
            catch
            {
                trans.Rollback();
                bResult = false;
            }

            db.CloseDatabaseState("N");
            return bResult;
        }

        /// <summary>更新會員資料</summary>
        public static void UpdateMemberInfo(string _memberid, string _password, string _email, string _name, string _tel, string _address, string _company, string _sex, string _country)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", _memberid);
            param.Add("Password", _password);
            param.Add("Email", _email);
            param.Add("Name", _name);
            param.Add("Tel", _tel);
            param.Add("Address", _address);
            param.Add("Company", _company);
            param.Add("Sex", _sex);
            param.Add("Country", _country);

            db.SqlParams = param;
            db.StrSQL = "IF NOT EXISTS(SELECT * FROM Member WHERE ID=@MemberID AND Password=@Password) BEGIN " +
                            "UPDATE Member SET UpdatePwdDate=GetDate() WHERE ID=@MemberID; " +
                        "END " +
                        "UPDATE Member SET Password=@Password, Email=@Email, Name=@Name, Tel=@Tel, Address=@Address, Company=@Company, Sex=@Sex, Country=@Country WHERE ID=@MemberID; ";

            db.ExecuteSQL();
        }

        /// <summary>更新會員的登入時間</summary>
        public static void UpdateMemberLoginDate(string MemberID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            db.SqlParams = param;

            db.StrSQL = "UPDATE Member SET LoginDate=getdate() WHERE ID=@MemberID";

            db.ExecuteSQL();
        }

        /// <summary>取得國家清單</summary>
        public static DataTable GetCountryList(string _code)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Code", _code);

            string strWhere = "";
            if (!string.IsNullOrEmpty(_code)) { strWhere += " AND Code=@Code "; }

            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Country WHERE 1=1 " + strWhere + " ORDER BY Name";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得品牌名稱</summary>
        public static string GetBrandName(string BrandID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("BrandID", BrandID);

            db.SqlParams = param;
            db.StrSQL = "SELECT Brand FROM Brand WHERE ID=@BrandID";
            string value = db.ExecuteScalar();
            return value;
        }

        /// <summary>取得OEM Lamp Module名稱</summary>
        public static string GetOEMLampModuleName(string LampModuleID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("LampModuleID", LampModuleID);

            db.SqlParams = param;
            db.StrSQL = "SELECT OEM_LM FROM OEMLampModule WHERE ID=@LampModuleID";
            string value = db.ExecuteScalar();
            return value;
        }

        /// <summary>取得Config定義表的對應顯示名稱</summary>
        public static string GetConfigName(string Type, string Value)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", Type);
            param.Add("Value", Value);

            db.SqlParams = param;
            db.StrSQL = "SELECT Name FROM Config WHERE Type=@Type AND Value=@Value";
            string value = db.ExecuteScalar();
            return value;
        }

        /// <summary>取得Config定義表的資料</summary>
        public static DataTable GetConfigData(string Type)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Type", Type);

            db.SqlParams = param;
            db.StrSQL = "SELECT * FROM Config WHERE Type=@Type";
            DataTable dtResult = db.ExecuteDataTable();
            return dtResult;
        }

        /// <summary>取得UHR Lamp Module品名</summary>
        public static string GetUHRLampModuleName(string UHRLMID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", UHRLMID);

            db.SqlParams = param;
            db.StrSQL = "SELECT LM FROM UHRLampModule WHERE ID=@ID";
            string value = db.ExecuteScalar();
            return value;
        }

        /// <summary>取得OEM Lamp Module清單</summary>
        public static DataTable GetOEMLampModuleByProjector(string ProjectorIDArray)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            db.StrSQL = "SELECT DISTINCT m.ID, m.OEM_LM FROM OEMLampModule m, LampModuleRelProduct r WHERE r.OEM_LMID=m.ID AND r.P_ID IN (" + ProjectorIDArray + ") ORDER BY m.OEM_LM";
            DataTable dt = db.ExecuteDataTable();
            return dt;
        }

        /// <summary>增加產品瀏覽Log</summary>
        public static void InsertProductBrowseLog(string PID, string MemberID, string IP)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("PID", PID);
            param.Add("MemberID", Tool.GetDBNullString(MemberID));
            param.Add("IP", IP);
            db.SqlParams = param;

            //若同來源沒瀏覽過此產品，則新增記錄
            db.StrSQL = "IF NOT EXISTS (SELECT * FROM Log WHERE Type='B' AND P_ID=@PID AND IP=@IP AND DATEDIFF(day, GETDATE(), DateTime)=0) BEGIN " +
                            "INSERT Log(Type, P_ID, Member_ID, DateTime, IP) VALUES('B', @PID, @MemberID, getdate(), @IP); " +
                        "END";
            db.ExecuteSQL();
        }

        /// <summary>增加關鍵字Log</summary>
        public static void InsertKeywordLog(string Keyword, string MemberID, string IP)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("Keyword", Keyword);
            param.Add("MemberID", Tool.GetDBNullString(MemberID));
            param.Add("IP", IP);
            db.SqlParams = param;

            //若同來源沒瀏覽過此產品，則新增記錄
            db.StrSQL = "IF NOT EXISTS (SELECT * FROM Log WHERE Type='K' AND Keyword=@Keyword AND IP=@IP AND DATEDIFF(day, GETDATE(), DateTime)=0) BEGIN " +
                            "INSERT Log(Type, Keyword, Member_ID, DateTime, IP) VALUES('K', @Keyword, @MemberID, getdate(), @IP); " +
                        "END";
            db.ExecuteSQL();
        }

        /// <summary>取得廠牌的資料清單</summary>
        public static DataTable GetBrandList(string BrandIDArray)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            db.StrSQL = "SELECT * FROM Brand WHERE ID IN(" + BrandIDArray + ") ORDER BY Brand";
            DataTable dt = db.ExecuteDataTable();
            return dt;
        }

        /// <summary>新增FAQ</summary>
        public static void InsertFAQ(string c_ID, string MemberID, string Type, string Subject, string Contents)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("c_ID", Tool.GetDBNullString(c_ID));
            param.Add("MemberID", MemberID);
            param.Add("Type", Tool.GetDBNullString(Type));
            param.Add("Subject", Subject);
            param.Add("Contents", Contents);
            db.SqlParams = param;

            db.StrSQL = "INSERT FAQ(c_ID, Member_ID, Type, Subject, Contents, UpdateTime) VALUES(@c_ID, @MemberID, @Type, @Subject, @Contents, getdate())";
            db.ExecuteSQL();
        }

        /// <summary>取得FAQ List</summary>
        public static DataTable GetFAQList(string MemberID, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            db.SqlParams = param;

            //SQL
            string strSQL = "SELECT q.ID, q.Type, q.Subject, q.UpdateTime, m.Name, COUNT(q1.ID) ReplyCount " +
                            "FROM FAQ q " +
                            "INNER JOIN Member m ON m.ID=q.Member_ID " +
                            "LEFT OUTER JOIN FAQ q1 ON q1.c_ID = q.ID " +
                            "WHERE q.Member_ID=@MemberID AND q.c_ID IS NULL " +
                            "GROUP BY q.ID, q.Type, q.Subject, q.UpdateTime, m.Name";

            //分頁
            DataTable dtResult = db.ExecuteDataTable(strSQL, "UpdateTime DESC", _pageindex, _pagesize, out _recordcount);
            return dtResult;
        }

        /// <summary>取得FAQ List</summary>
        public static DataTable GetFAQDetail(string ID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            db.SqlParams = param;

            //SQL
            db.StrSQL = "SELECT q.*, m.Name FROM FAQ q " +
                        "INNER JOIN Member m ON m.ID=q.Member_ID " +
                        "WHERE q.ID=@ID OR q.c_ID=@ID";

            return db.ExecuteDataTable();
        }

        /// <summary>取得產品的庫存數量(美國)</summary>
        public static int GetProductStockQtyAmerica(string PartName)
        {
            //物件初始化
            Company c = CompanyCollection.Get("UHRlamps");
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("PartName", PartName);
            db.SqlParams = param;

            //庫存量 減 訂單未出數量 減 借入未還數量 減 網站未轉訂單 (同品名加總)
            db.StrSQL = "SELECT SUM(ISNULL(MC007,0)) - SUM(ISNULL(a.Qty,0)) - SUM(ISNULL(b.Qty,0)) - SUM(ISNULL(c.Qty,0)) " +
                        "FROM {DBName}INVMB " +
                        "LEFT OUTER JOIN {DBName}INVMC ON (MC002='4A01') AND (MB001=MC001) " +
                        "LEFT OUTER JOIN (SELECT TD004, SUM(TD008-TD009) [Qty] FROM {DBName}COPTD WHERE (TD007='4A01') AND (TD016='N') AND (TD021<>'V') GROUP BY TD004) a ON (TD004=MB001) " +
                        "LEFT OUTER JOIN (SELECT TG004, SUM(TG009-TG021) [Qty] FROM {DBName}INVTG WHERE TG001='1401' AND (TG022 IN ('Y')) AND (TG024='N') GROUP BY TG004) b ON (TG004=MB001) " +
                        "LEFT OUTER JOIN (SELECT ProductNo, SUM(Quantity) [Qty] FROM [Order] o " +
                                         "INNER JOIN [OrderItem] oi ON o.ID=oi.Order_ID " +
                                         "INNER JOIN Member m ON m.ID=o.Member_ID " +
                                         "LEFT OUTER JOIN (SELECT TB012 FROM " + Definition.ERPDBName + "COPTB UNION SELECT TB012 FROM " + Definition.UHRlampsDBName + "COPTB) b ON o.OrderNum=b.TB012 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                                         "WHERE (ERP_Company='UHRlamps') AND (m.Level<>'') AND (o.Date >= '2013/7/1') AND (o.Cancel IS NULL OR o.Cancel <> 'Y') AND (b.TB012 IS NULL) " +
                                         "GROUP BY ProductNo) c ON c.ProductNo=MB002 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                        "WHERE (MB002=@PartName)";

            db.StrSQL = db.StrSQL.Replace("{DBName}", c.DBName);

            /*
            //庫存量 減 訂單未出數量 減 借入未還數量 (同品名加總)
            //SQL
            db.StrSQL = "SELECT SUM(MC007) - SUM(ISNULL(a.Qty,0)) - SUM(ISNULL(b.Qty,0)) [庫存數量] FROM INVMC " +
                        "INNER JOIN INVMB ON (MB001=MC001) " +
                        "LEFT OUTER JOIN (SELECT TD004, SUM(TD008-TD009) [Qty] FROM COPTD WHERE (TD001 IN ('2210','2230')) AND (TD016='N') AND (TD021<>'V') GROUP BY TD004) a ON (TD004=MC001) " +
                        "LEFT OUTER JOIN (SELECT TG004, SUM(TG009-TG021) [Qty] FROM INVTG WHERE TG001='1401' AND (TG022 IN ('Y','N')) AND (TG024='N') GROUP BY TG004) b ON (TG004=MC001) " +
                        "WHERE (MB002=@PartName) AND (MC002='4A01')";
            */

            decimal i;
            decimal.TryParse(db.ExecuteScalar(), out i);

            return Convert.ToInt32(i);
        }

        /// <summary>取得產品的庫存數量(台灣)</summary>
        public static int GetProductStockQtyTaiwan(string PartName)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.ERPConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("PartName", PartName);
            db.SqlParams = param;

            //庫存量減訂單未出數量
            //SQL
            db.StrSQL = "SELECT ISNULL(MC007,0) - SUM(TD008 - TD009) [庫存數量] FROM INVMB " +
                        "LEFT OUTER JOIN INVMC ON (MB001=MC001) AND (MC002 IN ('3101','4101','5101','9101')) " +
                        "LEFT OUTER JOIN COPTD ON (TD004=MB001) AND (TD016='N') AND (TD021<>'V') " +
                        "WHERE (MB002=@PartName)  " +
                        "GROUP BY MC007";

            decimal i;
            decimal.TryParse(db.ExecuteScalar(), out i);

            return Convert.ToInt32(i);
        }

        /// <summary>取得會員的價格表定義</summary>
        public static DataTable GetMemberPriceTitle(string MemberID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            db.SqlParams = param;

            //取得價格定義表
            db.StrSQL = "SELECT Value, Name FROM PriceTitle t, Config c " +
                        "WHERE t.Member_ID=@MemberID AND t.Type=c.Value AND c.Type='OrderType' " +
                        "GROUP BY c.Value, c.Name " +
                        "ORDER BY Name";

            return db.ExecuteDataTable();
        }

        /// <summary>取得會員的價格表</summary>
        public static DataTable GetMemberPrice(string MemberID, string OrderType, string Product, string Qty)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            param.Add("OrderType", OrderType);
            param.Add("Product", Product);
            param.Add("Qty", Qty);
            db.SqlParams = param;

            //取得價格定義表
            db.StrSQL = "SELECT t.*, c.Name [TypeName] FROM PriceTitle t " +
                        "INNER JOIN Config c ON t.Type=c.Value AND c.Type='OrderType' " +
                        "WHERE t.Member_ID=@MemberID " +
                        "ORDER BY Sort";
            DataTable dtField = db.ExecuteDataTable();
            dtField.Columns.Add("Price", Type.GetType("System.Decimal")); //增加Price欄位
            DataTable dtNewField = dtField.Clone(); //複製定義表結構

            //取得價格表
            db.StrSQL = "SELECT ProductName, PriceXml FROM PriceList WHERE Member_ID=@MemberID AND ProductName=@Product";
            DataTable dtPrice = db.ExecuteDataTable();

            if (dtPrice.Rows.Count > 0)
            {
                //讀取XML節點
                XmlDocument xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(dtPrice.Rows[0]["PriceXml"].ToString());
                XmlNodeList nodeList = xmlDoc.SelectNodes("//Item");

                //依序讀取節點值
                foreach (XmlNode node in nodeList)
                {
                    string strTitle = node.Attributes["Title"].Value;
                    DataRow row = dtField.Select("Title='" + strTitle + "'")[0];
                    row["Price"] = node.InnerText;

                    dtNewField.Rows.Add(row.ItemArray);
                }
            }

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(OrderType)) { strWhere += " AND Type='" + OrderType + "' "; }
            if (!string.IsNullOrEmpty(Qty)) { strWhere += string.Format(" AND {0} >= ISNULL(StartQty, {0}) AND {0} <= ISNULL(EndQty, {0})", Qty); }

            dtNewField.DefaultView.RowFilter = "1=1 " + strWhere;
            return dtNewField.DefaultView.ToTable();
        }

        /// <summary>取得會員購物車的OrderType清單</summary>
        public static DataTable GetpProductOrderType(string MemberID, string[] ProductList)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            db.SqlParams = param;

            //條件式
            string strWhere = "", strCon1 = "";
            foreach (string p in ProductList) { strCon1 += string.Format(",'{0}'", p); }
            if (!string.IsNullOrEmpty(strCon1)) { strWhere += " AND ProductName IN (" + strCon1.TrimStart(',') + ") "; }

            //SQL
            db.StrSQL = "SELECT DISTINCT c.Value, c.Name " +
                        "FROM PriceList p " +
                        "INNER JOIN Config c ON c.Type='OrderType' AND c.Value=p.OrderType " +
                        "WHERE Member_ID=@MemberID " + strWhere +
                        "ORDER BY Name";

            return db.ExecuteDataTable();
        }

        /// <summary>取得ERP對應的客戶品號資料</summary>
        public static DataTable GetERPCustomPN(string ERPCompany, string CustomCode, string ProductName)
        {
            //物件初始化
            Company c = CompanyCollection.Get(ERPCompany);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("CustomCode", CustomCode);
            param.Add("ProductName", ProductName);
            db.SqlParams = param;

            db.StrSQL = "SELECT MG003 [CustomPN], MG004 [CustomDESC] FROM COPMG " +
                        "INNER JOIN INVMB ON MG002=MB001 " +
                        "WHERE MG001=@CustomCode AND MB002=@ProductName " +
                        "ORDER BY MG003";

            return db.ExecuteDataTable();
        }

        /// <summary>取得ERP對應的客戶基本資料</summary>
        public static DataRow GetERPMemerProfile(string ERPCompany, string CustomCode)
        {
            //物件初始化
            Company c = CompanyCollection.Get(ERPCompany);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("CustomCode", CustomCode);
            db.SqlParams = param;

            db.StrSQL = "SELECT MA005 [Attn], MA006 [Tel], MA025 [BillAddr], MA027 [ShippAddr] FROM COPMA " +
                        "WHERE MA001=@CustomCode";
            DataTable dtResult = db.ExecuteDataTable();

            DataRow row = null;
            if (dtResult.Rows.Count > 0)
            {
                row = dtResult.Rows[0];
            }
            return row;
        }

        /// <summary>取得ERP對應的客戶信用額度</summary>
        public static decimal GetCustomCreditLimit(string ERPCompany, string CustomCode)
        {
            //物件初始化
            Company c = CompanyCollection.Get(ERPCompany);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("CustomCode", CustomCode);
            db.SqlParams = param;

            db.StrSQL = "DECLARE @Total decimal(21,6), @a1 decimal(21,6), @a2 decimal(21,6), @a3 decimal(21,6), @a4 decimal(21,6);" +

                        //未結帳銷貨、銷退
                        "SET @a1 = (SELECT SUM(原幣合計) FROM ( " +
                                        "SELECT (TG013 + TG025) [原幣合計], TG001, TG002, TG004, TG023 FROM COPTG " +
                                        "UNION ALL " +
                                        "SELECT (TI010 + TI011) [原幣合計], TI001, TI002, TI004, TI019 FROM COPTI " +
                                   ") r " +
                                   "LEFT OUTER JOIN (SELECT TB005, TB006 FROM ACRTB WHERE TB012='Y') a ON a.TB005=TG001 AND a.TB006=TG002 " +
                                   "WHERE TG004=@CustomCode AND TG023='Y' AND a.TB005 IS NULL); " +

                        //應收帳款(本幣)
                        "SET @a2 = (SELECT SUM((TA041 - TA058) * MQ010) FROM ACRTA " +
                                   "INNER JOIN CMSMQ ON MQ001=TA001 " +
                                   "WHERE TA004=@CustomCode AND TA019='N' AND TA025='Y' AND TA027='N'); " +

                        //應收票據
                        "SET @a3 = (SELECT SUM(TC003) FROM NOTTC WHERE TC013=@CustomCode AND TC012 IN (1,2,3,5,9)); " +

                        //訂貨金額
                        "SET @a4 = (SELECT SUM((TD008 - TD009) * TD011) " +
                                   "FROM COPTC " +
                                   "INNER JOIN COPTD ON TC001=TD001 AND TC002=TD002 " +
                                   "WHERE TC027='Y' AND TC004=@CustomCode AND TD016='N'); " +

                        //應收合計=應收票據+應收帳款+未結帳銷貨+訂貨金額
                        "SET @Total = ISNULL(@a1,0) + ISNULL(@a2,0) + ISNULL(@a3,0) + ISNULL(@a4,0); " +

                        //信用餘額=可超出額度-應收合計
                        "SELECT MA033 - @Total FROM COPMA WHERE MA001=@CustomCode; ";

            decimal dResult = Convert.ToDecimal(db.ExecuteScalar());
            return dResult;
        }

        /// <summary>取得訂單歷史記錄</summary>
        public static DataTable GetOrderList(string ID, string MemberID, string Type, string strSDate, string strEDate, string strKeyword, int _pageindex, int _pagesize, out int _recordcount)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("ID", ID);
            param.Add("MemberID", MemberID);
            param.Add("Type", Type);
            param.Add("SDate", strSDate);
            param.Add("EDate", strEDate);
            param.Add("Keyword", "%" + strKeyword + "%");
            db.SqlParams = param;

            //條件式
            string strWhere = "";
            if (!string.IsNullOrEmpty(ID)) { strWhere += " AND o.ID=@ID"; }
            if (!string.IsNullOrEmpty(MemberID)) { strWhere += " AND o.Member_ID=@MemberID"; }
            if (!string.IsNullOrEmpty(Type)) { strWhere += " AND o.Type=@Type"; }
            if (!string.IsNullOrEmpty(strSDate)) { strWhere += " AND Convert(date, o.Date) >= @SDate"; }
            if (!string.IsNullOrEmpty(strEDate)) { strWhere += " AND Convert(date, o.Date) <= @EDate"; }
            if (!string.IsNullOrEmpty(strKeyword)) { strWhere += " AND (o.PO + o.OrderNum + oi.ProductNo + oi.CustomPN) LIKE @Keyword"; }

            string StrSQL = "SELECT o.ID, o.Member_ID, o.OrderNum, c.Name [Type], o.Attn, o.PO, o.Tel, o.ShippingAddress, o.BillingAddress, o.Comment, Convert(Varchar(10), o.Date,111) [Date], o.Attachment, o.Cancel FROM [Order] o " +
                            "LEFT OUTER JOIN OrderItem oi ON oi.Order_ID=o.ID " +
                            "LEFT OUTER JOIN Config c ON c.Type='OrderType' AND o.Type=c.Value " +
                            "WHERE 1=1 AND o.OrderNum IS NOT NULL" + strWhere + " " +
                            "GROUP BY o.ID, o.Member_ID, o.OrderNum, c.Name, o.Attn, o.PO, o.Tel, o.ShippingAddress, o.BillingAddress, o.Comment, Convert(Varchar(10), o.Date,111), o.Attachment, o.Cancel";

            return db.ExecuteDataTable(StrSQL, "Date DESC", _pageindex, _pagesize, out _recordcount);
        }

        /// <summary>取得訂單單身項目歷史記錄</summary>
        public static DataTable GetOrderItemList(string OrderID)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderID", OrderID);
            db.SqlParams = param;

            db.StrSQL = "SELECT * FROM OrderItem WHERE Order_ID=@OrderID";

            return db.ExecuteDataTable();
        }

        /// <summary>判斷訂單是否已轉入ERP</summary>
        public static bool CheckOrderToERP(string ERPCompany, string OrderNumber)
        {
            //物件初始化
            Company c = CompanyCollection.Get(ERPCompany);
            DataBase.DataBase db = new DataBase.DataBase(c.ConnectionString);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderNumber", OrderNumber);
            db.SqlParams = param;

            db.StrSQL = "SELECT COUNT(*) FROM COPTB WHERE TB012=@OrderNumber AND TB011<>'V'";
            int iCount = Convert.ToInt16(db.ExecuteScalar());

            bool bResult = false;
            if (iCount > 0) { bResult = true; }

            return bResult;
        }

        /// <summary>取消訂單</summary>
        public static void CancelOrder(string OrderNumber)
        {
            //物件初始化
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //資料庫參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("OrderNumber", OrderNumber);
            db.SqlParams = param;

            db.StrSQL = "UPDATE [Order] SET Cancel='Y' WHERE OrderNum=@OrderNumber";

            db.ExecuteSQL();
        }

        /// <summary>取得產品庫存表列表</summary>
        public static DataTable GetInvertoryList(string MemberID, string OrderType)
        {
            //物件初始化
            Company c = CompanyCollection.Get("UHRlamps");
            DataBase.DataBase db = new DataBase.DataBase(Definition.UHRConnStr);

            //參數
            DataBase.SqlParams param = new UHR.DataBase.SqlParams();
            param.Add("MemberID", MemberID);
            param.Add("Type", OrderType);
            db.SqlParams = param;

            //取得價格表標題
            string sqlTitle = "";
            db.StrSQL = "SELECT * FROM PriceTitle WHERE Member_ID=@MemberID AND Type=@Type ORDER BY Sort";
            DataTable dtTitle = db.ExecuteDataTable();
            foreach (DataRow row in dtTitle.Rows)
            {
                string strTitle = row["Title"].ToString().Trim();
                sqlTitle += ",PriceXml.query('data(Price/Item[@Title=\"" + strTitle + "\"])') [" + strTitle + "]";
            }

            //SQL
            db.StrSQL = "SELECT [UHR P/N], CASE WHEN [Inventory] < 0 THEN 0 ELSE ISNULL([Inventory],0) END [Inventory]" + sqlTitle +
                        "FROM(" +
                            "SELECT MB002 [UHR P/N], SUM(ISNULL(MC007,0)) - SUM(ISNULL(a.Qty,0)) - SUM(ISNULL(b.Qty,0)) - SUM(ISNULL(c.Qty,0)) [Inventory] " +
                            "FROM {DBName}INVMB " +
                            "LEFT OUTER JOIN {DBName}INVMC ON (MC002='4A01') AND (MB001=MC001) " +
                            "LEFT OUTER JOIN (SELECT TD004, SUM(TD008-TD009) [Qty] FROM {DBName}COPTD WHERE (TD007='4A01') AND (TD016='N') AND (TD021<>'V') GROUP BY TD004) a ON (TD004=MB001) " +
                            "LEFT OUTER JOIN (SELECT TG004, SUM(TG009-TG021) [Qty] FROM {DBName}INVTG WHERE TG001='1401' AND (TG022 IN ('Y')) AND (TG024='N') GROUP BY TG004) b ON (TG004=MB001) " +
                            "LEFT OUTER JOIN (SELECT ProductNo, SUM(Quantity) [Qty] FROM [Order] o " +
                                             "INNER JOIN [OrderItem] oi ON o.ID=oi.Order_ID " +
                                             "INNER JOIN Member m ON m.ID=o.Member_ID " +
                                             "LEFT OUTER JOIN (SELECT TB012 FROM " + Definition.ERPDBName + "COPTB UNION SELECT TB012 FROM " + Definition.UHRlampsDBName + "COPTB) b ON o.OrderNum=b.TB012 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                                             "WHERE (ERP_Company='UHRlamps') AND (m.Level<>'') AND (o.Date >= '2013/7/1') AND (o.Cancel IS NULL OR o.Cancel <> 'Y') AND (b.TB012 IS NULL) " +
                                             "GROUP BY ProductNo) c ON c.ProductNo=MB002 COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                            "GROUP BY MB002" +
                        ")r " +
                        "INNER JOIN PriceList d ON d.Member_ID=@MemberID AND d.ProductName=r.[UHR P/N] COLLATE Chinese_Taiwan_Stroke_CI_AS " +
                        "ORDER BY [UHR P/N]";

            db.StrSQL = db.StrSQL.Replace("{DBName}", c.DBName);

            return db.ExecuteDataTable();
        }
    }
}