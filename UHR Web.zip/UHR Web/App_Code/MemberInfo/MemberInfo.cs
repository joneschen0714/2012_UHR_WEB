﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace UHR
{
    public class MemberInfo
    {
        //變數
        private string _memberid = "", _name = "", _account = "", _email = "", _level = "", _salesmail = "", _currency = "", _erp_company = "", _erp_customcode = "";

        public MemberInfo()
        {

        }

        /// <summary>會員ID</summary>
        public string MemberID
        {
            set { _memberid = value; }
            get { return _memberid; }
        }

        /// <summary>會員名稱</summary>
        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }

        /// <summary>Email</summary>
        public string Email
        {
            set { _email = value; }
            get { return _email; }
        }

        /// <summary>會員等級</summary>
        public string Level
        {
            set { _level = value; }
            get { return _level; }
        }

        /// <summary>對應的業務信箱</summary>
        public string ContactSalesMail
        {
            set { _salesmail = value; }
            get { return _salesmail; }
        }

        /// <summary>幣別</summary>
        public string Currency
        {
            set { _currency = value; }
            get { return _currency; }
        }

        /// <summary>ERP公司別</summary>
        public string ERP_Company
        {
            set { _erp_company = value; }
            get { return _erp_company; }
        }

        /// <summary>ERP客戶代號</summary>
        public string ERP_CustomCode
        {
            set { _erp_customcode = value; }
            get { return _erp_customcode; }
        }

        /// <summary>取得是否存取ERP</summary>
        public bool ConnectERP
        {
            get { return (ERP_Company != "" && ERP_CustomCode != ""); }
        }





        /// <summary>檢查是否登入</summary>
        public static bool CheckLogin
        {
            get { return (Definition.MemberInfo != null); }
        }

        /// <summary>設定登入記錄</summary>
        public static void SetMemberInfo(string _memberid,string _name, string _email, string _level, string _salesmail, string _currency, string _erpcompany, string _erpcustomcode)
        {
            //會員個人物件
            MemberInfo mi = new MemberInfo();
            mi.MemberID = _memberid;
            mi.Name = _name;
            mi.Email = _email;
            mi.Level = _level;
            mi.ContactSalesMail = _salesmail;
            mi.Currency = _currency;
            mi.ERP_Company = _erpcompany;
            mi.ERP_CustomCode = _erpcustomcode;

            Definition.MemberInfo = mi; //會員登入記錄

            BLL.UpdateMemberLoginDate(_memberid); //更新會員的登入時間
        }

        /// <summary>取得登入記錄</summary>
        public static MemberInfo Get()
        {
            return Definition.MemberInfo;
        }

        /// <summary>登出</summary>
        public static void Logout()
        {
            Definition.MemberInfo = null;

            //移除所有Session
            System.Web.SessionState.HttpSessionState hss = HttpContext.Current.Session;
            hss.Clear();

            //若有Cookie記錄
            HttpCookie cookie = HttpContext.Current.Request.Cookies["AutoLogin"];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddYears(-1); //清除Cookie
                HttpContext.Current.Response.Cookies.Set(cookie);
            }

            HttpContext.Current.Response.Redirect("~/Page/Member/Login.aspx");
        }
    }
}