﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;

namespace UHR
{
    /// <summary>公司別</summary>
    public class Company
    {
        private string _Name = "", _Value = "", _ConnectionString = "", _DBName = "";

        public Company() { }

        public Company(string Name, string Value, string ConnectionString, string DBName)
        {
            this.Name = Name;
            this.Value = Value;
            this.ConnectionString = ConnectionString;
            this.DBName = DBName;
        }

        public string Name
        {
            set { _Name = value; }
            get { return _Name; }
        }
        public string Value
        {
            set { _Value = value; }
            get { return _Value; }
        }
        public string ConnectionString
        {
            set { _ConnectionString = value; }
            get { return _ConnectionString; }
        }
        public string DBName
        {
            set { _DBName = value; }
            get { return _DBName; }
        }
    }

    /// <summary>公司別集合</summary>
    public class CompanyCollection : List<Company>
    {
        public CompanyCollection()
        {
            //預設公司別
            this.Add(new Company("華燈光電", "Arclite", Definition.ERPConnStr, Definition.ERPDBName));
            this.Add(new Company("UHRlamps", "UHRlamps", Definition.UHRLampsConnStr, Definition.UHRlampsDBName));
        }

        public static Company Get(string Value)
        {
            CompanyCollection cl = new CompanyCollection();
            var obj = from r in cl where r.Value == Value select r;

            Company c = null;
            foreach (var a in obj) { c = (Company)a; }

            return c;
        }
    }
}