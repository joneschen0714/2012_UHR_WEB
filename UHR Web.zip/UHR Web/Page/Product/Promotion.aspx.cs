﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Product_Promotion : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            "#CatalogTable { width:100%; }" +
                            "#CatalogTable td { text-align:left; border-bottom:#ff8c00 1px dashed; padding:10px 0; }" +
                            ".PromotionTitle { font-size:12px; font-weight:bold; }" +
                            ".PromotionNews { }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    //初始化
    private new void DataBind()
    {
        //資料來源
        DataTable dtPromotion = BLL.GetPromotionList();

        //資料繫結
        rpPromotion.ItemDataBound += new RepeaterItemEventHandler(rpPromotion_ItemDataBound);
        rpPromotion.DataSource = dtPromotion;
        rpPromotion.DataBind();
    }

    protected void rpPromotion_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //若為資料列
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            //取得當筆資料來源
            DataRowView rowView = (DataRowView)e.Item.DataItem;

            //取得控制項
            HyperLink linkTitle = (HyperLink)e.Item.FindControl("linkTitle");
            Label lblDescription = (Label)e.Item.FindControl("lblDescription");

            //變數
            string strID = Convert.ToString(rowView["ID"]);
            string strName = Convert.ToString(rowView["Name"]);
            string strDescription = Convert.ToString(rowView["Description"]);
            string strHref = ResolveClientUrl("~/Page/Product/ProductList.aspx?catalog=" + strID);

            //設定值
            linkTitle.Text = strName;
            linkTitle.NavigateUrl = strHref;
            lblDescription.Text = strDescription;
        }
    }
}