﻿using System;
using System.Data;
using System.Configuration;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Product_ProductDetail : System.Web.UI.Page
{
    public string LEVEL = "";

    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<script type='text/javascript' src='" + ResolveClientUrl("~/Source/Js/jQuery/jquery.treeview.js") + "'></script>" +
                        "<link type='text/css' rel='stylesheet' href='" + ResolveClientUrl("~/Source/Css/jquery.treeview.css") + "' />" +
                        "<style type=\"text/css\">" +
                            ".spField { font-weight:bold; }" +

                            ".RelatedTitle { font-weight:bold; background:url(../../Source/Image/lan_icon.gif) no-repeat center left; padding-left:15px; color:#ff6600; }" +
                            "div[jTag=divDesc] ul { padding:0px; margin:0 0 0 20px; list-style-type:square; }" +

                            ".ProductImgStyle { border:#CCCCCC 1px solid; margin:2px; }" +
                            "#divShoppingCart { text-align:right; }" +

                            ".ProductStatusDialog { background:#FFFFFF; }" +
                            ".ProductStatusDialog td { white-space:nowrap; }" +

                            ".PriceTable { background-color:#F6F6F6; width:100%; margin-bottom:15px; border:1px dashed #999999; }" +
                            ".PriceTable td { padding:0 10px; text-align:center; }" +
                            ".PriceTable td.bottom { border-bottom:1px dashed #999999; }" +
                            ".PriceTable td.right { border-right:1px dashed #999999; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //記錄全域變數供前台使用
        if (MemberInfo.CheckLogin)
        {
            LEVEL = MemberInfo.Get().Level; //會員等級
        }

        if (!IsPostBack)
        {
            //多國語系
            btnAddWishList.Text = Resources.Lang.L000116;
            btnLampModule.Text = Resources.Lang.L000076;
            btnBareLamp.Text = Resources.Lang.L000075;
            linkDiscount.Text = Resources.Lang.L000153;

            DataBind();
        }
    }

    //初始化
    public override void DataBind()
    {
        //網址參數
        ProjectorID = Tool.CheckQueryString("id");

        DataRow rowData = BLL.GetProductInfo(ProjectorID, null); //取得產品資料

        //設定變數
        string strUHR_LMID = Convert.ToString(rowData["UHR_LMID"]);
        string strUHR_LM_Status = Convert.ToString(rowData["UHR_LM_Status"]);
        string strUHR_BL_Status = Convert.ToString(rowData["UHR_BL_Status"]);

        //設定控制項值
        lblBrand.Text = GetItemValue(rowData["Brand"]);
        lblProjectorModel.Text = GetItemValue(rowData["ProjectorModel"]);
        lblUHRLampModule.Text = GetItemValue(rowData["UHR_LM"]);
        lblUHRBareLamp.Text = GetItemValue(rowData["UHR_BL"]);
        lblLampModule.Text = GetItemValue(rowData["OEM_LM"]);
        lblLampType.Text = GetItemValue(rowData["OEM_LT"]);
        lblType.Text = BLL.GetConfigName("ProductClass", rowData["UHR_LM_Class"].ToString());
        lblUHRLampModuleStatus.Text = BLL.GetConfigName("ProductStatus", rowData["UHR_LM_Status"].ToString());
        lblUHRBulbStatus.Text = BLL.GetConfigName("ProductStatus", rowData["UHR_BL_Status"].ToString());

        #region 價格
        string strLMPrice = GetItemValue(rowData["UHR_LM_Price"]);
        string strBLPrice = GetItemValue(rowData["UHR_BL_Price"]);

        if (strLMPrice != "-") { lblLMPrice.Text = strLMPrice + "(USD)"; } else { lblLMPrice.Text = strLMPrice; }
        if (strBLPrice != "-") { lblBLPrice.Text = strBLPrice + "(USD)"; } else { lblBLPrice.Text = strBLPrice; }
        #endregion

        #region 產品描述區域
        if (rowData["UHR_LM_Desc"].ToString() != "")
        {
            divDesc.Visible = true;
            lblUHRModuleDesc.Text = rowData["UHR_LM_Desc"].ToString();
        }
        #endregion

        //檢查會員是否已登入
        if (MemberInfo.CheckLogin)
        {
            MemberInfo mi = MemberInfo.Get();

            #region 會員分級功能(A級)
            if (mi.Level == "A")
            {
                //原廠燈Marking
                string strMarking = BLL.GetOEMLampModuleMarking(ProjectorID);
                if (strMarking != "")
                {
                    trMarking.Visible = true;
                    lblMarking.Text = strMarking;
                }

                //出廠年限
                trProduceDate.Visible = true;
                lblProduceDate.Text = Convert.ToString(rowData["ProduceDate"]);
            }
            #endregion

            #region 會員分級功能(A,B級)
            if (mi.Level == "A" || mi.Level == "B")
            {
                //顯示共用的光機與原廠燈
                tbRelatedProduct.Visible = true;
                FillRelatedProjector(strUHR_LMID);
                FillRelatedOEMLampModule(strUHR_LMID);

                #region 設定UHR LampModule庫存數量
                if (strUHR_LM_Status == "I")
                {
                    int iQtyUS = BLL.GetProductStockQtyAmerica(lblUHRLampModule.Text);
                    int iQtyTW = BLL.GetProductStockQtyTaiwan(lblUHRLampModule.Text);

                    liLMStock.Text = "<table class='ProductStatusDialog'>";
                    liLMStock.Text += "<tr><td><img src='" + ResolveClientUrl("~/Source/Image/Country/small/us.png") + "' /></td><td>America</td><td> ： Stock " + iQtyUS.ToString() + " Available</td></tr>";
                    liLMStock.Text += "<tr><td><img src='" + ResolveClientUrl("~/Source/Image/Country/small/tw.png") + "' /></td><td>Taiwan</td><td> ： " + (iQtyTW > 0 ? "In Stock" : "Out Of Stock") + "</td></tr>";
                    liLMStock.Text += "</table>";
                }
                #endregion
                #region 設定UHR Bulb庫存數量
                /*
                if (strUHR_BL_Status == "I")
                {
                    int iQtyUS = BLL.GetProductStockQtyAmerica(lblUHRBareLamp.Text);
                    int iQtyTW = BLL.GetProductStockQtyTaiwan(lblUHRBareLamp.Text);

                    HtmlImage img = new HtmlImage();
                    img.Attributes.Add("class", "ProductStatusDialogImg");
                    img.Src = "~/Source/Image/Quantity.png";

                    LiteralControl lc = new LiteralControl();
                    lc.Text = "<table class='ProductStatusDialog'>";
                    lc.Text += "<tr><td><img src='" + ResolveClientUrl("~/Source/Image/Country/small/us.png") + "' /></td><td>America</td><td> ： Stock " + iQtyUS.ToString() + " Available</td></tr>";
                    lc.Text += "<tr><td><img src='" + ResolveClientUrl("~/Source/Image/Country/small/tw.png") + "' /></td><td>Taiwan</td><td> ： " + (iQtyTW > 0 ? "In Stock" : "Out Of Stock") + "</td></tr>";
                    lc.Text += "</table>";

                    spanBLProductStatus.Controls.Add(new LiteralControl("&nbsp;"));
                    spanBLProductStatus.Controls.Add(img);
                    spanBLProductStatus.Controls.Add(lc);
                }
                */
                #endregion

                #region 優惠價格表
                DataTable dtLMPriceList = BLL.GetMemberPrice(MemberInfo.Get().MemberID, null, lblUHRLampModule.Text, null);
                if (dtLMPriceList.Rows.Count > 0)
                {
                    liLMPrice.Text = GetPriceTableHtml(Resources.Lang.L000076, dtLMPriceList, mi.Currency);
                    palPriceList.Visible = true;
                }

                DataTable dtBLPriceList = BLL.GetMemberPrice(MemberInfo.Get().MemberID, null, lblUHRBareLamp.Text, null);
                if (dtBLPriceList.Rows.Count > 0)
                {
                    liBLPrice.Text = GetPriceTableHtml(Resources.Lang.L000075, dtBLPriceList, mi.Currency);
                    palPriceList.Visible = true;
                }
                #endregion
            }
            #endregion
        }

        SetProductImages(strUHR_LMID);
        InsertProductBrowseLog(ProjectorID);
    }

    //新增瀏覽產品Log
    private void InsertProductBrowseLog(string PID)
    {
        string MemberID = "";
        if (MemberInfo.CheckLogin) { MemberID = Definition.MemberInfo.MemberID; }

        BLL.InsertProductBrowseLog(PID, MemberID, Tool.GetClientIP());
    }

    //相關Projector
    private void FillRelatedProjector(string _uhrlmid)
    {
        DataTable dtResult = BLL.GetRelatedProjector(_uhrlmid); //資料來源表
        dtResult.DefaultView.Sort = "Brand"; //排序
        DataTable dtBrand = dtResult.DefaultView.ToTable(true, "Brand"); //相異Brand表

        //TreeView tree = treeRelatedProjector;
        string strTree = "<ul class='filetree'>";
        foreach (DataRow rowBrand in dtBrand.Rows)
        {
            string strBrand = Convert.ToString(rowBrand["Brand"]);

            strTree += "<li><span class='folder'>" + strBrand + "</span>";

            //循序建立Projector
            strTree += "<ul>";
            DataRow[] rowProjectors = dtResult.Select("Brand='" + strBrand + "'", "ProjectorModel");
            foreach (DataRow rowProjector in rowProjectors)
            {
                string strProjectorID = Convert.ToString(rowProjector["ID"]);
                string strProjector = Convert.ToString(rowProjector["ProjectorModel"]);

                strTree += "<li><span class='file'><a href='ProductDetail.aspx?id=" + strProjectorID + "'>" + strProjector + "</a></span></li>";
            }
            strTree += "</ul></li>";
        }
        strTree += "</ul>";

        liRelatedProjector.Text = strTree;
    }

    //相關OEM Lamp Module
    private void FillRelatedOEMLampModule(string _uhrlmid)
    {
        DataTable dtResult = BLL.GetRelatedOEMLampModule(_uhrlmid); //資料來源表
        dtResult.DefaultView.Sort = "Brand"; //排序
        DataTable dtBrand = dtResult.DefaultView.ToTable(true, "Brand"); //相異Brand表

        //TreeView tree = treeRelatedProjector;
        string strTree = "<ul class='filetree'>";
        foreach (DataRow rowBrand in dtBrand.Rows)
        {
            string strBrand = Convert.ToString(rowBrand["Brand"]);

            strTree += "<li><span class='folder'>" + strBrand + "</span>";

            //循序建立Projector
            strTree += "<ul>";
            DataRow[] rowOEMLampModules = dtResult.Select("Brand='" + strBrand + "'", "OEM_LM");
            foreach (DataRow rowOEMLampModule in rowOEMLampModules)
            {
                string strOEMLampModuleID = Convert.ToString(rowOEMLampModule["ID"]);
                string strOEMLampModule = Convert.ToString(rowOEMLampModule["OEM_LM"]);

                strTree += "<li><span class='file'><a href='ProductList.aspx?oemlm=" + strOEMLampModuleID + "'>" + strOEMLampModule + "</a></span></li>";
            }
            strTree += "</ul></li>";
        }
        strTree += "</ul>";

        liRelatedOEMLampModule.Text = strTree;
    }

    //購物按鈕動作
    protected void btnPurchase_Click(object sender, EventArgs e)
    {
        //檢查是否登入
        if (MemberInfo.CheckLogin)
        {
            int iQty;
            int.TryParse(txtQty.Text, out iQty);
            if (iQty > 0)
            {
                string strType = ((Button)sender).CommandArgument; //LM或BL
                ShoppingCartItem.ProductType pt = ShoppingCartItem.GetProductType(strType);

                ShoppingCart sc = Definition.ShoppingCart;

                //判斷產品是否已存在
                if (!sc.Exists(ProjectorID, pt))
                {
                    sc.Add(ProjectorID, pt, iQty);
                    Response.Redirect("~/Page/Member/EstimatedSheet.aspx"); //轉向購物車頁
                }
                else
                {
                    div_p_Message.InnerHtml = "<label style='color:red'>" + Resources.Lang.L000130 + "</label>";
                }
            }
            else
            {
                //錯誤訊息
                div_p_Message.InnerHtml = "<label style='color:red'>" + Resources.Lang.L000131 + "</label>";
            }
        }
        else
        {
            div_p_Message.InnerHtml = "<label style='color:red'>" + Resources.Lang.L000132 + "</label>";
        }
    }

    //加入WishList動作
    protected void btnAddWishList_Click(object sender, EventArgs e)
    {
        //檢查是否登入
        if (MemberInfo.CheckLogin)
        {
            //變數
            string strMemberID = Definition.MemberInfo.MemberID;

            //檢查是否存在WishList
            bool bExists = BLL.WishListExists(strMemberID, ProjectorID);
            if (!bExists)
            {
                //加入Wish List
                BLL.AddWishList(strMemberID, ProjectorID);
                Response.Redirect("~/Page/Member/WishList.aspx");
            }
            else
            {
                div_p_Message.InnerHtml = "<label style='color:red'>" + Resources.Lang.L000130 + "</label>";
            }
        }
        else
        {
            div_p_Message.InnerHtml = "<label style='color:red'>" + Resources.Lang.L000132 + "</label>";
        }
    }

    //設定產品圖片
    private void SetProductImages(string _uhrlmid)
    {
        DataTable dtImages = BLL.GetUHR_LampModuleImage(_uhrlmid);

        List<string> listFileName = new List<string>(); //圖片檔名清單

        //循序增加檔名至清單
        foreach (DataRow row in dtImages.Rows)
        {
            //判斷權限
            bool bShow = false;
            if (MemberInfo.CheckLogin)
                bShow = (row["Main"].ToString() == "Y" || row["Level"].ToString() == "") || (row["Level"].ToString().Contains(MemberInfo.Get().Level));
            else
                bShow = (row["Main"].ToString() == "Y");

            if (bShow) { listFileName.Add(row["FileName"].ToString()); }
        }

        if (listFileName.Count > 0)
        {
            //循序建立圖片Html
            foreach (string strFileName in listFileName)
            {
                string strFilePath = ConfigurationManager.AppSettings["ProductImagePath"] + strFileName;
                string strPath = ResolveClientUrl("~/thumbnail.ashx?max=50&file=" + strFilePath);
                string strImgPath = ResolveClientUrl(strFilePath);

                liProductImg.Text += "<img src='" + strPath + "' onclick=\"ViewImage('" + _uhrlmid + "','" + strFileName + "')\" class='ProductImgStyle' style='cursor:pointer;' />";
            }
        }
        else
        {
            liProductImg.Text = "<img src='" + ResolveClientUrl(ConfigurationManager.AppSettings["ProductImagePath"] + "no_image.jpg") + "' width='280' class='ProductImgStyle' />";
        }
    }

    //Discount按鈕事件
    protected void linkDiscount_Click(object sender, EventArgs e)
    {
        Response.Redirect("~/Page/Public/QA.aspx?type=Order Information");
    }



    private string GetPriceTableHtml(string productType, DataTable dt, string Currency)
    {
        string html = "", type = "", title = "", desc = "", qty = "", price = "";

        title = "<tr><td class='bottom right' style='color:#ff6600; font-weight:bold;'>" + productType + "</td>";
        desc = "<tr><td class='bottom right'>" + Resources.Lang.L000128 + "</td>";
        qty = "<tr><td class='bottom right'>" + Resources.Lang.L000104 + "</td>";
        price = "<tr><td class='right'>" + Resources.Lang.L000154 + "</td>";

        foreach (DataRow row in dt.Rows)
        {
            title += string.Format("<td class='bottom'><b>{0}</b><br/>{1}</td>", row["TypeName"], row["Title"]);

            desc += string.Format("<td class='bottom'>{0}</td>", row["Description"] + "&nbsp;");

            if (Convert.IsDBNull(row["StartQty"]) && Convert.IsDBNull(row["EndQty"]))
                qty += "<td class='bottom'>-</td>";
            else
                qty += string.Format("<td class='bottom'>{0} ~ {1}</td>", row["StartQty"], row["EndQty"]);

            price += string.Format("<td>{0}({1})</td>", row["Price"], Currency);
        }

        title += "</tr>";
        qty += "</tr>";
        price += "</tr>";

        html = "<table cellpadding='0' cellspacing='0' class='PriceTable'>" + title + desc + qty + price + "</table>";
        return html;
    }

    private string GetItemValue(object data)
    {
        string value = Convert.ToString(data);
        if (string.IsNullOrEmpty(value))
        {
            value = "-";
        }
        return value;
    }

    private string ProjectorID
    {
        set { ViewState.Add("ProjectorID", value.Trim()); }
        get { return ViewState["ProjectorID"].ToString(); }
    }
}