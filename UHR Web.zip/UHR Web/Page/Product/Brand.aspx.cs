﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Brand : System.Web.UI.Page
{
    //全域變數
    private string strType;

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址變數
        strType = Tool.CheckQueryString("type");

        //第一次進入執行
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        //取得資料來源
        DataTable dtProductList = BLL.GetProductList("", "", strType, "", "", "", "", "");

        //濾出不重覆的Brand ID
        DataTable dtBrandID = dtProductList.DefaultView.ToTable(true, "BrandID");

        //組成Brand ID Array
        string strBrandIDArray = "";
        foreach (DataRow row in dtBrandID.Rows)
        {
            strBrandIDArray += (strBrandIDArray == "" ? "" : ",") + row["BrandID"].ToString();
        }

        //取得Brand資料清單
        DataTable dtBrand = BLL.GetBrandList(strBrandIDArray);

        int TDNum = 4; //TD數量
        int TRNum = (dtBrandID.Rows.Count / TDNum) + (dtBrandID.Rows.Count % TDNum > 0 ? 1 : 0); //TR數量

        string ResultStr = "";
        for (int i = 1; i <= TRNum; i++)
        {
            ResultStr += "<tr>";

            for (int j = 1; j <= TDNum; j++)
            {
                int Index = ((i - 1) * TDNum) + j;
                if (Index <= dtBrand.Rows.Count)
                {
                    DataRow row = dtBrand.Rows[Index - 1];
                    string ImgPath = ConfigurationManager.AppSettings["BrandImagePath"] + row["ImgSrc"].ToString();

                    ResultStr += string.Format("<td><a href='ProductList.aspx?type={0}&brand={1}'><img src='{2}' /></a></td>", strType, row["ID"], ResolveUrl(ImgPath));
                }
            }

            ResultStr += "</tr>";
        }

        liBrand.Text = ResultStr;
    }
}