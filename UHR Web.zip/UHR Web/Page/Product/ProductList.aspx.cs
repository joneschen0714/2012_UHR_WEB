﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Linq;
using UHR;

public partial class Page_Product_ProductList : System.Web.UI.Page
{
    //全域變數
    public string LEVEL = "";
    private string strKeyword, strOEMLM, strType, strCatalog, strBrand, strUHRLM, strClass, strStock;

    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            ".RemoveFilter_Title { background: url(../../Source/Image/tick_circle_frame.png) no-repeat 0px 2px; font-weight:bold; padding:0 0 0 20px; }" +
                            ".AddFilter_Title { background: url(../../Source/Image/filter.png) no-repeat 0px 2px; font-weight:bold; padding:0 0 0 20px; margin:5px 0 0 0; }" +
                            "ul[jTag=filters] { list-style:none; margin:0; padding:0 0 10px 0; line-height:18px; border-bottom:#ff8c00 1px dotted; }" +
                            "ul[jTag=filters] li { margin:0; padding:0 5px; list-style:none; cursor:pointer; border:#FFFFFF 1px solid; }" +
                            "ul[jTag=filters] li.RemoveItem { background: url(../../Source/Image/more_icon.gif) no-repeat 3px 8px; padding:0 0 0 10px; margin:0 0 3px 0; border:#d3d3d3 1px solid; }" +
                            "ul[jTag=filters] li:hover { background-color:#ebebeb; border:#d3d3d3 1px solid; }" +
                            "ul[jTag=filters] li span { color:#5D5D5D; font-size:10px; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //記錄全域變數供前台使用
        if (MemberInfo.CheckLogin)
        {
            LEVEL = MemberInfo.Get().Level; //會員等級
        }

        //全域變數
        strKeyword = Tool.CheckQueryString("keyword");
        strOEMLM = Tool.CheckQueryString("oemlm");
        strType = Tool.CheckQueryString("type");
        strCatalog = Tool.CheckQueryString("catalog");
        strBrand = Tool.CheckQueryString("brand");
        strUHRLM = Tool.CheckQueryString("uhrlm");
        strClass = Tool.CheckQueryString("class");
        strStock = Tool.CheckQueryString("stock");

        if (!IsPostBack)
        {
            GetDescription(strCatalog);
            gv_GridDataBind(sender, e);
            SetQueryCondition();
        }
    }

    //設定搜尋條件
    private void SetQueryCondition()
    {
        DataTable dt = (DataTable)gv.GridView.DataSource;

        #region Remove Filters
        if (!string.IsNullOrEmpty(strKeyword))
            liRemoveFilters.Text += string.Format("<li name='keyword' val='' class='RemoveItem'>Keyword : {0}</li>", strKeyword);

        if (!string.IsNullOrEmpty(strUHRLM))
            liRemoveFilters.Text += string.Format("<li name='uhrlm' val='' class='RemoveItem'>UHR LM : {0}</li>", BLL.GetUHRLampModuleName(strUHRLM));

        if (!string.IsNullOrEmpty(strType))
            liRemoveFilters.Text += string.Format("<li name='type' val='' class='RemoveItem'>Lamp Type : {0}</li>", BLL.GetConfigName("LampType", strType));

        if (!string.IsNullOrEmpty(strClass))
            liRemoveFilters.Text += string.Format("<li name='class' val='' class='RemoveItem'>Lamp Class : {0}</li>", BLL.GetConfigName("ProductClass", strClass));

        if (!string.IsNullOrEmpty(strStock))
            liRemoveFilters.Text += string.Format("<li name='stock' val='' class='RemoveItem'>Lamp Stock : {0}</li>", BLL.GetConfigName("ProductStatus", strStock));

        if (!string.IsNullOrEmpty(strBrand))
            liRemoveFilters.Text += string.Format("<li name='brand' val='' class='RemoveItem'>Brand : {0}</li>", BLL.GetBrandName(strBrand));

        if (!string.IsNullOrEmpty(strOEMLM))
            liRemoveFilters.Text += string.Format("<li name='oemlm' val='' class='RemoveItem'>Lamp Module : {0}</li>", BLL.GetOEMLampModuleName(strOEMLM));

        if (liRemoveFilters.Text != "")
        {
            liRemoveFilters.Text = "<div class='RemoveFilter_Title'>" + Resources.Lang.L000069 + " : </div>" +
                                      "<ul jTag='filters'>" + liRemoveFilters.Text + "</ul>";
        }
        #endregion

        #region Lamp Type
        if (string.IsNullOrEmpty(strType))
        {
            var t = from r in dt.AsEnumerable()
                    group r by new
                    {
                        LM_Type = r["LM_Type"],
                        LMTypeName = r["LMTypeName"]
                    } into g
                    select new { g.Key.LM_Type, g.Key.LMTypeName, Count = g.Count() };

            //大於1筆才顯示
            if (t.Count() > 1)
            {
                foreach (var item in t)
                {
                    liByLampType.Text += string.Format("<li name='type' val='{0}'>- {1} <span>({2})</span></li>", item.LM_Type, item.LMTypeName, item.Count);
                }
                liByLampType.Text = "<div class='AddFilter_Title'>By Lamp Type : </div>" +
                                    "<ul jTag='filters'>" + liByLampType.Text + "</ul>";
            }
        }
        #endregion

        #region Lamp Class
        if (string.IsNullOrEmpty(strClass))
        {
            var t = from r in dt.AsEnumerable()
                    group r by r["LM_Class"] into g
                    select new { LM_Class = g.Key, Count = g.Count() };

            //大於1筆才顯示
            if (t.Count() > 1)
            {
                foreach (var item in t)
                {
                    liByLampClass.Text += string.Format("<li name='class' val='{0}'>- {1} <span>({2})</span></li>", item.LM_Class, BLL.GetConfigName("ProductClass", item.LM_Class.ToString()), item.Count);
                }
                liByLampClass.Text = "<div class='AddFilter_Title'>By Lamp Class : " +
                                    "<a href='../Public/StaticPage.aspx?type=UHR_UHRG_Series'><img src='../../Source/Image/help1.png' align='absmiddle' /></a></div>" +
                                    "<ul jTag='filters'>" + liByLampClass.Text + "</ul>";
            }
        }
        #endregion

        #region Stock
        if (string.IsNullOrEmpty(strStock))
        {
            var t = from r in dt.AsEnumerable()
                    group r by r["UHR_LM_Status"] into g
                    select new { UHR_LM_Status = g.Key, Count = g.Count() };

            //大於1筆才顯示
            if (t.Count() > 1)
            {
                foreach (var item in t)
                {
                    liStock.Text += string.Format("<li name='stock' val='{0}'>- {1} <span>({2})</span></li>", item.UHR_LM_Status, BLL.GetConfigName("ProductStatus", item.UHR_LM_Status.ToString()), item.Count);
                }
                liStock.Text = "<div class='AddFilter_Title'>By Lamp Stock : </div>" +
                                    "<ul jTag='filters'>" + liStock.Text + "</ul>";
            }
        }
        #endregion

        #region UHR Model
        if (strKeyword != "" && strUHRLM == "")
        {
            var t = from r in dt.AsEnumerable()
                    group r by new
                    {
                        UHR_LMID = r["UHR_LMID"],
                        UHR_LM = r["UHR_LM"]
                    } into g
                    select new { g.Key.UHR_LMID, g.Key.UHR_LM, Count = g.Count() };

            //大於1筆，小於11筆才顯示
            if (t.Count() > 1 && t.Count() < 11)
            {
                foreach (var item in t)
                {
                    liUHRLM.Text += string.Format("<li name='uhrlm' val='{0}'>- {1} <span>({2})</span></li>", item.UHR_LMID, item.UHR_LM, item.Count);
                }
                liUHRLM.Text = "<div class='AddFilter_Title'>Available UHR Models : </div>" +
                               "<ul jTag='filters'>" + liUHRLM.Text + "</ul>";
            }
        }
        #endregion

        #region Brand
        if (string.IsNullOrEmpty(strBrand))
        {
            //dt.DefaultView.Sort = "Brand ASC";
            //DataTable dtBrand = dt.DefaultView.ToTable(true, "BrandID", "Brand");

            var t = from r in dt.AsEnumerable()
                    group r by new
                    {
                        BrandID = r["BrandID"],
                        Brand = r["Brand"]
                    } into g
                    select new { g.Key.BrandID, g.Key.Brand, Count = g.Count() };

            //大於1筆才顯示
            if (t.Count() > 1)
            {
                foreach (var item in t)
                {
                    liByBrand.Text += string.Format("<li name='brand' val='{0}'>- {1} <span>({2})</span></li>", item.BrandID, item.Brand, item.Count);
                }
                liByBrand.Text = "<div class='AddFilter_Title'>By Brand : </div>" +
                                    "<ul jTag='filters'>" + liByBrand.Text + "</ul>";
            }
        }
        else
        {
            #region OEM Lamp Module

            DataTable dtPID = dt.DefaultView.ToTable(true, "ID");


            if (string.IsNullOrEmpty(strOEMLM))
            {
                string strProductID = "";
                foreach (DataRow row in dtPID.Rows)
                {
                    strProductID += (strProductID == "" ? "" : ",") + row["ID"].ToString(); //組成P_ID的陣列
                }

                DataTable dtProduct = BLL.GetOEMLampModuleByProjector(strProductID);
                foreach (DataRow row in dtProduct.Rows)
                {
                    liByOEMLampModule.Text += string.Format("<option value='{0}'>{1}</option>", row["ID"], row["OEM_LM"]);
                }
                liByOEMLampModule.Text = "<div class='AddFilter_Title'>By Lamp Module : </div>" +
                                            "<select size='15' class='FilterListBox' style='width:100%;' onChange=\"FilterAction('oemlm', this.options[this.selectedIndex].value)\">" + liByOEMLampModule.Text + "</select>";
            }
            #endregion
        }
        #endregion
    }

    //取得Catalog Description
    private void GetDescription(string _catalogid)
    {
        palDescription.Visible = false;

        //若有CatalogID，則取得與設定Description
        if (!string.IsNullOrEmpty(_catalogid))
        {
            string strDescription = BLL.GetCatalogDescription(_catalogid);
            divDescription.InnerHtml = strDescription;
            palDescription.Visible = !string.IsNullOrEmpty(strDescription);
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //取得資料來源
        DataTable dtProductList = BLL.GetProductList(strKeyword, strOEMLM, strType, strCatalog, strBrand, strUHRLM, strClass, strStock);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn(Resources.Lang.L000020, "Brand", true, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000073, "ProjectorModel", true, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000118, "OEMLampModule", true, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000119, "OEM_LT", true, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000147, "UHR_LM", true, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000076, "UHR_LM_Status", true, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn(Resources.Lang.L000075, "UHR_BL_Status", true, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);
        gv.AddColumn(Resources.Lang.L000074, "Image", true, Unit.Empty, HorizontalAlign.Center, HorizontalAlign.Center);

        if (gv.SortExpression == "") { gv.SortExpression = "Brand"; } //預設排序

        //載入Grid
        gv.GridView.AllowPaging = true;
        gv.GridView.PageIndex = (gv.PageIndex - 1);
        gv.RowCount = dtProductList.Rows.Count;
        gv.GridView.DataKeyNames = new string[] { "ID" }; //設定主鍵
        dtProductList.DefaultView.Sort = gv.SortingCondition; //設定排序
        gv.GridView.DataSource = dtProductList.DefaultView.ToTable();
        gv.DataBind();
    }

    //Grid資料列繫結事件
    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //資料列
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellProjectorModel = gv.GetTableCell(e.Row, "ProjectorModel", true);
            TableCell cellOEMLampModule = gv.GetTableCell(e.Row, "OEMLampModule", true);
            TableCell cellOEMLT = gv.GetTableCell(e.Row, "OEM_LT", true);
            TableCell cellLMStatus = gv.GetTableCell(e.Row, "UHR_LM_Status", true);
            TableCell cellBLStatus = gv.GetTableCell(e.Row, "UHR_BL_Status", true);
            TableCell cellImage = gv.GetTableCell(e.Row, "Image", true);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strProjectorModel = Convert.ToString(rowView["ProjectorModel"]);
            string strHref = ResolveClientUrl("~/Page/Product/ProductDetail.aspx?id=" + strID);
            string strUHRLMStatus = Convert.ToString(rowView["UHR_LM_Status"]);
            string strUHRBLStatus = Convert.ToString(rowView["UHR_BL_Status"]);
            string strImage = Convert.ToString(rowView["Image"]);

            //設定值
            cellProjectorModel.Text = string.Format("<a href='{0}'>{1}</a>", strHref, strProjectorModel);

            //OEM LampModule值設定
            cellOEMLampModule.Text = cellOEMLampModule.Text.Replace(",", "<br />");

            //OEM LT值設定
            cellOEMLT.Text += "&nbsp;";

            //設定Status圖示
            SetTableCellStatusImg(cellLMStatus, strUHRLMStatus);
            SetTableCellStatusImg(cellBLStatus, strUHRBLStatus);

            //Image值設定
            if (!string.IsNullOrEmpty(strImage))
                cellImage.Text = string.Format("<img src='{0}' style='cursor:pointer;' onclick=\"GetImage('{1}');\" />", ResolveClientUrl("~/Source/Image/camera.png"), strImage);
            else
                cellImage.Text = "&nbsp;";
        }
    }

    //Filters觸發動作
    protected void btnFilters_Click(object sender, EventArgs e)
    {
        string strUrl = Request.Url.ToString();
        string name = txtFiltersName.Text;
        string value = txtFiltersValue.Text;

        strUrl = Tool.SetUrlParam(strUrl, name, value);
        Response.Redirect(strUrl);
    }

    private void SetTableCellStatusImg(TableCell Cell, string Status)
    {
        switch (Status)
        {
            case "I":
                Cell.Text = string.Format("<img src='{0}' />", ResolveClientUrl("~/Source/Image/GreenBall.png"));
                break;
            case "O":
                Cell.Text = string.Format("<img src='{0}' />", ResolveClientUrl("~/Source/Image/YellowBall.png"));
                break;
            case "N":
            case "":
                Cell.Text = string.Format("<img src='{0}' />", ResolveClientUrl("~/Source/Image/RedBall.png"));
                break;
        }
    }
}