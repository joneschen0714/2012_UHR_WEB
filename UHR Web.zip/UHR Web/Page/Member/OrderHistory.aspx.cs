﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class OrderHistory : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<script type='text/javascript' src='" + ResolveClientUrl("~/Source/Js/jQuery/jquery.validate.pack.js") + "'></script>";
        Page.Header.Controls.Add(new LiteralControl(strCss));

        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //第一次載入
        if (!IsPostBack)
        {
            //取得轉址參數
            string StartDate = Tool.CheckQueryString("sdate");
            string OrderNo = Tool.CheckQueryString("orderno");

            //多國語系
            btnSubmit.Text = Resources.Lang.L000110;
            txtSearchWord.Attributes.Add("value", Resources.Lang.L000188); //載入搜尋預設字

            //載入預設值
            txtSDate.Text = StartDate;
            txtSearchWord.Text = OrderNo;

            gv_GridDataBind(new object(), new EventArgs());
        }
    }

    //資料繫結事件
    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //取得控制項值
        string strSDate = txtSDate.Text.Trim();
        string strEDate = txtEDate.Text.Trim();
        string strKeyword = (txtSearchWord.Text == Resources.Lang.L000188 ? "" : txtSearchWord.Text);

        //會員物件
        MemberInfo mi = Definition.MemberInfo;

        //取得資料來源
        int recordCount;
        DataTable dt = BLL.GetOrderList(null, mi.MemberID, null, strSDate, strEDate, strKeyword, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn(Resources.Lang.L000177, "Date", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000179, "OrderNum", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000103, "Type", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000178, "Attn", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000180, "PO", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000194, "Cancel", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.Center);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataSource = dt;
        gv.DataBind();
    }

    //Grid資料列繫結事件
    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //資料列
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellOrderNum = gv.GetTableCell(e.Row, "OrderNum", true);
            TableCell cellCancel = gv.GetTableCell(e.Row, "Cancel", true);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strOrderNum = Convert.ToString(rowView["OrderNum"]);
            string strCancel = Convert.ToString(rowView["Cancel"]);

            //設定值
            HyperLink link = new HyperLink();
            link.Text = strOrderNum;
            link.NavigateUrl = "~/Page/Member/OrderHistoryDetail.aspx?id=" + strID;
            cellOrderNum.Controls.Add(link);

            //若刪單則顯示圖示
            if (strCancel == "Y")
            {
                Image img = new Image();
                img.ImageUrl = "~/Source/Image/delete.gif";
                cellCancel.Controls.Add(img);
            }
        }
    }
}