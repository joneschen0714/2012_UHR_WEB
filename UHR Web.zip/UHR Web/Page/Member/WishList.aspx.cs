﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Member_WishList : MemberPageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    //初始化
    private new void DataBind()
    {
        //資料來源
        MemberInfo mi = Definition.MemberInfo;
        DataTable dtWishList = BLL.GetWishListData(mi.MemberID);

        //資料繫結
        rpWishList.ItemDataBound += new RepeaterItemEventHandler(rpWishList_ItemDataBound);
        rpWishList.DataSource = dtWishList;
        rpWishList.DataBind();
    }

    protected void rpWishList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //若為資料列
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            DataRowView row = (DataRowView)e.Item.DataItem;

            //取得控制項
            Label lblItem = (Label)e.Item.FindControl("lblItem");
            Label lblBrand = (Label)e.Item.FindControl("lblBrand");
            HyperLink linkProjectorModel = (HyperLink)e.Item.FindControl("linkProjectorModel");
            Label lblLampModule = (Label)e.Item.FindControl("lblLampModule");
            Label lblLampType = (Label)e.Item.FindControl("lblLampType");
            ImageButton imgDelete = (ImageButton)e.Item.FindControl("imgDelete");

            //設定值
            lblItem.Text = Convert.ToString(e.Item.ItemIndex + 1);
            lblBrand.Text = Convert.ToString(row["Brand"]);
            linkProjectorModel.Text = Convert.ToString(row["ProjectorModel"]);
            linkProjectorModel.NavigateUrl = "~/Page/Product/ProductDetail.aspx?id=" + Convert.ToString(row["ID"]);
            lblLampModule.Text = Convert.ToString(row["OEMLampModule"]);
            lblLampType.Text = Convert.ToString(row["OEM_LT"]);
            imgDelete.CommandArgument = Convert.ToString(row["WishListID"]);
        }
    }

    //移除項目
    protected void imgDelete_Click(object sender, EventArgs e)
    {
        ImageButton imgDelete = (ImageButton)sender;
        string strWishListID = imgDelete.CommandArgument;

        BLL.RemoveWishListItem(strWishListID);
        DataBind();
    }
}
