﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using UHR;

public partial class OrderHistoryDetail : MemberPageBase
{
    private string M_ID, M_Back;
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            "#thisDetail { margin-top:10px; border:#cccccc 1px solid; }" +
                            "#thisDetail td.CheckoutTitle { background-color:#707070; color:#ffffff; text-align:center; font-weight:bold; }" +
                            "#thisDetail th { background-color:#eeefe6; text-align:right; vertical-align:top; padding:1px 5px 1px 10px; }" +
                            "#thisDetail td { padding:1px 0 1px 5px; }" +
                            "#thisDetail .bottom { border-bottom:#d9d3d5 1px dashed; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        M_ID = Tool.CheckQueryString("id");
        M_Back = Tool.CheckQueryString("back");

        //多國語系
        btnCancel.Text = Resources.Lang.L000181;
        btnBack.Text = Resources.Lang.L000189;

        //第一次載入
        if (!IsPostBack)
        {
            if (!string.IsNullOrEmpty(M_ID))
            {
                DataBind();
            }
            else
            {
                Response.Redirect("~/Error.htm");
            }
        }
    }

    public override void DataBind()
    {
        //會員物件
        MemberInfo mi = Definition.MemberInfo;

        //取得資料來源
        int recordCount;
        DataTable dt = BLL.GetOrderList(M_ID, null, null, null, null, null, 1, 1, out recordCount);
        DataRow row = dt.Rows[0];

        //判斷資料是否是登入者本人
        if (mi.MemberID == row["Member_ID"].ToString())
        {
            //若已刪單或無ERP對應，則不顯示刪單按鈕
            if (row["Cancel"].ToString() == "Y" || mi.ConnectERP == false)
            {
                //顯示刪單圖示
                if (row["Cancel"].ToString() == "Y")
                {
                    Image imgCanelForm = new Image();
                    imgCanelForm.ImageUrl = "~/Source/Image/stop.png";
                    imgCanelForm.Style.Value = "position:absolute; top:20px; right:10px;";
                    phCancelStatus.Controls.Add(imgCanelForm);
                }

                btnCancel.Visible = false;
            }
            else
            {
                //若已轉入ERP，則不顯示刪單按鈕
                bool bResult = BLL.CheckOrderToERP(mi.ERP_Company, row["OrderNum"].ToString());
                if (bResult)
                {
                    btnCancel.Visible = false;
                }
                else
                {
                    btnCancel.Attributes.Add("onclick", "return confirm('" + Resources.Lang.L000190 + "')");
                }
            }

            //設定值
            lblPurchasedDate.Text = row["Date"].ToString();
            lblOrderNo.Text = row["OrderNum"].ToString();
            lblAttn.Text = row["Attn"].ToString();
            lblPO.Text = row["PO"].ToString();
            lblTel.Text = row["Tel"].ToString();
            lblShippingAddr.Text = row["ShippingAddress"].ToString();
            lblBillingAddr.Text = row["BillingAddress"].ToString();
            lblComment.Text = row["Comment"].ToString();
            btnBack.Visible = (M_Back != "N");

            //附件下載
            if (!string.IsNullOrEmpty(Convert.ToString(row["Attachment"])))
            {
                //檔案路徑設定
                string strPath = "/Source/OrderFile/";
                string strFile = row["Attachment"].ToString();

                //增加控制項
                HyperLink linkFile = new HyperLink();
                linkFile.ImageUrl = "~/Source/Image/save.png";
                linkFile.NavigateUrl = "~/Control/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile);
                phFile.Controls.Add(linkFile);
            }

            //載入購物車
            rpProductList.ItemDataBound += new RepeaterItemEventHandler(rpProductList_ItemDataBound);
            rpProductList.DataSource = DAL.GetOrderItemList(M_ID);
            rpProductList.DataBind();
        }
        else
        {
            Response.Redirect("~/Error.htm");
        }
    }

    protected void rpProductList_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //若為資料列
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            //取得當筆資料來源
            DataRowView row = (DataRowView)e.Item.DataItem;

            //取得產品資訊
            DataRow pRow = BLL.GetProductInfo(row["P_ID"].ToString(), null);

            //取得控制項
            Label lblItem = (Label)e.Item.FindControl("lblItem");
            Label lblType = (Label)e.Item.FindControl("lblType");
            Label lblPN = (Label)e.Item.FindControl("lblPN");
            Label lblProjector = (Label)e.Item.FindControl("lblProjector");
            Label lblOEMLM = (Label)e.Item.FindControl("lblOEMLM");
            Label lblCustomPN = (Label)e.Item.FindControl("lblCustomPN");
            Label lblCustomDESC = (Label)e.Item.FindControl("lblCustomDESC");
            Label lblQty = (Label)e.Item.FindControl("lblQty");

            //設定值
            lblItem.Text = Convert.ToString(e.Item.ItemIndex + 1);
            lblType.Text = ShoppingCartItem.GetProductType(row["Type"].ToString()).ToString();
            lblPN.Text = row["ProductNo"].ToString();
            lblProjector.Text = string.Format("{0} {1}", pRow["Brand"], pRow["ProjectorModel"]);
            lblOEMLM.Text = pRow["OEM_LM"].ToString();
            lblCustomPN.Text = row["CustomPN"].ToString();
            lblCustomDESC.Text = row["CustomDESC"].ToString();
            lblQty.Text = row["Quantity"].ToString();
        }
    }

    protected void btnCancel_OnClick(object sender, EventArgs e)
    {
        //會員物件
        MemberInfo mi = Definition.MemberInfo;
        DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0];

        BLL.CancelOrder(lblOrderNo.Text); //呼叫刪單函式
        btnCancel.Visible = false;
        Page.Header.Controls.Add(Tool.GetJavaScriptContent("alert('" + Resources.Lang.L000144 + "');"));

        #region 判斷Mail樣版
        TemplateMail _template = new TemplateMail("~/Source/Html/OrderCancelation.htm");
        _template["{name}"] = Convert.ToString(rowMember["Name"]);
        _template["{ordernum}"] = lblOrderNo.Text;
        _template["{orderlink}"] = Request.Url.ToString() + "&back=N";
        #endregion

        #region Mail相關設定
        Mail _mail = new Mail();
        _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
        _mail.To.Add(Definition.ContactSalesMail);
        _mail.CC.Add(mi.Email);

        _mail.Subject = "Order Cancelation Notice!" + string.Format(" [{0} - {1}] - {2}", rowMember["Company"], rowMember["Name"], lblOrderNo.Text);
        _mail.Body = _template.ToString();
        _mail.IsBodyHtml = true;
        _mail.SendMail();
        _mail.Dispose();
        #endregion

        Response.Redirect("OrderHistory.aspx?orderno=" + lblOrderNo.Text);
    }
}