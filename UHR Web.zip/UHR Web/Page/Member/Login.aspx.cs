﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Member_Login : System.Web.UI.Page
{
    //初始化
    protected void Page_Load(object sender, EventArgs e)
    {
        //多國語系
        btnSignIn.Text = Resources.Lang.L000038;

        //第一次進入點
        if (!IsPostBack)
        {
            //判斷是否登入
            if (MemberInfo.CheckLogin)
            {
                //頁面轉址
                if (Redirect != "") Response.Redirect(Redirect);
                else Response.Redirect("Index.aspx");
            }
            else
            {
                //若帳號密碼不為空白
                if (UID != "" && PWD != "")
                {
                    //登入驗証
                    DataTable dtMember = BLL.MemberLogin(UID, PWD);
                    if (dtMember.Rows.Count > 0)
                    {
                        //變數
                        DataRow rowMember = dtMember.Rows[0];
                        string strID = Convert.ToString(rowMember["ID"]);
                        string strName = Convert.ToString(rowMember["Name"]);
                        string strLevel = Convert.ToString(rowMember["Level"]);
                        string strSalesMail = Convert.ToString(rowMember["ContactSalesMail"]);
                        string strCurrency = Convert.ToString(rowMember["Currency"]);
                        string strERP_Company = Convert.ToString(rowMember["ERP_Company"]);
                        string strERP_CustomCode = Convert.ToString(rowMember["ERP_CustomCode"]);

                        //設定登入記錄
                        MemberInfo.SetMemberInfo(strID,strName, UID, strLevel, strSalesMail, strCurrency, strERP_Company, strERP_CustomCode);

                        //自動登入功能
                        if (NextVisit)
                        {
                            //寫入Cookie
                            HttpCookie cookie = new HttpCookie("AutoLogin");
                            cookie.Values.Add("MemberID", strID);
                            cookie.Expires = DateTime.Now.AddYears(1);
                            Response.Cookies.Add(cookie);
                        }

                        //頁面轉址
                        if (Redirect != "") Response.Redirect(Redirect);
                        else Response.Redirect("~/Default.aspx");
                    }
                    else
                    {
                        Response.Redirect("~/Page/Member/LoginFailure.aspx"); //登入失敗
                    }
                }
                else
                {
                    MemberRegister1.DataBind("");
                }
            }
        }
    }

    //登入動作
    protected void btnSignIn_Click(object sender, EventArgs e)
    {
        //變數
        string strUrl = Request.Url.OriginalString;
        string strUid = txtEmail.Text.Trim();
        string strPwd = txtPassword.Text.Trim();
        string strNextVisit = cbNextVisit.Checked.ToString().ToLower();

        //組成Url
        strUrl = Tool.SetUrlParam(strUrl, "uid", strUid);
        strUrl = Tool.SetUrlParam(strUrl, "pwd", strPwd);
        strUrl = Tool.SetUrlParam(strUrl, "nextvisit", strNextVisit);

        //轉向登入頁
        Response.Redirect(strUrl);
    }


    //屬性-會員帳號
    private string UID
    {
        get { return Tool.CheckQueryString("uid"); }
    }

    //屬性-會員密碼
    private string PWD
    {
        get { return Tool.CheckQueryString("pwd"); }
    }

    //屬性-是否下次登入
    private bool NextVisit
    {
        get { return bool.Parse(Tool.CheckQueryString("nextvisit")); }
    }

    //屬性-目標頁面
    private string Redirect
    {
        get
        { return Tool.CheckQueryString("redirect"); }
    }
}