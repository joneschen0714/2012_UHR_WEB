﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using UHR;

public partial class Page_Member_CheckOut : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            "#thisDetail { margin-top:10px; border:#cccccc 1px solid; }" +
                            "#thisDetail td.CheckoutTitle { background-color:#707070; color:#ffffff; text-align:center; font-weight:bold; }" +
                            "#thisDetail th { background-color:#eeefe6; text-align:right; vertical-align:top; padding:1px 5px 1px 10px; }" +
                            "#thisDetail td { padding:1px 0 1px 5px; }" +
                            "#thisDetail .bottom { border-bottom:#d9d3d5 1px dashed; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //多國語系
            linkContinue.Text = Resources.Lang.L000136;
            btnSubmit.Text = Resources.Lang.L000110;

            SetMemberInfo();
            DataBind();
        }
    }

    //初始化
    private new void DataBind()
    {
        ShoppingCart sc = Definition.ShoppingCart;

        //設定訂單類別
        if (sc.OrderType != "")
        {
            DataTable dtOrderType = BLL.GetConfigData("OrderType");
            lblOrderType.Text = dtOrderType.Select("Value='" + sc.OrderType + "'")[0]["Name"].ToString();
        }

        //設定訂單明細
        rpItems.ItemDataBound += new RepeaterItemEventHandler(rpItems_ItemDataBound);
        rpItems.DataSource = sc;
        rpItems.DataBind();
    }
    protected void rpItems_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //若為資料列
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            //取得當筆資料來源
            ShoppingCartItem _item = (ShoppingCartItem)e.Item.DataItem;

            //取得控制項
            Label lblItem = (Label)e.Item.FindControl("lblItem");
            Label lblType = (Label)e.Item.FindControl("lblType");
            Label lblPN = (Label)e.Item.FindControl("lblPN");
            HyperLink linkProjectorModel = (HyperLink)e.Item.FindControl("linkProjectorModel");
            Label lblLampModule = (Label)e.Item.FindControl("lblLampModule");
            Label lblCustomPN = (Label)e.Item.FindControl("lblCustomPN");
            Label lblCustomDesc = (Label)e.Item.FindControl("lblCustomDesc");
            Label lblQuantity = (Label)e.Item.FindControl("lblQuantity");
            Label lblUnitPrice = (Label)e.Item.FindControl("lblUnitPrice");
            Label lblSubTotal = (Label)e.Item.FindControl("lblSubTotal");

            //設定值
            lblItem.Text = Convert.ToString(e.Item.ItemIndex + 1);
            lblType.Text = _item.Type.ToString();
            lblPN.Text = _item.ProductNo;
            linkProjectorModel.Text = _item.Brand + " " + _item.ProjectorModel;
            linkProjectorModel.NavigateUrl = "~/Page/Product/ProductDetail.aspx?id=" + _item.ProjectorID;
            lblLampModule.Text = _item.OEMLampModule;
            lblCustomPN.Text = _item.CustomPN;
            lblCustomDesc.Text = _item.CustomDESC;
            lblQuantity.Text = Convert.ToString(_item.Quantity);

            //設定價格
            if (_item.UnitPrice != null)
            {
                lblUnitPrice.Text = string.Format("{0}({1})", _item.UnitPrice, _item.Currency);
                lblSubTotal.Text = string.Format("{0}({1})", _item.SubTotalPrice, _item.Currency);
            }
            else
            {
                lblUnitPrice.Text = "-";
                lblSubTotal.Text = "-";
            }
        }
    }

    //設定基本預設資料
    private void SetMemberInfo()
    {
        //取得會員資料
        MemberInfo mi = Definition.MemberInfo;
        DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0];

        //設定會員基本資料
        lblName.Text = Convert.ToString(rowMember["Name"]);
        lblEmail.Text = Convert.ToString(rowMember["Email"]);
        lblCompany.Text = Convert.ToString(rowMember["Company"]);

        //是否可存取ERP
        if (mi.ConnectERP)
        {
            DataRow rowERPMember = BLL.GetERPMemerProfile(mi.ERP_Company, mi.ERP_CustomCode); //取得ERP客戶基本資料

            txtAttn.Text = Convert.ToString(rowERPMember["Attn"]);
            txtTel.Text = Convert.ToString(rowERPMember["Tel"]);
            txtShippingAddress.Text = Convert.ToString(rowERPMember["ShippAddr"]);
            txtBillingAddress.Text = Convert.ToString(rowERPMember["BillAddr"]);
        }
        else
        {
            //若有訂單記錄，則帶入上一次記錄
            DataRow rowOrder = BLL.GetLastOrder(Definition.MemberInfo.MemberID);
            if (rowOrder != null)
            {
                txtAttn.Text = Convert.ToString(rowOrder["Attn"]);
                txtTel.Text = Convert.ToString(rowOrder["Tel"]);
                txtShippingAddress.Text = Convert.ToString(rowOrder["ShippingAddress"]);
                txtBillingAddress.Text = Convert.ToString(rowOrder["BillingAddress"]);
            }
        }
    }

    //送出單子動作
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        ShoppingCart sc = Definition.ShoppingCart;
        MemberInfo mi = Definition.MemberInfo;

        //變數
        bool bFile = true;
        string strFileName = "", strFilePath = "";
        string strMemberID = mi.MemberID;
        string strEmail = lblEmail.Text.Trim();
        string strAttn = txtAttn.Text.Trim();
        string strPO = txtPO.Text.Trim();
        string strTel = txtTel.Text.Trim();
        string strShipAddress = txtShippingAddress.Text.Trim();
        string strBillingAddress = txtBillingAddress.Text.Trim();
        string strComment = txtComment.Text.Replace(System.Environment.NewLine, "<br />");
        string strEmailCC = txtEmailCC.Text.Trim(',', ' ');

        #region 上傳檔案
        if (file.HasFile)
        {
            //判斷檔案大小
            if (file.PostedFile.ContentLength <= 500000)
            {
                //上傳檔案
                strFileName = "Attachment_" + DateTime.Now.ToString("yyyyMMddhhmmss") + System.IO.Path.GetExtension(file.FileName).ToLower();
                string strPath = Server.MapPath("~/Source/OrderFile/");
                strFilePath = strPath + strFileName;
                file.SaveAs(strFilePath);
            }
            else
            {
                bFile = false;
                Page.Header.Controls.Add(Tool.GetJavaScriptContent("$.prompt('" + Resources.Lang.L000175 + "');"));
            }
        }
        #endregion

        #region 若新增詢價記錄成功
        if (bFile)
        {
            //取得新訂單編號
            string strOrderNum = BLL.GetNewOrderNumber();

            //寫入訂單記錄
            bool bOrderResult = BLL.AddOrder(strMemberID, strOrderNum, sc.OrderType, strAttn, strPO, strTel, strShipAddress, strBillingAddress, strComment, strFileName, strEmailCC, sc);
            if (bOrderResult)
            {
                DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0];
                DataRow rowCountry = BLL.GetCountryList(rowMember["Country"].ToString()).Rows[0];

                #region 建立附件 CSV檔
                string strPath = Server.MapPath("~/Source/Temp/InquiryList_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".csv");
                System.IO.StreamWriter sw = new System.IO.StreamWriter(strPath, true, System.Text.Encoding.Default);
                sw.WriteLine("\"Item\",\"Type\",\"Status\",\"UHR P/N\",\"Brand\",\"Project Model\",\"OEM Lamp Module #\",\"Customer P/N\",\"Product Description\",\"Quantity\",\"Currency\",\"Unit Price\",\"Sub Total\",\"Title\",\"Description\""); //建立Header

                //建立Items
                string strItems = "";
                for (int i = 0; i < sc.Count; i++)
                {
                    //變數
                    ShoppingCartItem sci = sc[i];

                    //設定價格
                    string strUnitPrice = "", strSubTotal = "";
                    if (sci.UnitPrice != null)
                    {
                        strUnitPrice = string.Format("{0}({1})", sci.UnitPrice, sci.Currency);
                        strSubTotal = string.Format("{0}({1})", sci.SubTotalPrice, sci.Currency);
                    }
                    else
                    {
                        strUnitPrice = "-";
                        strSubTotal = "-";
                    }

                    //Product Status
                    DataRow rowProductInfo = BLL.GetProductInfo(sci.ProjectorID, null);
                    string strStatus = "";
                    if (sci.Type == ShoppingCartItem.ProductType.LampModule)
                        strStatus = BLL.GetConfigName("ProductStatus", rowProductInfo["UHR_LM_Status"].ToString());
                    else if (sci.Type == ShoppingCartItem.ProductType.Bulb)
                        strStatus = BLL.GetConfigName("ProductStatus", rowProductInfo["UHR_BL_Status"].ToString());

                    //Title & Description
                    string strTitle = "", strDescription = "";
                    DataTable dtPriceTitle = BLL.GetMemberPrice(mi.MemberID, sc.OrderType, sci.ProductNo, sci.Quantity.ToString());
                    if (dtPriceTitle.Rows.Count > 0)
                    {
                        strTitle = Convert.ToString(dtPriceTitle.Rows[0]["Title"]);
                        strDescription = Convert.ToString(dtPriceTitle.Rows[0]["Description"]);
                    }

                    string strItem = string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\",\"{9}\",\"{10}\",\"{11}\",\"{12}\",\"{13}\",\"{14}\"", i + 1, sci.Type, strStatus, sci.ProductNo, sci.Brand, sci.ProjectorModel, sci.OEMLampModule, sci.CustomPN, sci.CustomDESC, sci.Quantity, sci.Currency, sci.UnitPrice, sci.SubTotalPrice, strTitle, strDescription);
                    sw.WriteLine(strItem);

                    strItems += string.Format("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td><td>{4}</td><td>{5}</td><td>{6}</td><td>{7}</td><td>{8}</td><td>{9}</td><td>{10}</td><td>{11}</td></tr>", i + 1, sci.Type, strStatus, sci.ProductNo, sci.Brand, sci.ProjectorModel, sci.OEMLampModule, sci.CustomPN, sci.CustomDESC, sci.Quantity, strUnitPrice, strSubTotal);
                }

                //建立Total
                sw.WriteLine(",,,,,,,,\"Total\",\"{0}\",,,\"{1}\",,", sc.TotalQuantity, Tool.GetValue(sc.TotalAmount, "-"));
                strItems += "<tr style='font-weight:bold;'><td colspan='8'></td><td>Total</td><td>" + sc.TotalQuantity + "</td><td></td><td>" + Tool.GetValue(sc.TotalAmount, "-") + "</td></tr>";

                sw.Close();
                sw.Dispose();
                #endregion

                #region Mail內容參數
                //判斷Mail樣版
                TemplateMail _template = sc.OrderTypeObject.MailTemplate;
                _template["{name}"] = Convert.ToString(rowMember["Name"]);
                _template["{ordernum}"] = strOrderNum;
                _template["{company}"] = Convert.ToString(rowMember["Company"]);
                _template["{email}"] = strEmail;
                _template["{tel1}"] = Convert.ToString(rowMember["Tel"]);
                _template["{country}"] = Convert.ToString(rowCountry["Name"]);

                _template["{date}"] = DateTime.Now.ToString();
                _template["{attnto}"] = strAttn;
                _template["{pono}"] = strPO;
                _template["{tel}"] = strTel;
                _template["{type}"] = lblOrderType.Text;
                _template["{shippingaddress}"] = strShipAddress;
                _template["{billingaddress}"] = strBillingAddress;
                _template["{comment}"] = strComment;
                _template["{Items}"] = strItems;
                #endregion

                #region Mail相關設定
                strEmailCC = ((strEmailCC != "") ? ("," + strEmailCC) : "");

                Mail _mail = new Mail();
                _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
                _mail.To.Add(strEmail + strEmailCC);
                _mail.CC.Add(Definition.ContactSalesMail);

                /*
                //若為A、B級客戶，則BCC給Long
                if (mi.Level == "A" || mi.Level == "B")
                    _mail.Bcc.Add("lchen@arclite.com.tw");
                */

                _mail.Subject = sc.OrderTypeObject.MailSubject + string.Format(" [{0} - {1}] - {2}", rowMember["Company"], rowMember["Name"], strOrderNum);
                _mail.Body = _template.ToString();
                _mail.IsBodyHtml = true;
                _mail.Attachments.Add(new Attachment(strPath));
                if (strFilePath != "") { _mail.Attachments.Add(new Attachment(strFilePath)); } //增加附檔
                _mail.SendMail();
                _mail.Dispose();
                #endregion

                Definition.ShoppingCart.Clear(); //清除購物車記錄

                //刪除Temp CSV檔
                System.IO.FileInfo fi = new System.IO.FileInfo(strPath);
                fi.Delete();

                Response.Redirect("~/Page/Member/CheckOutResult.aspx"); //轉向Result頁面
            }
            else
            {
                Page.Header.Controls.Add(Tool.GetJavaScriptContent("$.prompt('Is unable to send out, please again try one time.');"));
            }
        }
        #endregion
    }
}