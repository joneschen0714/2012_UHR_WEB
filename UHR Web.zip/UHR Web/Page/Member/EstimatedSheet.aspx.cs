﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Member_EstimatedSheet : MemberPageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //多國語系
            linkCheckOut.Text = Resources.Lang.L000031;
            btnUpdateQty.Text = Resources.Lang.L000095;
            linkContinue.Text = Resources.Lang.L000157;

            DataBind();

            //若Type=T則更新價格
            if (Definition.ShoppingCart.OrderType == "T")
                btnUpdateQty_Click(new object(), new EventArgs());
        }
    }

    //初始化
    private new void DataBind()
    {
        //載入OrderType選單
        rblOrderType.DataSource = BLL.GetMemberPriceTitle(Definition.MemberInfo.MemberID);
        rblOrderType.DataBind();

        //載入購物車
        rpShoppingCart.ItemDataBound += new RepeaterItemEventHandler(rpShoppingCart_ItemDataBound);
        rpShoppingCart.DataSource = Definition.ShoppingCart;
        rpShoppingCart.DataBind();

        //設定OrderType值
        if (Definition.ShoppingCart.OrderType != "")
        {
            rblOrderType.SelectedValue = Definition.ShoppingCart.OrderType;
        }
        else
        {
            //若只有1個Type，則指定1個，否則預設為N
            if (rblOrderType.Items.Count == 1)
            {
                rblOrderType.Items[0].Selected = true;
                rblOrderType_SelectIndexChanged(new object(), new EventArgs());
            }
        }

        //顯示區域切換
        if (Definition.ShoppingCart.Count > 0)
        {
            palCheckOut.Visible = true;

            if (rblOrderType.Items.Count > 0)
                tbOrderType.Visible = true;
            else
                tbOrderType.Visible = false;
        }
        else
        {
            tbOrderType.Visible = false;
            palCheckOut.Visible = false;
        }
    }

    //訂單類別切換
    protected void rblOrderType_SelectIndexChanged(object sender, EventArgs e)
    {
        //更新訂單類別
        Definition.ShoppingCart.OrderType = rblOrderType.SelectedValue;

        btnUpdateQty_Click(sender, e); //更新項目數量與價格
    }

    protected void rpShoppingCart_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        //若為資料列
        if (e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
        {
            //取得當筆資料來源
            ShoppingCartItem _item = (ShoppingCartItem)e.Item.DataItem;

            //取得控制項
            Label lblItem = (Label)e.Item.FindControl("lblItem");
            Label lblType = (Label)e.Item.FindControl("lblType");
            HiddenField hiddenType = (HiddenField)e.Item.FindControl("hiddenType");
            Label lblPN = (Label)e.Item.FindControl("lblPN");
            HyperLink linkProjectorModel = (HyperLink)e.Item.FindControl("linkProjectorModel");
            Label lblLampModule = (Label)e.Item.FindControl("lblLampModule");
            TextBox txtCustomPN = (TextBox)e.Item.FindControl("txtCustomPN");
            TextBox txtDesc = (TextBox)e.Item.FindControl("txtDesc");
            TextBox txtQty = (TextBox)e.Item.FindControl("txtQty");
            Label lblUnitPrice = (Label)e.Item.FindControl("lblUnitPrice");
            Label lblSubTotal = (Label)e.Item.FindControl("lblSubTotal");
            ImageButton imgDelete = (ImageButton)e.Item.FindControl("imgDelete");
            HiddenField hiddenProjectorID = (HiddenField)e.Item.FindControl("hiddenProjectorID");

            string strType = ShoppingCartItem.GetProductTypeValue(_item.Type);

            //設定值
            lblItem.Text = Convert.ToString(e.Item.ItemIndex + 1);
            lblType.Text = _item.Type.ToString();
            hiddenType.Value = strType;
            lblPN.Text = _item.ProductNo;
            linkProjectorModel.Text = _item.Brand + " " + _item.ProjectorModel;
            linkProjectorModel.NavigateUrl = "~/Page/Product/ProductDetail.aspx?id=" + _item.ProjectorID;
            lblLampModule.Text = _item.OEMLampModule;
            txtCustomPN.Text = _item.CustomPN;
            txtDesc.Text = _item.CustomDESC;
            txtQty.Text = Convert.ToString(_item.Quantity);
            imgDelete.CommandArgument = (_item.ProjectorID + "," + strType);
            hiddenProjectorID.Value = _item.ProjectorID;

            //判斷是否連接ERP
            if (MemberInfo.Get().ConnectERP)
            {
                //增加控制項屬性
                txtCustomPN.Attributes.Add("onclick", "GetCustomPN('" + (e.Item.ItemIndex + 1) + "','" + _item.ProjectorID + "','" + ShoppingCartItem.GetProductTypeValue(_item.Type) + "')");
                txtDesc.Attributes.Add("onclick", "GetCustomPN('" + (e.Item.ItemIndex + 1) + "','" + _item.ProjectorID + "','" + ShoppingCartItem.GetProductTypeValue(_item.Type) + "')");
            }
            else
            {
                //增加控制項屬性
                txtCustomPN.Attributes.Add("onchange", "UpdateCustomPN('" + (e.Item.ItemIndex + 1) + "','" + _item.ProjectorID + "','" + ShoppingCartItem.GetProductTypeValue(_item.Type) + "')");
                txtDesc.Attributes.Add("onchange", "UpdateCustomPN('" + (e.Item.ItemIndex + 1) + "','" + _item.ProjectorID + "','" + ShoppingCartItem.GetProductTypeValue(_item.Type) + "')");
            }

            //設定價格
            if (_item.UnitPrice != null)
            {
                lblUnitPrice.Text = string.Format("{0}({1})", _item.UnitPrice, _item.Currency);
                lblSubTotal.Text = string.Format("{0}({1})", _item.SubTotalPrice, _item.Currency);
            }
            else
            {
                lblUnitPrice.Text = "-";
                lblSubTotal.Text = "-";
            }
        }
    }

    //移除項目
    protected void imgDelete_Click(object sender, EventArgs e)
    {
        //變數
        string strArgument = ((ImageButton)sender).CommandArgument;
        string strPjID = strArgument.Split(',')[0];
        string strType = strArgument.Split(',')[1];
        ShoppingCartItem.ProductType pt = ShoppingCartItem.GetProductType(strType);

        Definition.ShoppingCart.Remove(strPjID, pt);
        DataBind();
    }

    //更新數量
    protected void btnUpdateQty_Click(object sender, EventArgs e)
    {
        //循序讀取購物項目
        foreach (RepeaterItem ri in rpShoppingCart.Items)
        {
            //變數
            string strPjID = ((HiddenField)ri.FindControl("hiddenProjectorID")).Value;
            string strType = ((HiddenField)ri.FindControl("hiddenType")).Value;
            ShoppingCartItem.ProductType pt = ShoppingCartItem.GetProductType(strType);
            string strQty = ((TextBox)ri.FindControl("txtQty")).Text.Trim();

            //數量轉型
            int iQty;
            int.TryParse(strQty, out iQty);

            //若數量大於0則更新
            if (iQty > 0)
            {
                ShoppingCartItem sci = Definition.ShoppingCart.Get(strPjID, pt);
                sci.Quantity = iQty;

                Definition.ShoppingCart.UpdatePrice(strPjID, pt); //更新價格
            }
        }

        DataBind();
    }

    //Check Out
    protected void linkCheckOut_Click(object sender, EventArgs e)
    {
        string strMessage = "";
        if ((rblOrderType.Items.Count > 0 && Definition.ShoppingCart.OrderType != "") || rblOrderType.Items.Count == 0)
        {
            btnUpdateQty_Click(sender, e); //更新數量

            bool bCheck = Definition.ShoppingCart.OrderTypeObject.CheckData(ref strMessage); //檢查函式

            if (bCheck)
                Response.Redirect("~/Page/Member/CheckOut.aspx"); //轉向CheckOut頁面
            else
                lblMsg.Text = strMessage;
        }
        else
        {
            lblMsg.Text = Resources.Lang.L000160;
        }
    }
}
