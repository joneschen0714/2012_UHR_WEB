﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class FAQDetail : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            ".MainTable { width:100%; border-collapse:collapse; margin:0 0 10px 0; }" +
                            ".MainTable th { background-color:#f9f5c6; border:#a9a9a9 1px dashed; vertical-align:top; }" +
                            ".MainTable td { border:#a9a9a9 1px dashed; padding:0 0 0 5px;}" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));

        repReplyFAQ.ItemDataBound += new RepeaterItemEventHandler(repReplyFAQ_ItemDataBound);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            DataBind();
        }
    }

    public override void DataBind()
    {
        string FAQ_ID = Tool.CheckQueryString("id");

        DataTable dtResult = BLL.GetFAQDetail(FAQ_ID);

        #region 主要內容
        DataRow row = dtResult.Select("c_ID IS NULL")[0];

        //驗証身份
        if (Definition.MemberInfo.MemberID != Convert.ToString(row["Member_ID"])) { throw new Exception(); }

        lblName.Text = Convert.ToString(row["Name"]);
        lblCreateDate.Text = Convert.ToDateTime(row["UpdateTime"]).ToString("yyyy-MM-dd");
        lblType.Text = Convert.ToString(row["Type"]);
        lblSubject.Text = Convert.ToString(row["Subject"]);
        lblContents.Text = Convert.ToString(row["Contents"]);
        #endregion

        repReplyFAQ.DataSource = dtResult.Select("c_ID="+ FAQ_ID);
        repReplyFAQ.DataBind();
    }

    protected void repReplyFAQ_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType == ListItemType.Item || e.Item.ItemType == ListItemType.AlternatingItem)
        {
            DataRow rowView = (DataRow)e.Item.DataItem;

            Label lblName = (Label)e.Item.FindControl("lblName");
            Label lblDate = (Label)e.Item.FindControl("lblDate");
            Label lblSubject = (Label)e.Item.FindControl("lblSubject");
            Label lblContents = (Label)e.Item.FindControl("lblContents");

            lblName.Text = Convert.ToString(rowView["Name"]);
            lblDate.Text = Convert.ToDateTime(rowView["UpdateTime"]).ToString("yyyy-MM-dd");
            lblSubject.Text = Convert.ToString(rowView["Subject"]);
            lblContents.Text = Convert.ToString(rowView["Contents"]);
        }
    }
}