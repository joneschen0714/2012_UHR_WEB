﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using System.Linq;
using UHR;

public partial class OrderImport : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            "div.preview { line-height:16px; margin-top:20px; padding:5px; border:#a9a9a9 1px solid; }" +
                            "div.preview .tt { width:100%; border-left:#cccccc 1px solid; border-right:#cccccc 1px solid; border-top:#cccccc 1px solid; border-bottom-style:none; } " +
                            "div.preview .tt th { padding:3px 10px 3px 5px; background-color:#eeeeee; text-align:left; border:none; border-bottom:#cccccc 1px solid; } " +
                            "div.preview .tt td { padding:3px 10px 3px 5px; border-top-style:none; border-left-style:none; border-right-style:none; border-bottom:#cccccc 1px solid; } " +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //多國語系
        btnExport.Text = Resources.Lang.L000203;
        btnUpload.Text = Resources.Lang.L000206;
        btnPreView.Text = Resources.Lang.L000200;
        btnCancel.Text = Resources.Lang.L000201;
        linkFormat.Text = Resources.Lang.L000199;

        //第一次載入
        if (!IsPostBack)
        {
            //載入OrderType選單
            rblOrderType.DataSource = BLL.GetMemberPriceTitle(Definition.MemberInfo.MemberID);
            rblOrderType.DataBind();

            //若只有1個Type，則為預設
            if (rblOrderType.Items.Count == 1)
            {
                rblOrderType.Items[0].Selected = true;
            }

            //檔案連結
            linkFormat.NavigateUrl = "~/Control/DownloadFile.aspx?FilePath=" + Server.UrlEncode("/Page/Member/Format/") + "&FileName=" + Server.UrlEncode("ImportOrderFormat.csv");
        }
    }

    protected void btnExport_Click(object sender, EventArgs e)
    {
        if (rblOrderType.SelectedValue != "")
        {
            //會員物件
            MemberInfo mi = Definition.MemberInfo;

            //取得庫存列表
            DataTable dtNews = BLL.GetInvertoryList(mi.MemberID, rblOrderType.SelectedValue);

            //檔案路徑設定
            string strPath = "/Source/Temp/";
            string strFile = "ExportData.csv";
            string strFilePath = Server.MapPath("~" + strPath + strFile);

            //轉出與下載Excel
            Tool.DataTableToCSV(dtNews, strFilePath);
            Response.Redirect("~/Control/DownloadFile.aspx?FilePath=" + Server.UrlEncode(strPath) + "&FileName=" + Server.UrlEncode(strFile));
        }
        else
        {
            lblMsg.Text = Resources.Lang.L000185;
        }
    }

    protected void btnPreView_Click(object sender, EventArgs e)
    {
        List<string> listProduct = new List<string>();

        if (rblOrderType.SelectedValue != "")
        {
            if (file.HasFile)
            {
                //上傳檔案
                string strFileName = "OrderUpload.csv";
                string strPath = Server.MapPath("~/Source/Temp/");
                file.SaveAs(strPath + strFileName);

                //載入Excel
                DataTable dt = Tool.GetDataSetFromCSV(strPath, strFileName);

                //檢查收件人、地址、電話是否都有填寫
                DataRow[] rows = dt.Select("[Recipient/Company] is null or [Shipping address] is null or [Contact Tel] is null");
                if (rows.Length == 0)
                {
                    //新增欄位
                    dt.Columns.Add("OrderNumber", Type.GetType("System.String"));
                    dt.Columns.Add("UnitPrice", Type.GetType("System.Decimal"));
                    dt.Columns.Add("SubTotal", Type.GetType("System.Decimal"));

                    //會員登入物件
                    MemberInfo mi = Definition.MemberInfo;

                    //循序讀取資料列
                    foreach (DataRow row in dt.Rows)
                    {
                        //變數
                        string ProductNo = row["UHR P/N"].ToString();
                        int Quantity = Convert.ToInt32(row["Quantity"]);

                        try
                        {
                            //取得對應的價格
                            DataTable dtPrice = BLL.GetMemberPrice(mi.MemberID, rblOrderType.SelectedValue, ProductNo, Quantity.ToString());
                            decimal UnitPrice = Convert.ToDecimal(dtPrice.Rows[0]["Price"]);
                            decimal TotalPrice = Quantity * UnitPrice;

                            //回寫價格至暫存表
                            row["UnitPrice"] = UnitPrice;
                            row["SubTotal"] = TotalPrice;
                        }
                        catch
                        {
                            listProduct.Add(ProductNo);//增加品名至錯誤區
                        }
                    }

                    if (listProduct.Count < 1)
                    {
                        dtSessionOrderList = dt; //儲存至Session

                        //按訂單分類
                        var g = from t in dt.AsEnumerable()
                                group t by new
                                {
                                    ShippingAddress = t["Shipping Address"],
                                    Recipient = t["Recipient/Company"],
                                    ContactTel = t["Contact Tel"],
                                    PO = t["PO NO#"],
                                    Remark = t["Remark"]
                                };

                        //組成預覽Html
                        string strRreview = "";
                        foreach (var gp in g)
                        {
                            string st = "<div class='preview'>" +
                                        "Recipient/Company：{0} <br/> " +
                                        "Contact Tel：{1} <br/> " +
                                        "PO NO.：{2} <br/> " +
                                        "Shipping address：{3} <br/> " +
                                        "Remark：{4} <br/> ";

                            strRreview += string.Format(st, gp.Key.Recipient, gp.Key.ContactTel, gp.Key.PO, gp.Key.ShippingAddress, gp.Key.Remark);

                            st = "<table class='tt' cellpadding='0' cellspacing='0'><tr><th>UHR P/N</th><th>Custom P/N</th><th>Product Description</th><th>Quantity</th><th>Unit Price</th><th>Sub Total</th></tr>";
                            foreach (var i in gp)
                            {
                                st += "<tr><td>" + i["UHR P/N"] + "</td>" +
                                          "<td>" + i["Customer P/N"] + "</td>" +
                                          "<td>" + i["Product Description"] + "</td>" +
                                          "<td>" + i["Quantity"] + "</td>" +
                                          "<td>" + mi.Currency + " " + i["UnitPrice"] + "</td>" +
                                          "<td>" + mi.Currency + " " + i["SubTotal"] + "</td></tr>";
                            }
                            st += "</table></div>";
                            strRreview += st;
                        }

                        liPreView.Text = strRreview;

                        //顯示上傳按鈕
                        if (liPreView.Text != "")
                        {
                            btnPreView.Enabled = false;
                            palButton.Visible = true;
                        }
                    }
                    else
                    {
                        //錯誤訊息
                        foreach (string s in listProduct)
                        {
                            lblMsg.Text += s + " " + Resources.Lang.L000202 + "<br/>";
                        }
                    }
                }
                else
                {
                    lblMsg.Text = Resources.Lang.L000205;
                }
            }
        }
        else
        {
            lblMsg.Text = Resources.Lang.L000185;
        }
    }

    protected void btnUpload_Click(object sender, EventArgs e)
    {
        //呼叫匯入函式
        string strMsg = "";
        bool bResult = BLL.ImportOrderList(rblOrderType.SelectedValue, dtSessionOrderList, ref strMsg);

        if (bResult)
        {
            #region Mail模版
            var maxOrderNum = dtSessionOrderList.AsEnumerable().Max(p => p["OrderNumber"]);
            var minOrderNum = dtSessionOrderList.AsEnumerable().Min(p => p["OrderNumber"]);

            MemberInfo mi = Definition.MemberInfo;
            DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0];
            DataRow rowCountry = BLL.GetCountryList(rowMember["Country"].ToString()).Rows[0];

            TemplateMail _template = new TemplateMail("~/Source/Html/OrderImport.htm");
            _template["{name}"] = Convert.ToString(rowMember["Name"]);
            _template["{StartOrderNum}"] = minOrderNum.ToString();
            _template["{EndOrderNum}"] = maxOrderNum.ToString();
            _template["{ordertype}"] = rblOrderType.SelectedItem.Text;
            _template["{email}"] = Convert.ToString(rowMember["Email"]);
            _template["{company}"] = Convert.ToString(rowMember["Company"]);
            _template["{billingaddress}"] = Convert.ToString(rowMember["Address"]);
            _template["{tel1}"] = Convert.ToString(rowMember["Tel"]);
            _template["{country}"] = Convert.ToString(rowCountry["Name"]);
            #endregion

            #region Mail 子模版
            //按訂單分類
            var grouped = from t in dtSessionOrderList.AsEnumerable()
                          group t by new
                          {
                              OrderNumber = t["OrderNumber"],
                              ShippingAddress = t["Shipping Address"],
                              Recipient = t["Recipient/Company"],
                              ContactTel = t["Contact Tel"],
                              PO = t["PO NO#"],
                              Remark = t["Remark"]
                          } into g
                          select new
                          {
                              g.Key,
                              TotalQty = g.Sum(x => (int)x["Quantity"]),
                              TotalPrice = g.Sum(x => (decimal)x["SubTotal"]),
                              Items = g
                          };

            string strRreview = "";
            foreach (var gp in grouped)
            {
                string st = "<div class='preview'>" +
                            "Purchased Date：{0} <br/> " +
                            "Order Number：{1} <br/> " +
                            "Recipient/Company：{2} <br/> " +
                            "Contact Tel：{3} <br/> " +
                            "PO NO.：{4} <br/> " +
                            "Shipping address：{5} <br/> " +
                            "Remark：{6} <br/> ";

                strRreview += string.Format(st, DateTime.Now.ToString(), gp.Key.OrderNumber, gp.Key.Recipient, gp.Key.ContactTel, gp.Key.PO, gp.Key.ShippingAddress, gp.Key.Remark);

                st = "<table class='tt' cellpadding='0' cellspacing='0' rules='cols'><tr><th>Item</th><th>UHR P/N</th><th>Customer P/N</th><th>Product Description</th><th>Quantity</th><th>Unit Price</th><th>Sub Total</th></tr>";

                int index = 1;
                foreach (var i in gp.Items)
                {
                    st += "<tr><td>" + index.ToString() + "</td>" +
                              "<td>" + i["UHR P/N"] + "</td>" +
                              "<td>" + i["Customer P/N"] + "</td>" +
                              "<td>" + i["Product Description"] + "</td>" +
                              "<td>" + i["Quantity"] + "</td>" +
                              "<td>" + mi.Currency + " " + i["UnitPrice"] + "</td>" +
                              "<td>" + mi.Currency + " " + i["SubTotal"] + "</td></tr>";

                    index++;
                }
                st += "<tr style='font-weight:bold;'><td colspan='4' align='right'>Total</td><td>" + gp.TotalQty + "</td><td></td><td>" + mi.Currency + " " + gp.TotalPrice + "</td></tr>";
                st += "</table></div>";
                strRreview += st;
            }

            _template["{Items}"] = strRreview;
            #endregion

            #region Mail相關設定
            Mail _mail = new Mail();
            _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
            _mail.To.Add(mi.Email);
            _mail.CC.Add(Definition.ContactSalesMail);

            _mail.Subject = string.Format("Order Confirmation Notice! [{0} - {1}] - {2} ~ {3}", rowMember["Company"], rowMember["Name"], minOrderNum, maxOrderNum);
            _mail.Body = _template.ToString();
            _mail.IsBodyHtml = true;
            _mail.SendMail();
            _mail.Dispose();
            #endregion

            Session.Remove("dtOrderImport"); //清除Session

            //轉址訂單歷程頁
            string StartDate = DateTime.Now.ToString("yyyy/MM/dd");
            Response.Redirect("OrderHistory.aspx?sdate=" + StartDate);
        }
        else
        {
            lblMsg.Text = strMsg;
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        liPreView.Text = "";
        palButton.Visible = false;
        btnPreView.Enabled = true;

        Session.Remove("dtOrderImport"); //清除Session
    }

    private DataTable dtSessionOrderList
    {
        get { return (DataTable)Session["dtOrderImport"]; }
        set { Session["dtOrderImport"] = value; }
    }
}