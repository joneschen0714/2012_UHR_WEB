﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Member_Index : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            ".divMemberBlock { border:1px #FF9933 solid; padding:5px 10px; margin-bottom:5px; }" +
                            ".divMemberBlock .imgPosition { }" +
                            ".divMemberBlock .linkPosition { margin-left:15px; }" +
                            ".divMemberBlock .wordPosition { }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //多國語系
        btnProfile.Text = Resources.Lang.L000050;
        lblProfileDesc.Text = Resources.Lang.L000099;
        btnPromotion.Text = Resources.Lang.L000028;
        btnWishList.Text = Resources.Lang.L000029;
        btnShoppingCart.Text = Resources.Lang.L000030;
        btnRmaForm.Text = Resources.Lang.L000017;
        btnFAQ.Text = Resources.Lang.L000033;
        btnOrderHistory.Text = Resources.Lang.L000176;
        btnImportOrder.Text = Resources.Lang.L000183;
    }

    protected void MemberButton_Click(object sender, EventArgs e)
    {
        LinkButton linkBtn = (LinkButton)sender;

        if (linkBtn.ID == "btnProfile")
        { Response.Redirect("~/Page/Member/UpdateMyProfile.aspx"); }

        else if (linkBtn.ID == "btnPromotion")
        { Response.Redirect("~/Page/Product/Promotion.aspx"); }

        else if (linkBtn.ID == "btnWishList")
        { Response.Redirect("~/Page/Member/WishList.aspx"); }

        else if (linkBtn.ID == "btnShoppingCart")
        { Response.Redirect("~/Page/Member/EstimatedSheet.aspx"); }

        else if (linkBtn.ID == "btnRmaForm")
        { Response.Redirect("~/Page/RMA/RmaForm.aspx"); }

        else if (linkBtn.ID == "btnFAQ")
        { Response.Redirect("~/Page/Member/FAQList.aspx"); }

        else if (linkBtn.ID == "btnOrderHistory")
        { Response.Redirect("~/Page/Member/OrderHistory.aspx"); }

        else if (linkBtn.ID == "btnImportOrder")
        { Response.Redirect("~/Page/Member/OrderImport.aspx"); }
    }
}