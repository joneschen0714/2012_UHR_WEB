﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class FAQList : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gv_GridDataBind(sender, e);
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        MemberInfo mi = Definition.MemberInfo; //目前會員物件

        //取得資料來源
        int recordCount;
        DataTable dtFAQ = BLL.GetFAQList(mi.MemberID, gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn(Resources.Lang.L000044, "", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000103, "Type", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000141, "Subject", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000145, "", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(Resources.Lang.L000146, "", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataKeyNames = new string[] { "ID" }; //設定主鍵
        gv.GridView.DataSource = dtFAQ;
        gv.DataBind();
    }

    //Grid資料列繫結事件
    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //資料列
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            DataRowView rowView = (DataRowView)e.Row.DataItem;

            int iReplyCount = Convert.ToInt32(rowView["ReplyCount"]);

            TableCell cellDate = gv.GetTableCell(e.Row, Resources.Lang.L000044, false);
            TableCell cellReply = gv.GetTableCell(e.Row, Resources.Lang.L000145, false);
            TableCell cellView = gv.GetTableCell(e.Row, Resources.Lang.L000146, false);

            cellDate.Text = Convert.ToDateTime(rowView["UpdateTime"]).ToString("yyyy-MM-dd");
            cellReply.Text = (iReplyCount > 0 ? "<img src='../../Source/Image/checkbox_checked.png' />" : "&nbsp;");
            cellView.Text = string.Format("<a href='FAQDetail.aspx?id={0}'>" + Resources.Lang.L000146 + "</a>", rowView["ID"]);
        }
    }
}