﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using UHR;

public partial class QA : MemberPageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //多國語系
            btnSend.Text = Resources.Lang.L000142;

            DataBind();
        }
    }

    public override void DataBind()
    {
        string strType = Tool.CheckQueryString("type"); //問題類型

        MemberInfo mi = Definition.MemberInfo; //目前的會員物件
        DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0]; //取得會員資料

        //設定控制項值
        lblFrom.Text = Convert.ToString(rowMember["Name"]);

        ddlType.DataSource = BLL.GetConfigData("Q&A Type");
        ddlType.DataBind();
        ddlType.Items.Insert(0, new ListItem("--select type--", ""));

        if (strType != "") ddlType.SelectedValue = strType; //選擇類型
    }

    //送出按鈕事件
    protected void btnSend_Click(object sender, EventArgs e)
    {
        MemberInfo mi = Definition.MemberInfo; //目前的會員物件
        DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0]; //取得會員資料

        //變數
        string strTypeVal = ddlType.SelectedValue;
        string strTypeTxt = ddlType.SelectedItem.Text;
        string strSubject = txtSubject.Text.Trim();
        string strComments = txtComments.Text.Replace(System.Environment.NewLine, "<br />");

        //回寫DB
        BLL.InsertFAQ("", mi.MemberID, strTypeTxt, strSubject, strComments);

        #region Mail內容參數
        TemplateMail _template = new TemplateMail("~/Source/Html/QAForm.htm");
        _template["{name}"] = Convert.ToString(rowMember["Name"]);
        _template["{From}"] = lblFrom.Text;
        _template["{Sent DateTime}"] = DateTime.Now.ToString("yyyy/MM/dd hh:mm");
        _template["{Type}"] = strTypeTxt;
        _template["{Subject}"] = strSubject;
        _template["{Comments}"] = strComments;
        #endregion

        #region Mail相關設定
        Mail _mail = new Mail();
        _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
        _mail.CC.Add(Definition.ContactSalesMail);
        _mail.To.Add(mi.Email);
        _mail.Subject = "Q&A Form" + string.Format(" [{0} - {1}]", rowMember["Company"], rowMember["Name"]);
        _mail.Body = _template.ToString();
        _mail.IsBodyHtml = true;
        _mail.SendMail();
        _mail.Dispose();
        #endregion

        //清除內容
        ddlType.SelectedValue = "";
        txtSubject.Text = "";
        txtComments.Text = "";

        Page.Header.Controls.Add(Tool.GetJavaScriptContent("alert('" + Resources.Lang.L000144 + "');"));
    }
}