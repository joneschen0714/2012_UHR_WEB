﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Public_NewsList : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //註冊事件
        gv.GridView.RowDataBound += new GridViewRowEventHandler(GridView_RowDataBound);
        gv.GridDataBind += new EventHandler(gv_GridDataBind);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            gv_GridDataBind(sender, e);
        }
    }

    protected void gv_GridDataBind(object sender, EventArgs e)
    {
        //取得資料來源
        int recordCount;
        DataTable dtNews = BLL.GetAllNews("News", gv.PageIndex, gv.GridView.PageSize, out recordCount);

        //多國語系
        string strDate = Resources.Lang.ResourceManager.GetString("L000044");
        string strTitle = Resources.Lang.ResourceManager.GetString("L000045");

        //增加欄位
        gv.GridView.Columns.Clear();
        gv.AddColumn(strDate, "EffectiveDate", false, 100, HorizontalAlign.NotSet, HorizontalAlign.NotSet);
        gv.AddColumn(strTitle, "Title", false, Unit.Empty, HorizontalAlign.NotSet, HorizontalAlign.NotSet);

        //載入Grid
        gv.RowCount = recordCount;
        gv.GridView.DataKeyNames = new string[] { "ID" }; //設定主鍵
        gv.GridView.DataSource = dtNews;
        gv.DataBind();
    }

    //Grid資料列繫結事件
    protected void GridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //資料列
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //表格欄
            TableCell cellTitle = gv.GetTableCell(e.Row, "Title", true);
            TableCell cellDate = gv.GetTableCell(e.Row, "EffectiveDate", true);

            //變數
            DataRowView rowView = (DataRowView)e.Row.DataItem;
            string strID = Convert.ToString(rowView["ID"]);
            string strTitle = Convert.ToString(rowView["Title"]);
            string strHref = ResolveClientUrl("~/Page/Public/NewsDetail.aspx?id=" + strID);
            string strDate = Convert.ToDateTime(rowView["EffectiveDate"]).ToString("[yyyy-MM-dd]");

            //設定值
            cellTitle.Text = string.Format("<a href='{0}'>{1}</a>", strHref, strTitle);
            cellDate.Text = strDate;
        }
    }
}