﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Ajax_QuickOrder : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string strType = Tool.CheckQueryString("type");
        string strKeyword = Tool.CheckQueryString("keyword");
        string strLM = Tool.CheckQueryString("lm");
        string strBL = Tool.CheckQueryString("bl");

        if (strType == "quickorder")
        {
            GetQuickOrderData(strKeyword);
        }
        else if (strType == "additem")
        {
            AddItem(strLM, strBL);
        }
    }

    //取得QuickOrder的Json資料來源
    private void GetQuickOrderData(string _keyword)
    {
        DataTable dtResult = BLL.GetQuickOrderData(_keyword);

        string html = "";
        if (dtResult.Rows.Count > 0)
        {
            //多國語系
            string lReset = Resources.Lang.ResourceManager.GetString("L000055");
            string lBrand = Resources.Lang.ResourceManager.GetString("L000020");
            string lProjector = Resources.Lang.ResourceManager.GetString("L000056");

            html += "<input type='button' value='" + lReset + "' onclick='QuickOrderClear()' class='ButtonStyle2_s' />　　" +
                    "<span>B: Bulb　L: Lamp Module</span>" +
                    "<table id='quickordermodule' width='700px' cellpadding='0' cellspacing='0'>" +
                        "<tr> <th>&nbsp;&nbsp;L&nbsp;&nbsp;&nbsp;B</th> <th>UHR Lamp Module</th> <th>" + lBrand + "</th> <th>" + lProjector + "</th> <th>Lamp Module</th> </tr>";

            //取出UHR_LampModule與OEM_LampModule不重覆資料
            DataTable dtUHRLM = dtResult.DefaultView.ToTable(true, "Brand", "OEMLampModule", "UHR_LMID", "UHR_LM", "UHR_LM_Status", "UHR_BL_Status");

            foreach (DataRow row in dtUHRLM.Rows)
            {
                //變數
                string strBrand = Convert.ToString(row["Brand"]);
                string strOEMLampModule = Convert.ToString(row["OEMLampModule"]);
                string strUHR_LMID = Convert.ToString(row["UHR_LMID"]);
                string strUHR_LM = Convert.ToString(row["UHR_LM"]);
                string strUHR_LM_Status = Convert.ToString(row["UHR_LM_Status"]);
                string strUHR_BL_Status = Convert.ToString(row["UHR_BL_Status"]);

                string temp = "";
                temp += "<tr class='trQuickOrderItem'>" +
                            "<td><input name='radioLM' type='radio' {LM_Status} /><input name='radioBL' type='radio' {BL_Status} /></td>" +
                            "<td><a href='{Href}'>{UHR_LM}</a></td>" +
                            "<td>{Brand}</td>" +
                            "<td><select>{ProjectModelItems}</select></td>" +
                            "<td>{OEMLampModule}</td>" +
                        "</tr>";

                //設定Projector項目
                string strProjectorModelItems = "";
                DataRow[] rowProjectors = dtResult.Select("Brand='" + strBrand + "' AND OEMLampModule='" + strOEMLampModule + "' AND UHR_LM='" + strUHR_LM + "'");
                foreach (DataRow rowPj in rowProjectors)
                {
                    string strPjID = Convert.ToString(rowPj["ID"]);
                    string strProjector = Convert.ToString(rowPj["ProjectorModel"]);

                    strProjectorModelItems += "<option value='" + strPjID + "'>" + strProjector + "</option>";
                }

                temp = temp.Replace("{Brand}", strBrand)
                           .Replace("{ProjectModelItems}", strProjectorModelItems)
                           .Replace("{OEMLampModule}", strOEMLampModule)
                           .Replace("{UHR_LM}", strUHR_LM)
                           .Replace("{Href}", ResolveClientUrl("~/Page/Product/ProductList.aspx?uhrlm=" + strUHR_LMID))
                           .Replace("{LM_Status}", strUHR_LM_Status != "I" ? "disabled" : "")
                           .Replace("{BL_Status}", strUHR_BL_Status != "I" ? "disabled" : "");

                html += temp;
            }
            html += "</table>";
        }
        else
        {
            html = Resources.Lang.ResourceManager.GetString("L000048");
        }

        Response.Write(html);
    }

    //加入產品至購物車
    private void AddItem(string _lm, string _bl)
    {
        string strScript = "";

        ShoppingCart sc = Definition.ShoppingCart;

        //加入Lamp Module
        if (!string.IsNullOrEmpty(_lm))
        {
            ShoppingCartItem.ProductType pt = ShoppingCartItem.GetProductType("LM");
            if (!sc.Exists(_lm, pt)) { sc.Add(_lm, pt, 1); }
            else { strScript += Resources.Lang.ResourceManager.GetString("L000053") + "<br />"; }
        }

        //加入Bare Lamp
        if (!string.IsNullOrEmpty(_bl))
        {
            ShoppingCartItem.ProductType pt = ShoppingCartItem.GetProductType("BL");
            if (!sc.Exists(_bl, pt)) { sc.Add(_bl, pt, 1); }
            else { strScript += Resources.Lang.ResourceManager.GetString("L000054") + "<br />"; }
        }

        Response.Write(strScript);
    }
}