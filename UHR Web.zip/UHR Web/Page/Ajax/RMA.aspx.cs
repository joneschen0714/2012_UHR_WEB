﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Page_Ajax_RMA : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //網址參數
        string strType = Tool.CheckQueryString("type");
        string strVal = Tool.CheckQueryString("val");

        if (strType == "getreasondata")
        {
            GetReasonData(strVal);
        }
    }

    //取得RMA單的Reason資料
    private void GetReasonData(string _value)
    {
        DataTable dt = BLL.GetRmaReason();

        int i = 1;
        string strContent = "<div id=\"divReasonCode\">";
        foreach (DataRow row in dt.Rows)
        {
            string strID = Convert.ToString(row["ID"]);
            string strItem = Convert.ToString(row["Item"]);
            string strChecked = "";

            foreach (string tmpVal in _value.Split(','))
                if (strID == tmpVal) { strChecked = "Checked"; }

            strContent += string.Format("<input id=\"{0}\" type=\"checkbox\" value=\"{1}\" {3} /> <label for=\"{0}\">{2}</label><br />",
                            "cbReasonCode" + Convert.ToString(i),
                            strID,
                            strItem,
                            strChecked);
            i++;
        }
        strContent += "</div>";
        Response.Write(strContent);
    }
}
