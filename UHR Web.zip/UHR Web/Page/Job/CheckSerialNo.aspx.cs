﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Data.OleDb;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class CheckSerialNo : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D:\\checkno.xls;Extended Properties=Excel 8.0;";
        OleDbDataAdapter adp = new OleDbDataAdapter("SELECT SerialNo FROM [Sheet1$]", strConn);

        DataTable dtResult = new DataTable();
        adp.Fill(dtResult);

        string strSixTxt = "";
        int iSN = 1;

        foreach (DataRow row in dtResult.Rows)
        {
            string strSerialNo = Convert.ToString(row["SerialNo"]);
            int iCurr = int.Parse(strSerialNo.Substring(6, 4));

            if (strSixTxt == strSerialNo.Substring(0, 6))
            {
                if ((iSN + 1) != iCurr)
                {
                    Response.Write(strSerialNo.Substring(0, 6) + iSN.ToString("0000") + " > " + strSerialNo.Substring(0, 6) + iCurr.ToString("0000") + "<br />");
                    iSN = iCurr;
                }
                else
                {
                    iSN++;
                }
                strSixTxt = strSerialNo.Substring(0, 6);
            }
            else
            {
                if (iCurr != 1)
                {
                    Response.Write("缺少0001 > " + strSerialNo.Substring(0, 6) + iCurr.ToString("0000") + "<br />");
                }
                strSixTxt = strSerialNo.Substring(0, 6);
                iSN = iCurr;
            }
        }
    }
}
