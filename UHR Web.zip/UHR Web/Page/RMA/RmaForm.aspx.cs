﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Net.Mail;
using UHR;

public partial class Page_RMA_RmaForm : MemberPageBase
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            ".trSplit > td { padding:5px; }" +
                            ".tbForm .FormHeader { background-color:#ff8c00; color:#FFFFFF; }" +
                            ".tbForm .FormHeader th { padding:0px 5px; }" +
                            ".tbForm td { padding:2px 5px; text-align:center; border-bottom:#b8860b 1px dotted; }" +
                            ".Pointer { cursor:pointer; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    //送出動作
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        string strReasonXml = txtReasonCode.Text;
        string strType = rblType.SelectedValue;
        string strDescription = txtDescription.Text.Replace(System.Environment.NewLine, "<br />");
        MemberInfo mi = Definition.MemberInfo;

        bool bResult = BLL.AddRMAForm(strType, strDescription, strReasonXml, mi);
        if (bResult)
        {
            string strItemsHtml = "";
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(strReasonXml);
            foreach (XmlNode node in xmlDoc.SelectNodes("items/item"))
            {
                strItemsHtml += string.Format("<tr> <td>{0}</td> <td>{1}</td> <td>{2}</td> <td>{3}</td> </tr>",
                                    node.Attributes["item"].Value,
                                    node.Attributes["pn"].Value,
                                    node.Attributes["sn"].Value,
                                    node.Attributes["code"].Value);
            }


            DataRow rowMember = BLL.GetMemberInfo(mi.MemberID).Rows[0]; //取得會員個人資料
            DataRow rowCountry = BLL.GetCountryList(rowMember["Country"].ToString()).Rows[0];

            //Mail內容參數
            TemplateMail _template = new TemplateMail("~/Source/Html/RmaForm.htm");
            _template["{date}"] = DateTime.Now.ToString("yyyy/MM/dd");
            _template["{reques}"] = strType;
            _template["{company}"] = Convert.ToString(rowMember["Company"]);
            _template["{person}"] = Convert.ToString(rowMember["Name"]);
            _template["{email}"] = Convert.ToString(rowMember["Email"]);
            _template["{tel}"] = Convert.ToString(rowMember["Tel"]);
            _template["{country}"] = Convert.ToString(rowCountry["Name"]);
            _template["{Address}"] = Convert.ToString(rowMember["Address"]);
            _template["{Description}"] = strDescription;
            _template["{item}"] = strItemsHtml;

            //Mail相關設定
            Mail _mail = new Mail();
            _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
            _mail.To.Add(mi.Email);
            _mail.CC.Add(Definition.ContactSalesMail);
            _mail.Subject = "RMA Request" + string.Format(" [{0} - {1}]", rowMember["Company"], rowMember["Name"]);
            _mail.Body = _template.ToString();
            _mail.IsBodyHtml = true;
            _mail.SendMail();

            //訊息顯示
            Control ctrl = Tool.GetJavaScriptContent("$.prompt('" + Resources.Lang.L000170 + "')");
            Page.Header.Controls.Add(ctrl);
        }
        else
        {
            //訊息顯示
            Control ctrl = Tool.GetJavaScriptContent("$.prompt('Processing mistake')");
            Page.Header.Controls.Add(ctrl);
        }
    }
}