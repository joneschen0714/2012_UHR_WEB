﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css & Script
        string strScript = "<style type='text/css'>" +
                                ".divPromotionSlides { position:relative; height:250px; width:645px; z-index:0; margin-bottom:10px; }" +
                                ".divPromotionSlides .SlideItem { position:absolute; left:0; top:0; display:none; }" +
                                ".divPromotionSlides .SlideBtn { position:absolute; bottom:5px; right:5px; z-index:1; }" +
                                ".divPromotionSlides .SlideBtn a { background:url(Source/Image/radio-button_off.png); display:block; width:20px; height:20px; float:left; cursor:pointer; }" +
                                ".divPromotionSlides .SlideBtn a.ActiveSlideBtn { background:url(Source/Image/radio-button_on.png); cursor:default; }" +

                                "#divMiddle { position:relative; width:970px; margin:10px auto; }" +
                                "#hotpdts { }" +
                                "#hotpdts li { margin:0 5px; background-color:#fff; border:#EFEFEF 1px solid; text-align:center; width:120px; height:140px; }" +
                                "#hotpdts li img { margin-top:5px; }" +
                                "#hotpdts li p { margin-top:10px; font-weight:bold; line-height:18px; }" +
                                "#hotpdts li a { display:block; text-decoration:none; }" +
                                "</style>";
        Page.Header.Controls.Add(new LiteralControl(strScript));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //執行各函式
        if (!IsPostBack)
        {
            SetMutliLanguage();
            CreateSlide();
            CreateHotProducts();
            CreateNews();
        }
    }

    private void CreateSlide()
    {
        int iOut;
        DataTable dtNews = BLL.GetAllNews("Slide", 1, int.MaxValue, out iOut);

        string strSlideBtn = "";
        for (int i = 0; i < dtNews.Rows.Count; i++)
        {
            DataRow row = dtNews.Rows[i];

            liSlide.Text += string.Format("<div class='SlideItem'>{0}</div>", row["SlideContent"]);

            string select = (i == 0 ? "ActiveSlideBtn" : "");
            strSlideBtn += string.Format("<a class='{0}' time='{1}'></a>", select, row["SlideTimeSpan"]);
        }
        liSlideBtn.Text = strSlideBtn;
    }

    private void CreateHotProducts()
    {
        DataTable dt = BLL.GetHotProducts();

        string str = "<ul>";
        foreach (DataRow row in dt.Rows)
        {
            string strFilePath = ConfigurationManager.AppSettings["ProductImagePath"] + Convert.ToString(row["FileName"]);
            string strPath = ResolveClientUrl("~/thumbnail.ashx?height=80&file=" + strFilePath);
            string p_ID = row["ID"].ToString();
            string Brand = row["Brand"].ToString();
            string OEM_LM = row["OEM_LM"].ToString();

            if (OEM_LM.IndexOf('/') > 0)
                OEM_LM = OEM_LM.Substring(0, OEM_LM.IndexOf('/'));

            //str += "<li><a href='Page/Product/ProductList.aspx?uhrlm=" + LMID + "'><img src='" + strPath + "' />" + LM + "</a></li>";
            str += "<li><a href='Page/Product/ProductDetail.aspx?id=" + p_ID + "'><img src='" + strPath + "' /><p>" + Brand + "<div>" + OEM_LM + "</div></p></a></li>";
        }

        str += "</ul>";
        liHotProducts.Text = str;
    }

    private void CreateNews()
    {
        DataRow row = BLL.GetFirstNews();

        if (row != null)
        {
            lbl_News.Text = row["Title"].ToString();
            liNewsContent.Text = string.Format("<a class='link01' href='Page/Public/NewsDetail.aspx?id={0}'>{1}</a>", row["ID"], row["Description"]);
        }
    }

    private void SetMutliLanguage()
    {
        //lblLatestNews.Text = Resources.Lang.L000040;
        //linkViewAllNews.Text = Resources.Lang.L000041;
        lblHotProducts.Text = Resources.Lang.L000042;
        lbl_Help.Text = Resources.Lang.L000221;
        lbl_HelpContent.Text = Resources.Lang.L000222;
        lbl_Shipping.Text = Resources.Lang.L000224;
        Label1.Text = Resources.Lang.L000214;
        Label2.Text = Resources.Lang.L000225;
        Label5.Text = Resources.Lang.L000228;
        Label6.Text = Resources.Lang.L000229;

        lbl_UhrgSeries.Text = Resources.Lang.L000230;
        Label7.Text = Resources.Lang.L000006;
        Label8.Text = Resources.Lang.L000231;
        Label9.Text = Resources.Lang.L000007;
        Label10.Text = Resources.Lang.L000235;
        lbl_WeAccept.Text = Resources.Lang.L000215;
        lbl_SAYNO.Text = Resources.Lang.L000213;
    }
}