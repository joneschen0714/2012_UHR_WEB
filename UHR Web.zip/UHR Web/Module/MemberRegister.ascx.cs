﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Module_MemberRegister : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //多國語系
        rev_txt_r_Email.Text = Resources.Lang.L000082;
        cv_txt_r_ConfirmPassword.Text = Resources.Lang.L000086;
        rbl_r_Sex.Items.FindByValue("M").Text = Resources.Lang.L000088;
        rbl_r_Sex.Items.FindByValue("F").Text = Resources.Lang.L000089;
        btnRegister.Text = Resources.Lang.L000094;
        btnUpdate.Text = Resources.Lang.L000095;

    }

    //預設函式
    private void FillDefault()
    {
        //載入國家清單
        ddl_r_Country.DataSource = BLL.GetCountryList("");
        ddl_r_Country.DataBind();
        ddl_r_Country.Items.Insert(0, new ListItem(Resources.Lang.L000096, ""));
    }

    //更新初始化
    public new void DataBind(string _memberid)
    {
        FillDefault();

        //判斷是否帶入會員ID
        if (string.IsNullOrEmpty(_memberid))
        {
            btnUpdate.Visible = false;
        }
        else
        {
            btnRegister.Visible = false;
            hiddenMemberID.Value = _memberid;

            //資料來源
            DataRow row = BLL.GetMemberInfo(_memberid).Rows[0];

            //載入值
            hiddenMemberID.Value = _memberid;
            txt_r_ConfirmPassword.Text = Convert.ToString(row["Password"]);
            txt_r_Name.Text = Convert.ToString(row["Name"]);
            rbl_r_Sex.SelectedValue = Convert.ToString(row["Sex"]);
            txt_r_Email.Text = Convert.ToString(row["Email"]);
            txt_r_Tel.Text = Convert.ToString(row["Tel"]);
            txt_r_Address.Text = Convert.ToString(row["Address"]);
            txt_r_Company.Text = Convert.ToString(row["Company"]);
            ddl_r_Country.SelectedValue = Convert.ToString(row["Country"]);
            trNextVisit.Visible = false;
        }
    }

    //註冊按鈕動作
    protected void btnRegister_Click(object sender, EventArgs e)
    {
        //變數
        string strPassword = txt_r_ConfirmPassword.Text.Trim();
        string strName = txt_r_Name.Text.Trim();
        string strSex = rbl_r_Sex.SelectedValue;
        string strEmail = txt_r_Email.Text.Trim();
        string strTel = txt_r_Tel.Text.Trim();
        string strAddress = txt_r_Address.Text.Trim();
        string strCompany = txt_r_Company.Text.Trim();
        string strCountry = ddl_r_Country.SelectedValue.Trim();
        string strMessage = "";

        //檢查會員資料
        BLL.CheckMember(null, strEmail, ref strMessage);
        if (string.IsNullOrEmpty(strMessage))
        {
            //註冊會員 & 成功訊息
            BLL.RegisterMember(strPassword, strEmail, strName, strTel, strAddress, strCompany, strSex, strCountry);

            //變數
            string strUrl = "~/Page/Member/Login.aspx";
            strUrl = Tool.SetUrlParam(strUrl, "uid", strEmail);
            strUrl = Tool.SetUrlParam(strUrl, "pwd", strPassword);
            strUrl = Tool.SetUrlParam(strUrl, "nextvisit", cbNextVisit.Checked.ToString());

            //轉向登入頁
            Response.Redirect(strUrl);
        }
        else
        {
            //錯誤訊息
            lbl_r_Message.Text = "<label style='color:red'>Email is already in use.</label>";
        }
    }

    //更新按鈕動作
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        //變數
        string strMemberID = hiddenMemberID.Value;
        string strPassword = txt_r_ConfirmPassword.Text.Trim();
        string strName = txt_r_Name.Text.Trim();
        string strSex = rbl_r_Sex.SelectedValue;
        string strEmail = txt_r_Email.Text.Trim();
        string strTel = txt_r_Tel.Text.Trim();
        string strAddress = txt_r_Address.Text.Trim();
        string strCompany = txt_r_Company.Text.Trim();
        string strCountry = ddl_r_Country.SelectedValue.Trim();
        string strMessage = "";

        //檢查會員資料
        BLL.CheckMember(strMemberID, strEmail, ref strMessage);
        if (string.IsNullOrEmpty(strMessage))
        {
            BLL.UpdateMemberInfo(strMemberID, strPassword, strEmail, strName, strTel, strAddress, strCompany, strSex, strCountry);

            Definition.MemberInfo.Email = strEmail;

            lbl_r_Message.Text = "<label style='color:blue'>Finish</label>";
        }
        else
        {
            //錯誤訊息
            lbl_r_Message.Text = "<label style='color:red'>Email is already in use.</label>";
        }
    }
}