﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Net.Mail;
using UHR;

public partial class Module_ForgotPassword : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //多國語系
        lblTitle.Text = Resources.Lang.L000077;
        lblDesc1.Text = Resources.Lang.L000078;
        lblDesc2.Text = Resources.Lang.L000079;
        btnRequest.Text = Resources.Lang.L000080;
        rfv_txtEmail.Text = Resources.Lang.L000081;
        rev_txtEmail.Text = Resources.Lang.L000082;
    }

    protected void btnRequest_Click(object sender, EventArgs e)
    {
        string strEmail = txtEmail.Text.Trim();

        DataTable dtResult = BLL.EmailGetMember(strEmail);

        if (dtResult.Rows.Count > 0)
        {
            //參數
            DataRow row = dtResult.Rows[0];
            string strPassword = Convert.ToString(row["Password"]);
            string strName = Convert.ToString(row["Name"]);
            string strSubject = "Send Password from UHR Lamps Web";

            //Mail內容參數
            TemplateMail _template = new TemplateMail("~/Source/Html/ForgotPassword.htm");
            _template["{account}"] = strEmail;
            _template["{password}"] = strPassword;

            //Mail相關設定
            Mail _mail = new Mail();
            _mail.From = new MailAddress(Definition.SendMailFromAddress, Definition.SendMailDisplayName);
            _mail.To.Add(new MailAddress(strEmail, strName));
            _mail.Subject = strSubject;
            _mail.Body = _template.ToString();
            _mail.IsBodyHtml = true;
            _mail.SendMail();

            //發Mail & 傳回發送狀態
            lblMessage.Text = "<label style='color:blue'>already send to your mailbox.</label>";
        }
        else
        {
            lblMessage.Text = "<label style='color:red'>Email not found.</label>";
        }
    }
}
