﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text;
using System.Xml;
using UHR;

public partial class Module_Menu : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string strMenuPath = ConfigurationSettings.AppSettings["MenuXmlPath"];

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(Server.MapPath(strMenuPath));

            liMenu.Text = CreateMenu("menu", xmlDoc.LastChild.ChildNodes);
        }
    }

    private string CreateMenu(string tag, XmlNodeList Nodes)
    {
        string menu = "<ul id='" + tag + "'>";

        for (int i = 0; i < Nodes.Count; i++)
        {
            XmlNode node = Nodes[i];

            //讀取屬性
            string strUrl = ResolveClientUrl(node.Attributes["Url"].Value);
            string strTitle = node.Attributes["Title"].Value;
            string strToolTip = node.Attributes["ToolTip"] == null ? "" : node.Attributes["ToolTip"].Value;

            //語系轉換
            strTitle = Resources.Lang.ResourceManager.GetString(strTitle);
            strToolTip = Resources.Lang.ResourceManager.GetString(strToolTip);

            if (strUrl != "") { strUrl = " href='" + strUrl + "' "; };
            if (strToolTip != "") { strToolTip = "title='" + strToolTip + "' "; }

            menu += string.Format("<li><a {0} {1}>{2}</a>", strUrl, strToolTip, strTitle);

            if (node.ChildNodes.Count > 0)
            {
                menu += "<div>" + CreateMenu("child", node.ChildNodes) + "</div>";
            }

            menu += "</li>";
        }

        menu += "</ul>";
        return menu;
    }
}