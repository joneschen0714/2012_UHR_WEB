﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Module_QuickOrder : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            "#quickordermodule tr th { background-color:#ffdead; text-align:left; }" +
                            "#quickordermodule tr.trQuickOrderItem td { padding:2px 5px; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //執行各函式
        if (!IsPostBack)
        {
            SetMutliLanguage();
        }
    }

    private void SetMutliLanguage()
    {
        lblQuickOrder.Text = Resources.Lang.ResourceManager.GetString("L000046");
    }
}
