﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class Module_ProductSearch : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            //預設值
            txtKeyword.Attributes.Add("value", Resources.Lang.L000100);
            lblSeach.Text = Resources.Lang.L000237;

            //載入輸入的關鍵字
            string strKeyword = Tool.CheckQueryString("keyword");
            txtKeyword.Text = strKeyword;
        }
    }

    //按鈕搜尋動作
    protected void btnSearch_Click(object sender, EventArgs e)
    {
        //記錄關鍵字Log
        string MemberID = "";
        if (MemberInfo.CheckLogin) { MemberID = Definition.MemberInfo.MemberID; }
        BLL.InsertKeywordLog(txtKeyword.Text, MemberID, Tool.GetClientIP());

        string strKeyword = txtKeyword.Text.Replace("-", "").Replace(" ", "");
        strKeyword = Server.UrlEncode(strKeyword); //編碼
        string strHref = ResolveClientUrl("~/Page/Product/ProductList.aspx?keyword=" + strKeyword);

        //轉址
        Response.Redirect(strHref);
    }
}