﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Specialized;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Xml;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using UHR;

public partial class MutliLanguage : System.Web.UI.UserControl
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //載入Style樣式
        string strCss = "<style type=\"text/css\">" +
                            "#tbMutliLang { display:none; position:absolute; right:0px; top:15px; }" +
                            "#tbMutliLang ul { list-style:none; margin:0px; padding:0px; background:#fff; }" +
                            "#tbMutliLang ul li { padding:0px; margin:0px; }" +
                        "</style>";
        Page.Header.Controls.Add(new LiteralControl(strCss));
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        //語系
        lblLang.Text = Resources.Lang.L000209;

        if (!IsPostBack)
        {
            //取得目前語系
            string strLang = System.Globalization.CultureInfo.CurrentCulture.Name;
            string[] strCurrentLang = ListLang.Find(delegate(string[] strArray) { return strArray[0] == strLang; });

            //顯示目前語系
            lblSelectLang.Text = strCurrentLang[1];
            imgLang.ImageUrl = strCurrentLang[2];

            //組成Html
            string strHtml = "<ul>";
            foreach (string[] ary in ListLang)
            {
                strHtml += "<li><a href='#' onclick=\"SetCurrentLang('" + ary[0] + "')\"><img src=" + ResolveUrl(ary[2]) + " /> " + ary[1] + "</a></li>";
            }
            strHtml += "</ul>";
            li.Text = strHtml;
        }
    }

    protected void LangChanged_Click(object sender, EventArgs e)
    {
        //取得切換的語系
        string strLang = txtLangCode.Text;

        //記錄Cookie，為期一年
        HttpCookie cookie = new HttpCookie("Lang", strLang);
        cookie.Expires = DateTime.Now.AddYears(1);
        Response.Cookies.Add(cookie);

        //重導此頁
        Response.Redirect(Request.Url.ToString());
    }

    private List<string[]> ListLang
    {
        get
        {
            string[] strA1 = { "zh-TW", "繁體中文", "~/Source/Image/Country/small/tw.png" };
            string[] strA2 = { "de-DE", "Deutsch", "~/Source/Image/Country/small/germany.gif" };
            string[] strA3 = { "ja-JP", "日本語", "~/Source/Image/Country/small/ja.png" };
            string[] strA4 = { "en-US", "English", "~/Source/Image/Country/small/us.png" };

            List<string[]> listLang = new List<string[]>();
            listLang.Add(strA1);
            listLang.Add(strA2);
            listLang.Add(strA3);
            listLang.Add(strA4);

            return listLang;
        }
    }
}