﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using UHR;

public partial class Template_Main : System.Web.UI.MasterPage
{
    protected void Page_Init(object sender, EventArgs e)
    {
        //引用頁面Css & Script
        string strScript = "<link type='text/css' rel='stylesheet' href='{0}' />" +
                           "<link type='text/css' rel='stylesheet' href='{1}' />" +
                           "<link type='text/css' rel='stylesheet' href='{2}' />" +
                           "<script type='text/javascript' src='{3}'></script>" +
                           "<script type='text/javascript' src='{4}'></script>" +
                           "<script type='text/javascript' src='{5}'></script>" +
                           "<script type='text/javascript' src='{6}'></script>" +
                           "<script type='text/javascript' src='{7}'></script>";

        strScript = string.Format(strScript,
                        ResolveClientUrl("~/Source/Css/css.css"),
                        ResolveClientUrl("~/Source/Css/jquery.impromptu.css"),
                        ResolveClientUrl("~/Source/Css/menu.css"),
                        ResolveClientUrl("~/Source/Js/jQuery/jquery-1.7.1.min.js"),
                        ResolveClientUrl("~/Source/Js/jQuery/jquery-impromptu.4.0.min.js"),
                        ResolveClientUrl("~/Source/Js/jQuery/jquery.tooltip.pack.js"),
                        ResolveClientUrl("~/Source/Js/jQuery/jquery.hoverIntent.minified.js"),
                        ResolveClientUrl("~/Source/Js/jQuery/jcarousellite_1.0.1c5.js"));

        Page.Header.Controls.Add(new LiteralControl(strScript));



        //判斷是否登入
        if (!MemberInfo.CheckLogin)
        {
            //若有Cookie記錄
            HttpCookie cookie = Request.Cookies["AutoLogin"];
            if (cookie != null)
            {
                string strMemberID = cookie.Values["MemberID"];
                DataRow row = BLL.GetMemberInfo(strMemberID).Rows[0];

                //變數
                string strName = Convert.ToString(row["Name"]);
                string strEmail = Convert.ToString(row["Email"]);
                string strLevel = Convert.ToString(row["Level"]);
                string strSalesMail = Convert.ToString(row["ContactSalesMail"]);
                string strCurrency = Convert.ToString(row["Currency"]);
                string strERP_Company = Convert.ToString(row["ERP_Company"]);
                string strERP_CustomCode = Convert.ToString(row["ERP_CustomCode"]);

                //設定登入記錄
                MemberInfo.SetMemberInfo(strMemberID, strName, strEmail, strLevel, strSalesMail, strCurrency, strERP_Company, strERP_CustomCode);

                linkLogin.Text = "Welcome, " + strName; //已登入訊息
            }
            else
            {
                linkLogin.Text = Resources.Lang.L000207; //未登入訊息
            }
        }
        else
        {
            string strName = MemberInfo.Get().Name;
            linkLogin.Text = "Welcome, " + strName; //已登入訊息
        }

        linkCart.Text = string.Format("{0} ({1})", Resources.Lang.L000208, Definition.ShoppingCart.Count); //購物車數量
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        lblSlogin.Text = Resources.Lang.L000238;
    }
}