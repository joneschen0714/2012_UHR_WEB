function fn_WindowOpen(url, name, width, height)
{
    var args = (height != 0 ? ",height="+ height : "");
	    args += (width != 0 ? ",width="+ width : "");

    window.open(url, name, 'modal=yes,resizable=yes,scrollbars=yes,location=no,directories=no,status=no,menubar=no'+ args);
}

//Dialog��w�}��
function fn_openThisWindowDialog(path , width , height)
{
	var args = (height != 0 ? "dialogHeight:"+ height +"px;" : "");
	args += (width != 0 ? "dialogWidth:"+ width +"px;" : "");
	
	//$("html").attr("style","background-color:#c8c8c8; filter:Gray(Opacity=40) Alpha(opacity=40);");
	window.showModalDialog(path, self, 'status:no;resizable:yes;center:yes;'+ args);
}